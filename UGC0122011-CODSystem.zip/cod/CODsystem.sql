CREATE TABLE Users (  
    user_id SERIAL PRIMARY KEY,  
    username VARCHAR(50) UNIQUE NOT NULL,  
    password VARCHAR(255) NOT NULL,  
    post_office_name VARCHAR(100) NOT NULL,  
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP  
);  
SELECT * FROM Users;

CREATE TABLE Sellers (  
    seller_id SERIAL PRIMARY KEY,  
    name VARCHAR(100) NOT NULL,  
    address TEXT NOT NULL,  
    contact_number VARCHAR(15) NOT NULL,  
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP  
);  
SELECT * FROM Sellers;

CREATE TABLE Receivers (  
    receiver_id SERIAL PRIMARY KEY,  
    name VARCHAR(100) NOT NULL,  
    address TEXT NOT NULL,  
    contact_number VARCHAR(15) NOT NULL,  
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP  
);  
SELECT * FROM Receivers;

CREATE TABLE Parcels (  
    parcel_id SERIAL PRIMARY KEY,  
    seller_id INT REFERENCES Sellers(seller_id) ON DELETE CASCADE,  
    receiver_id INT REFERENCES Receivers(receiver_id) ON DELETE CASCADE,  
    destination_post_office VARCHAR(100) NOT NULL,  
    amount DECIMAL(10, 2) NOT NULL,  
    weight DECIMAL(10, 2) NOT NULL,  
    commission DECIMAL(10, 2) NOT NULL,  
    status VARCHAR(50) DEFAULT 'Pending',  
    barcode VARCHAR(50) UNIQUE NOT NULL,  
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP  
);  
SELECT * FROM Parcels;

CREATE TABLE Transactions (  
    transaction_id SERIAL PRIMARY KEY,  
    parcel_id INT REFERENCES Parcels(parcel_id) ON DELETE CASCADE,  
    amount DECIMAL(10, 2) NOT NULL,  
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  
    status VARCHAR(50) DEFAULT 'Pending',  
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP  
);  
SELECT * FROM Transactions;

CREATE TABLE Receipts (  
    receipt_id SERIAL PRIMARY KEY,  
    parcel_id INT REFERENCES Parcels(parcel_id) ON DELETE CASCADE,  
    receipt_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  
    amount DECIMAL(10, 2) NOT NULL,  
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP  
);
SELECT * FROM Receipts;

INSERT INTO Users (username, password, post_office_name) VALUES
('saman_perera', 'saman123', 'Colombo Fort Post Office'),
('nishan_jayasinghe', 'nishan456', 'Kandy City Post Office'),
('priya_silva', 'priya@789', 'Galle Post Office'),
('kamal_fernando', 'kamal2024', 'Jaffna Post Office'),
('dilani_rajapaksha', 'dilani#2024', 'Matara Post Office'),
('tissa_dissanayake', 'tissa@pass', 'Negombo Post Office'),
('chaminda_rathnayake', 'chaminda123', 'Kurunegala Post Office'),
('lakshmi_perera', 'lakshmi#2024', 'Anuradhapura Post Office'),
('udaya_mendis', 'udaya@123', 'Batticaloa Post Office'),
('kumari_wickramasinghe', 'kumari$pass', 'Trincomalee Post Office'),
('shantha_samarasinghe', 'shantha@456', 'Gampaha Post Office'),
('indika_jayawardena', 'indika2024', 'Nuwara Eliya Post Office'),
('renuka_fernando', 'renuka!2024', 'Badulla Post Office'),
('geetha_liyanage', 'geetha1234', 'Vavuniya Post Office'),
('ajith_wijeratne', 'ajith@2024', 'Ratnapura Post Office'),
('nirmala_kumarasinghe', 'nirmala!pass', 'Kalutara Post Office'),
('kanchana_rajapakse', 'kanchana@123', 'Colombo 7 Post Office'),
('aruna_lokubandara', 'aruna2024!', 'Mullaitivu Post Office'),
('pradeep_kumar', 'pradeep@pass', 'Puttalam Post Office'),
('tharushi_rajapaksha', 'tharushi!2024', 'Kegalle Post Office'),
('janaka_senanayake', 'janaka123', 'Dehiwala Post Office'),
('rinaz_fahmy', 'rinaz4567', 'Colombo 3 Post Office'),
('ranjith_wijesinghe', 'ranjith7890', 'Polonnaruwa Post Office'),
('jayanthi_rathnayake', 'jayanthi@2024', 'Dambulla Post Office'),
('lasithani_perera', 'lasitha123!', 'Colombo 8 Post Office'),
('vishnu_silva', 'vishnu@pass', 'Maharagama Post Office'),
('anura_fernando', 'anura$2024', 'Kandy Post Office'),
('kamala_dissanayake', 'kamala1234', 'Jaffna Fort Post Office'),
('mohamed_nasir', 'nasir@2024', 'Kilinochchi Post Office'),
('padma_mendis', 'padma#2024', 'Mullaitivu Post Office'),
('arjuna_wickramasinghe', 'arjuna4567', 'Nugegoda Post Office'),
('sharika_rajapaksha', 'sharika2024', 'Beliatta Post Office'),
('harsha_kumari', 'harsha123!', 'Galle Fort Post Office'),
('duminda_samarasinghe', 'duminda@pass', 'Rathmalana Post Office'),
('sudesh_kumara', 'sudesh2024', 'Colombo 4 Post Office'),
('ishara_nandani', 'ishara@456', 'Weligama Post Office'),
('lasanthi_mendis', 'lasanthi#2024', 'Kurunegala City Post Office'),
('nilanthi_perera', 'nilanthi@pass', 'Matale Post Office'),
('chandima_wickramasinghe', 'chandima1234', 'Chilaw Post Office'),
('ranjika_fernando', 'ranjika@123', 'Mannar Post Office'),
('suranga_dissanayake', 'suranga!456', 'Puttalam City Post Office'),
('thushara_madusanka', 'thushara@pass', 'Moratuwa Post Office'),
('kamali_perera', 'kamali2024', 'Bentota Post Office'),
('roshan_rathnayake', 'roshan$2024', 'Vavuniya Town Post Office');


INSERT INTO Users (username, password, post_office_name) VALUES
('mohamed_ali', 'mohamed1234', 'Nuwara Eliya Post Office'),
('aruna_senanayake', 'aruna@2024', 'Vavuniya District Post Office'),
('lanka_jayasinghe', 'lanka4567', 'Trincomalee City Post Office'),
('chandima_fernando', 'chandima@1234', 'Colombo 11 Post Office'),
('ranjitha_fernando', 'ranjitha#pass', 'Puttalam District Post Office'),
('tilak_dissanayake', 'tilak2024!', 'Galle District Post Office'),
('dilan_perera', 'dilan@pass', 'Kurunegala District Post Office'),
('pradeep_sena', 'pradeep2024', 'Badulla District Post Office'),
('ravi_wickramasinghe', 'ravi$123', 'Kandy South Post Office'),
('kamani_fernando', 'kamani@2024', 'Beruwala City Post Office'),
('mohamed_rizvi', 'rizvi@pass', 'Jaffna South Post Office'),
('chandima_liyanage', 'chandima@789', 'Gampaha District Post Office'),
('ranjith_kumara', 'ranjith$2024', 'Matara South Post Office'),
('kumari_perera', 'kumari@pass', 'Colombo 2 Post Office'),
('heshan_fernando', 'heshan2024', 'Vavuniya City Post Office'),
('sasika_perera', 'sasika!123', 'Polonnaruwa District Post Office'),
('gayan_dissanayake', 'gayan1234!', 'Puttalam South Post Office'),
('yashoda_rajapaksha', 'yashoda@pass', 'Kegalle District Post Office'),
('kamani_wijesinghe', 'kamani#pass', 'Kalutara District Post Office'),
('madusha_samarasinghe', 'madusha@123', 'Moratuwa City Post Office'),
('sushmitha_wijeratne', 'sushmitha@456', 'Nuwara Eliya District Post Office'),
('vishal_silva', 'vishal@1234', 'Galle City Post Office'),
('suvinda_fernando', 'suvinda#pass', 'Ratnapura South Post Office'),
('charitha_perera', 'charitha@2024', 'Matale District Post Office'),
('indika_samarasinghe', 'indika!pass', 'Jaffna North Post Office'),
('kamal_perera', 'kamal@pass', 'Colombo 5 Post Office'),
('ranjith_liyanage', 'ranjith1234', 'Puttalam North Post Office'),
('lasitha_wijesinghe', 'lasitha@456', 'Trincomalee District Post Office'),
('dinesh_wickramasinghe', 'dinesh#2024', 'Anuradhapura North Post Office'),
('vithura_rajapaksha', 'vithura!123', 'Kandy District Post Office'),
('hemani_fernando', 'hemani#pass', 'Kurunegala North Post Office'),
('tilak_rathnayake', 'tilak1234!', 'Matara North Post Office'),
('sarath_silva', 'sarath@pass', 'Batticaloa South Post Office'),
('rajitha_perera', 'rajitha@2024', 'Kalutara City Post Office'),
('shihara_rajapakse', 'shihara@123', 'Gampaha South Post Office'),
('taniya_perera', 'taniya#456', 'Moratuwa North Post Office'),
('nuwan_rathnayake', 'nuwan@pass', 'Dambulla District Post Office'),
('danushka_wijesinghe', 'danushka@pass', 'Vavuniya South Post Office'),
('kavinda_silva', 'kavinda1234', 'Colombo 9 Post Office'),
('pavithra_jayasinghe', 'pavithra!2024', 'Polonnaruwa South Post Office'),
('kevin_dissanayake', 'kevin@1234', 'Jaffna East Post Office'),
('kamani_liyanage', 'kamani@pass', 'Kegalle South Post Office'),
('kushan_mendis', 'kushan123', 'Kandy North Post Office'),
('varuni_perera', 'varuni!456', 'Matara West Post Office'),
('nayana_silva', 'nayana@789', 'Galle South Post Office'),
('shanthi_wijesinghe', 'shanthi#2024', 'Batticaloa City Post Office'),
('manoj_fernando', 'manoj1234!', 'Kalutara North Post Office'),
('sanjeeva_rajapaksha', 'sanjeeva@pass', 'Colombo 6 Post Office'),
('nisha_wickramasinghe', 'nisha#2024', 'Kandy West Post Office'),
('gihan_wijeratne', 'gihan@2024', 'Kegalle City Post Office'),
('deepani_perera', 'deepani!789', 'Jaffna West Post Office'),
('chandana_fernando', 'chandana1234', 'Gampaha North Post Office'),
('saman_silva', 'saman@123', 'Batticaloa North Post Office'),
('kamal_wickramasinghe', 'kamal#456', 'Matale West Post Office'),
('nuwan_fernando', 'nuwan1234', 'Kegalle District Post Office'),
('kamani_rathnayake', 'kamani@123', 'Beruwala Post Office'),
('sanjay_wijesinghe', 'sanjay@2024', 'Mihintale Post Office'),
('dinesh_fernando', 'dinesh1234!', 'Ratnapura District Post Office'),
('lakshitha_silva', 'lakshitha#2024', 'Katunayake Post Office'),
('nisha_fernando', 'nisha2024', 'Anuradhapura District Post Office'),
('shamil_wijeratne', 'shamil!2024', 'Kandy North Post Office'),
('pradeep_samaraweera', 'pradeep123!', 'Jaffna City Post Office'),
('samanthika_perera', 'samanthika@pass', 'Hikkaduwa Post Office'),
('upendra_perera', 'upendra2024!', 'Habarana Post Office'),
('sureni_perera', 'sureni@pass', 'Kandy Post Office'),
('venura_silva', 'venura1234', 'Colombo 10 Post Office'),
('lahiru_fernando', 'lahiru#123', 'Dambulla City Post Office');

SELECT * FROM Users;

INSERT INTO Users (username, password, post_office_name) VALUES
('niveth_rathnayake', 'niveth@1234', 'Galle South Post Office'),
('ranjith_fernando', 'ranjith@2024', 'Matale South Post Office'),
('kamal_wickramasinghe', 'kamal@456', 'Vavuniya City Post Office'),
('shane_rathnayake', 'shane@789', 'Kurunegala North Post Office'),
('suneth_rajapaksha', 'suneth@123', 'Kandy North Post Office'),
('ajith_silva', 'ajith@456', 'Polonnaruwa North Post Office'),
('gayan_perera', 'gayan@789', 'Matale North Post Office'),
('niranjan_samarasinghe', 'niranjan@2024', 'Vavuniya South Post Office'),
('lasitha_dissanayake', 'lasitha@pass', 'Badulla City Post Office'),
('pradeep_wickramasinghe', 'pradeep@1234', 'Trincomalee City Post Office'),
('kasun_silva', 'kasun@456', 'Galle North Post Office'),
('nisala_wickramasinghe', 'nisala@789', 'Kandy South Post Office'),
('kamini_samarasinghe', 'kamini@123', 'Vavuniya City Post Office'),
('nirasha_fernando', 'nirasha@456', 'Matara District Post Office'),
('janaka_rajapaksha', 'janaka@789', 'Kurunegala City Post Office'),
('chandana_silva', 'chandana@123', 'Jaffna South Post Office'),
('shanika_rathnayake', 'shanika@2024', 'Polonnaruwa City Post Office'),
('kamal_fernando', 'kamal@1234', 'Vavuniya North Post Office'),
('priya_wickramasinghe', 'priya@456', 'Trincomalee North Post Office'),
('indika_dissanayake', 'indika@789', 'Galle South Post Office'),
('chaminda_fernando', 'chaminda@123', 'Matale District Post Office'),
('kamani_rajapaksha', 'kamani@456', 'Badulla South Post Office'),
('dinesh_samarasinghe', 'dinesh@789', 'Kandy North Post Office'),
('geetha_fernando', 'geetha@1234', 'Vavuniya South Post Office'),
('nimesha_rathnayake', 'nimesha@456', 'Kurunegala South Post Office'),
('sajini_silva', 'sajini@789', 'Trincomalee District Post Office'),
('ranjana_fernando', 'ranjana@2024', 'Polonnaruwa South Post Office'),
('kamani_rathnayake', 'kamani@123', 'Matara City Post Office'),
('tharindu_samarasinghe', 'tharindu@456', 'Jaffna North Post Office'),
('taniya_perera', 'taniya@789', 'Vavuniya City Post Office'),
('mahesha_rathnayake', 'mahesha@1234', 'Matale South Post Office'),
('indira_samarasinghe', 'indira@456', 'Galle District Post Office'),
('sumith_rajapaksha', 'sumith@789', 'Kandy South Post Office'),
('kamal_fernando', 'kamal@123', 'Polonnaruwa North Post Office'),
('dharmika_silva', 'dharmika@456', 'Vavuniya District Post Office'),
('rajitha_rathnayake', 'rajitha@789', 'Badulla District Post Office'),
('kamini_fernando', 'kamini@1234', 'Matale City Post Office'),
('sanath_samarasinghe', 'sanath@456', 'Jaffna South Post Office'),
('madhavi_fernando', 'madhavi@789', 'Kurunegala North Post Office'),
('uditha_samarasinghe', 'uditha@1234', 'Galle City Post Office'),
('kamal_silva', 'kamal@456', 'Vavuniya North Post Office'),
('megantha_samarasinghe', 'megantha@789', 'Trincomalee City Post Office'),
('kavinda_rathnayake', 'kavinda@123', 'Matale North Post Office'),
('sumathi_silva', 'sumathi@2024', 'Polonnaruwa District Post Office'),
('naveen_samarasinghe', 'naveen@456', 'Vavuniya South Post Office'),
('deshika_perera', 'deshika@789', 'Kandy City Post Office'),
('sarath_fernando', 'sarath@1234', 'Matara City Post Office'),
('kamini_rathnayake', 'kamini@456', 'Badulla North Post Office'),
('pradeep_samarasinghe', 'pradeep@789', 'Vavuniya North Post Office'),
('sangeetha_silva', 'sangeetha@123', 'Kurunegala District Post Office'),
('kanchana_rajapaksha', 'kanchana@456', 'Trincomalee South Post Office'),
('dinesh_wickramasinghe', 'dinesh@789', 'Polonnaruwa North Post Office'),
('sharmila_samarasinghe', 'sharmila@2024', 'Kandy South Post Office'),
('prabha_silva', 'prabha@123', 'Matale South Post Office'),
('kamini_fernando', 'kamini@456', 'Badulla South Post Office'),
('janitha_wickramasinghe', 'janitha@789', 'Matale District Post Office'),
('shavini_rajapaksha', 'shavini@123', 'Kurunegala South Post Office');

INSERT INTO Users (username, password, post_office_name) VALUES
('tharindu_wisal', 'password_1234', 'Pannipitiya Post Office'),
('nila_rathna', 'nila@secret', 'Matale South Post Office'),
('uditha_pera', 'uditha@1234', 'Colombo Fort Post Office'),
('shamila_samarani', 'shamila!@34', 'Kurunegala Post Office'),
('kamala_dilruksha', 'kamala@pass1', 'Jaffna City Post Office'),
('prabath_nil', 'prabath@456', 'Anuradhapura North Post Office'),
('dini_wickramasinghe', 'samanthi@890', 'Kandy City Post Office'),
('nikmani_silva', 'nimesha&123', 'Galle South Post Office'),
('randuni_rajapaksha', 'ranjitha$pass', 'Vavuniya City Post Office'),
('saumya_silva', 'sunil@secure', 'Trincomalee South Post Office'),
('krishantha_samarasinghe', 'krishantha@123', 'Polonnaruwa District Post Office'),
('sumithra_perera', 'sumith@4567', 'Badulla City Post Office'),
('lakshanika_fernando', 'lakshani#78', 'Jaffna South Post Office'),
('prashanthika_silva', 'prashantha$567', 'Matara South Post Office'),
('ranjithan_wickramasinghe', 'ranjith@2024', 'Kurunegala South Post Office'),
('chandanamala_samarasinghe', 'chandana_123', 'Kandy North Post Office'),
('nivethithani_rathnayake', 'nivethitha@!23', 'Vavuniya North Post Office'),
('kamani_praba', 'kamani@#2024', 'Vavuniya District Post Office'),
('buddhika_rajapaksha', 'buddhi@456', 'Colombo Central Post Office'),
('kumarika_samarasinghe', 'kumari@789', 'Kandy South Post Office'),
('sharinila_fernando', 'sharini@pass', 'Kurunegala North Post Office'),
('kamalani_wickramasinghe', 'kamala123@456', 'Matale North Post Office'),
('kavindran_samarasinghe', 'kavindra@pass123', 'Polonnaruwa City Post Office'),
('sudeshika_wickramasinghe', 'sudesh@password1', 'Galle North Post Office'),
('shashi_perera', 'shashika@1234', 'Trincomalee Post Office'),
('lakmalwathi_rajapaksha', 'lakmal!@456', 'Matara City Post Office'),
('nisalaka_wickramasinghe', 'nisala123@789', 'Vavuniya South Post Office'),
('dilankam_silva', 'dilanka@secret', 'Polonnaruwa North Post Office'),
('kaminil_samara', 'kamini@secure123', 'Badulla South Post Office'),
('naveeni_fernando', 'naveen_123@456', 'Galle District Post Office'),
('anushka_rathnayake', 'anushka@secure', 'Matale District Post Office'),
('manjulan_perera', 'manjula@#4567', 'Kandy District Post Office'),
('sarathi_silva', 'sarath@pass', 'Vavuniya District Post Office'),
('devika_rathnayake', 'devika@123pass', 'Kurunegala City Post Office'),
('nivethini_fernando', 'nivethini@12345', 'Jaffna City Post Office'),
('kamala_rathnayake', 'kamal@6789', 'Polonnaruwa District Post Office'),
('asanka_samarasinghe', 'asanka@secure@987', 'Galle South Post Office'),
('udara_silva', 'udara@5678', 'Matara North Post Office'),
('ranjinma_wickramasinghe', 'ranjini@pass123', 'Kurunegala South Post Office'),
('sathru_fernando', 'kamini!@12', 'Trincomalee City Post Office'),
('lal_samarasinghe', 'kamal@89012', 'Jaffna North Post Office'),
('asani_rajapaksha', 'asanka@789@#', 'Vavuniya South Post Office'),
('shamika_silva', 'shamini_@1234', 'Galle North Post Office'),
('chandi_fernando', 'chandima@password', 'Colombo South Post Office'),
('nishan_samarasinghe', 'nishan@4567', 'Matale South Post Office'),
('geethani_rathnayake', 'geethani@12345', 'Kandy North Post Office'),
('kamini_perera', 'kamini@pass2', 'Matara South Post Office'),
('shanika_fernando', 'shanika123@pass', 'Badulla Post Office'),
('kavindu_samarasinghe', 'kamini123@2024', 'Galle City Post Office'),
('nivethitha_fernando', 'nivethitha@pass', 'Vavuniya North Post Office'),
('samith_silva', 'samitha@5678', 'Kurunegala City Post Office'),
('dinesh_perera', 'dinesh@1234secure', 'Jaffna South Post Office'),
('sadiika_fernando', 'sadhika!@pass', 'Polonnaruwa South Post Office'),
('tharushi_wickramasinghe', 'tharushi@1234pass', 'Vavuniya City Post Office'),
('srilanka_rathnayake', 'srilanka@secure123', 'Colombo West Post Office'),
('kamal_silva', 'kamal@2024pass', 'Matale City Post Office'),
('ranjan_samarasinghe', 'ranjana@45678', 'Galle District Post Office'),
('kamal_samarasinghe', 'kamal@7890pass', 'Kurunegala North Post Office');

INSERT INTO Users (username, password, post_office_name) VALUES
('niveth_rathnayake', 'niveth@1234', 'Galle South Post Office'),
('raju_fernando', 'ranjith@2024', 'Matale South Post Office'),
('kasuni_wickramasinghe', 'kamal@456', 'Vavuniya City Post Office'),
('shane_rathnayake', 'shane@789', 'Kurunegala North Post Office'),
('suneth_rajapaksha', 'suneth@123', 'Kandy North Post Office'),
('aji_silva', 'ajith@456', 'Polonnaruwa North Post Office'),
('gayani_perera', 'gayan@789', 'Matale North Post Office'),
('nirman_samarasinghe', 'niranjan@2024', 'Vavuniya South Post Office'),
('laksiri_dissanayake', 'lasitha@pass', 'Badulla City Post Office'),
('pramuditha_wickramasinghe', 'pradeep@1234', 'Trincomalee City Post Office'),
('kasun_silva', 'kasun@456', 'Galle North Post Office'),
('nisalam_wickramasinghe', 'nisala@789', 'Kandy South Post Office'),
('janu_samarasinghe', 'kamini@123', 'Vavuniya City Post Office'),
('nirasha_fernando', 'nirasha@456', 'Matara District Post Office'),
('janaka_rajapaksha', 'janaka@789', 'Kurunegala City Post Office'),
('chandanamala_silva', 'chandana@123', 'Jaffna South Post Office'),
('shani_rathnayake', 'shanika@2024', 'Polonnaruwa City Post Office'),
('kamlu_fernando', 'kamal@1234', 'Vavuniya North Post Office'),
('priya_wickramasinghe', 'priya@456', 'Trincomalee North Post Office'),
('indu_dissanayake', 'indika@789', 'Galle South Post Office'),
('chami_fernando', 'chaminda@123', 'Matale District Post Office'),
('rakunu_rajapaksha', 'kamani@456', 'Badulla South Post Office'),
('dinu_samarasinghe', 'dinesh@789', 'Kandy North Post Office'),
('geethma_fernando', 'geetha@1234', 'Vavuniya South Post Office'),
('nimna_rathnayake', 'nimesha@456', 'Kurunegala South Post Office'),
('sajan_silva', 'sajini@789', 'Trincomalee District Post Office'),
('ranju_fernando', 'ranjana@2024', 'Polonnaruwa South Post Office'),
('kusum_rathnayake', 'kamani@123', 'Matara City Post Office'),
('tharu_samarasinghe', 'tharindu@456', 'Jaffna North Post Office'),
('tani_perera', 'taniya@789', 'Vavuniya City Post Office'),
('mahesha_rathnayake', 'mahesha@1234', 'Matale South Post Office'),
('indira_samarasinghe', 'indira@456', 'Galle District Post Office'),
('sunil_rajapaksha', 'sumith@789', 'Kandy South Post Office'),
('malika_fernando', 'kamal@123', 'Polonnaruwa North Post Office'),
('dharmika_silva', 'dharmika@456', 'Vavuniya District Post Office'),
('uchitha_rathnayake', 'rajitha@789', 'Badulla District Post Office'),
('nira_fernando', 'kamini@1234', 'Matale City Post Office'),
('sanath_samarasinghe', 'sanath@456', 'Jaffna South Post Office'),
('madhavi_fernando', 'madhavi@789', 'Kurunegala North Post Office'),
('udina_samarasinghe', 'uditha@1234', 'Galle City Post Office'),
('kamlika_silva', 'kamal@456', 'Vavuniya North Post Office'),
('megantha_samarasinghe', 'megantha@789', 'Trincomalee City Post Office'),
('kavindi_rathnayake', 'kavinda@123', 'Matale North Post Office'),
('sumana_silva', 'sumathi@2024', 'Polonnaruwa District Post Office'),
('navman_samarasinghe', 'naveen@456', 'Vavuniya South Post Office'),
('deshi_perera', 'deshika@789', 'Kandy City Post Office'),
('sashi_fernando', 'sarath@1234', 'Matara City Post Office'),
('kaumini_rathnayake', 'kamini@456', 'Badulla North Post Office'),
('sameera_samaralsinghe', 'pradeep@789', 'Vavuniya North Post Office'),
('githa_silva', 'sangeetha@123', 'Kurunegala District Post Office'),
('kanchi_rajapaksha', 'kanchana@456', 'Trincomalee South Post Office'),
('dinusha_wickramasinghe', 'dinesh@789', 'Polonnaruwa North Post Office'),
('shadu_samarasinghe', 'sharmila@2024', 'Kandy South Post Office'),
('prathiba_silva', 'prabha@123', 'Matale South Post Office'),
('lakruwani_fernando', 'kamini@456', 'Badulla South Post Office'),
('mala_wickramasinghe', 'janitha@789', 'Matale District Post Office'),
('malika_rajapaksha', 'shavini@123', 'Kurunegala South Post Office');
SELECT * FROM Users;
INSERT INTO Users (username, password, post_office_name) VALUES
('candi_fernando', 'chaminda@1234', 'Vavuniya North Post Office'),
('athma_rathnayake', 'athma@456', 'Galle District Post Office'),
('thimithri_rajapaksha', 'sumith@pass', 'Kurunegala City Post Office'),
('nilu_silva', 'nilusha@789', 'Polonnaruwa South Post Office'),
('pramu_rathnayake', 'prabath@123', 'Matale City Post Office'),
('pavani_wickramasinghe', 'pavithra@2024', 'Trincomalee District Post Office'),
('ransiluni_dissanayake', 'kamani@pass', 'Badulla City Post Office'),
('jagath_perera', 'janitha@456', 'Jaffna District Post Office'),
('sumana_samarasinghe', 'samanthi@1234', 'Gampaha City Post Office'),
('hiran_fernando', 'hiran@2024', 'Matara District Post Office'),
('sumudu_rajapaksha', 'sumudu@789', 'Vavuniya City Post Office'),
('shaluka_rathnayake', 'shantha@1234', 'Polonnaruwa District Post Office'),
('tharuka_silva', 'tharindu@456', 'Kandy South Post Office'),
('kavindu_wickramasinghe', 'kavinda@123', 'Galle North Post Office'),
('gagani_perera', 'gayani@789', 'Matara South Post Office'),
('keshari_samarasinghe', 'kamali@pass', 'Jaffna South Post Office'),
('hasitha_silva', 'hasitha@1234', 'Trincomalee North Post Office'),
('dulnith_fernando', 'dinesh@456', 'Kurunegala North Post Office'),
('lakshan_rajapaksha', 'pradeep@789', 'Polonnaruwa South Post Office'),
('nalaka_samarasinghe', 'nirmala@123', 'Vavuniya South Post Office'),
('priyamani_rajapaksha', 'priya@pass', 'Matale District Post Office'),
('laksiri_wickramasinghe', 'lasitha@456', 'Galle South Post Office'),
('jayani_rathnayake', 'jayanthi@1234', 'Kandy North Post Office'),
('kumar_fernando', 'kumar@789', 'Vavuniya North Post Office'),
('gelumi_silva', 'geethika@456', 'Polonnaruwa District Post Office'),
('udara_rathnayake', 'udaya@1234', 'Badulla South Post Office'),
('avishka_wickramasinghe', 'nirantha@789', 'Trincomalee South Post Office'),
('avishka_samarasinghe', 'lavinia@123', 'Galle City Post Office'),
('induni_rajapaksha', 'indika@pass', 'Kandy South Post Office'),
('rasika_fernando', 'rasika@2024', 'Vavuniya City Post Office'),
('dev_silva', 'dinesh@456', 'Kurunegala City Post Office'),
('ranjana_rathnayake', 'ranjani@789', 'Galle North Post Office'),
('sahan_fernando', 'sahan@1234', 'Jaffna South Post Office'),
('kithmani_perera', 'kamini@pass', 'Matara North Post Office'),
('sunima_wickramasinghe', 'sunil@456', 'Matale District Post Office'),
('malaka_dissanayake', 'megantha@789', 'Polonnaruwa North Post Office'),
('tasha_rajapaksha', 'tasha@123', 'Trincomalee North Post Office'),
('kasthuri_rathnayake', 'kasuni@2024', 'Badulla District Post Office'),
('narayan_fernando', 'narayan@123', 'Kurunegala District Post Office'),
('uddika_perera', 'uditha@789', 'Gampaha District Post Office'),
('hasira_rajapaksha', 'hasitha@pass', 'Vavuniya South Post Office'),
('chapa_wickramasinghe', 'chandana@456', 'Kandy District Post Office'),
('nimala_samarasinghe', 'nisala@123', 'Galle District Post Office'),
('sasika_fernando', 'nivanka@789', 'Jaffna City Post Office'),
('parami_rathnayake', 'prabodh@2024', 'Matara District Post Office'),
('sanatha_rajapaksha', 'sanath@123', 'Polonnaruwa South Post Office'),
('kalpa_silva', 'kasuni@pass', 'Vavuniya North Post Office'),
('kalpana_rathnayake', 'kamal@789', 'Kandy South Post Office'),
('subhashini_wickramasinghe', 'subhashini@1234', 'Galle North Post Office'),
('dhanushka_fernando', 'dhanushka@456', 'Kurunegala North Post Office'),
('piyath_dissanayake', 'priya@pass', 'Jaffna North Post Office'),
('narinda_rajapaksha', 'narinda@789', 'Matale City Post Office'),
('nipuni_rathnayake', 'kumari@1234', 'Trincomalee City Post Office'),
('chithari_samarasinghe', 'charitha@456', 'Polonnaruwa North Post Office');

INSERT INTO Users (username, password, post_office_name) VALUES
('Shazni_Ahamad', 'password_1234', 'Pannipitiya Post Office'),
('Shiyon_Rishi', 'nila@secret', 'Matale South Post Office'),
('Jonathan', 'uditha@1234', 'Colombo Fort Post Office'),
('Mhommad_Hafeez', 'shamila!@34', 'Kurunegala Post Office'),
('G_Kavin', 'kamala@pass1', 'Jaffna City Post Office'),
('Arthik_Adriyan', 'prabath@456', 'Anuradhapura North Post Office'),
('Pradeep_Daneesh', 'samanthi@890', 'Kandy City Post Office'),
('Aarean_Stain', 'nimesha&123', 'Galle South Post Office'),
('Jarlath_Dion', 'ranjitha$pass', 'Vavuniya City Post Office'),
('Zion_Moses', 'sunil@secure', 'Trincomalee South Post Office'),
('Deeran_Mogath', 'krishantha@123', 'Polonnaruwa District Post Office'),
('S_Ashrithan', 'sumith@4567', 'Badulla City Post Office'),
('C_Clavon', 'lakshani#78', 'Jaffna South Post Office'),
('Lithikesh', 'prashantha$567', 'Matara South Post Office'),
('Adarva_Yash', 'ranjith@2024', 'Kurunegala South Post Office'),
('Shanella_Jerusha', 'chandana_123', 'Kandy North Post Office'),
('Delisha_Hana', 'nivethitha@!23', 'Vavuniya North Post Office'),
('Emana_Marsha', 'kamani@#2024', 'Vavuniya District Post Office'),
('Ayaa', 'buddhi@456', 'Colombo Central Post Office'),
('Dileshan', 'kumari@789', 'Kandy South Post Office'),
('Neluja', 'sharini@pass', 'Kurunegala North Post Office'),
('SNimesha', 'kamala123@456', 'Matale North Post Office'),
('Esada_Ayodya', 'kavindra@pass123', 'Polonnaruwa City Post Office'),
('Shemri_Mariya', 'sudesh@password1', 'Galle North Post Office'),
('B_J_Andrews', 'shashika@1234', 'Trincomalee Post Office'),
('B_J_Alloshiya', 'lakmal!@456', 'Matara City Post Office'),
('S_Julinaa', 'nisala123@789', 'Vavuniya South Post Office'),
('Mani_Das', 'dilanka@secret', 'Polonnaruwa North Post Office'),
('Niyal_Math', 'kamini@secure123', 'Badulla South Post Office'),
('Arvinda_K', 'naveen_123@456', 'Galle District Post Office'),
('Sachithra', 'anushka@secure', 'Matale District Post Office'),
('Amali_Jones', 'manjula@#4567', 'Kandy District Post Office'),
('Trisha', 'sarath@pass', 'Vavuniya District Post Office'),
('Vihan_K', 'devika@123pass', 'Kurunegala City Post Office'),
('Suraksha', 'nivethini@12345', 'Jaffna City Post Office'),
('Akhil_J', 'kamal@6789', 'Polonnaruwa District Post Office'),
('Thilina_K', 'asanka@secure@987', 'Galle South Post Office'),
('Pathum_F', 'udara@5678', 'Matara North Post Office'),
('Harshi_L', 'ranjini@pass123', 'Kurunegala South Post Office'),
('Amira_D', 'kamini!@12', 'Trincomalee City Post Office'),
('Ishan_R', 'kamal@89012', 'Jaffna North Post Office'),
('Anush_M', 'asanka@789@#', 'Vavuniya South Post Office'),
('Samira_K', 'shamini_@1234', 'Galle North Post Office'),
('Tharushi_G', 'chandima@password', 'Colombo South Post Office'),
('Dishan_P', 'nishan@4567', 'Matale South Post Office'),
('Nilushi_W', 'geethani@12345', 'Kandy North Post Office'),
('Rumesh_H', 'kamini@pass2', 'Matara South Post Office'),
('Prasanna_J', 'shanika123@pass', 'Badulla Post Office'),
('Dulanjali_T', 'kamini123@2024', 'Galle City Post Office'),
('Isuri_S', 'nivethitha@pass', 'Vavuniya North Post Office'),
('Udeshi_V', 'samitha@5678', 'Kurunegala City Post Office'),
('Viduranga_Z', 'dinesh@1234secure', 'Jaffna South Post Office'),
('Sumithra_F', 'sadhika!@pass', 'Polonnaruwa South Post Office'),
('Hasara_G', 'tharushi@1234pass', 'Vavuniya City Post Office'),
('Sithija_Y', 'srilanka@secure123', 'Colombo West Post Office'),
('Kishan_B', 'kamal@2024pass', 'Matale City Post Office'),
('Nishadi_H', 'ranjana@45678', 'Galle District Post Office'),
('Chathura_J', 'kamal@7890pass', 'Kurunegala North Post Office');

INSERT INTO Users (username, password, post_office_name) VALUES
('Abinandana', 'abinandana@pass', 'Kandy Post Office'),
('Naamika', 'naamika@pass', 'Galle Main Post Office'),
('Ruyae', 'ruyae@1234', 'Colombo Fort Post Office'),
('Premali', 'premali@secure', 'Kurunegala Post Office'),
('Sanath', 'sanath@5678', 'Jaffna City Post Office'),
('Nimandha', 'nimandha@2024', 'Anuradhapura Post Office'),
('Siriraki', 'siriraki@password', 'Matara Main Post Office'),
('Veerakanda', 'veerakanda@pass', 'Nuwara Eliya Post Office'),
('Piyumi', 'piyumi@4567', 'Batticaloa Post Office'),
('Shersha', 'shersha@pass', 'Ampara City Post Office'),
('Dayalu', 'dayalu@secure', 'Ratnapura Post Office'),
('Ekanā', 'ekana@pass123', 'Polonnaruwa Post Office'),
('Lakshika', 'lakshika@2024', 'Badulla Post Office'),
('Ruseen', 'ruseen@pass', 'Hambantota Main Post Office'),
('Keshavi', 'keshavi@pass', 'Kalutara Post Office'),
('Gunith', 'gunith@secure123', 'Gampaha District Post Office'),
('Chithrika', 'chithrika@567', 'Matale South Post Office'),
('Madhuri', 'madhuri@2024', 'Kilinochchi Post Office'),
('Nilka', 'nilka@pass', 'Monaragala Main Post Office'),
('Senura', 'senura@4567', 'Mannar Post Office'),
('Jigman', 'jigman@secure', 'Trincomalee Post Office'),
('Piyara', 'piyara@pass123', 'Kurunegala South Post Office'),
('Sachitra', 'sachitra@1234', 'Vavuniya Post Office'),
('Sumitra', 'sumitra@pass', 'Kegalle Post Office'),
('Parshan', 'parshan@5678', 'Dehiwala Post Office'),
('Eksaha', 'eksaha@secure', 'Moratuwa Post Office'),
('Niraaya', 'niraaya@password', 'Puttalam Main Post Office'),
('Senadira', 'senadira@1234', 'Negombo Post Office'),
('Karuna', 'karuna@4567', 'Colombo Main Post Office'),
('Mudith', 'mudith@pass', 'Mount Lavinia Post Office'),
('Dewmi', 'dewmi@secure', 'Panadura Post Office'),
('Devnu', 'devnu@1234', 'Wattala Post Office'),
('Deduni', 'deduni@pass123', 'Chilaw Post Office'),
('Deuni', 'deuni@4567', 'Wennappuwa Post Office'),
('Thanuri', 'thanuri@secure', 'Battaramulla Post Office'),
('Danuri', 'danuri@pass', 'Kaduwela Post Office'),
('Manisha', 'manisha@secure', 'Horana Post Office'),
('Lalantha', 'lalantha@password', 'Kadawatha Post Office'),
('Bawantha', 'bawantha@1234', 'Kiribathgoda Post Office'),
('Manuka', 'manuka@5678', 'Homagama Post Office'),
('Manidu', 'manidu@pass', 'Nugegoda Post Office'),
('Nirman', 'nirman@secure', 'Maharagama Post Office'),
('Maleesha', 'maleesha@4567', 'Rajagiriya Post Office'),
('Safi', 'safi@pass', 'Wellawatta Post Office'),
('Zahi', 'zahi@1234', 'Malabe Post Office'),
('Saubagya', 'saubagya@secure', 'Peliyagoda Post Office'),
('Mauni', 'mauni@password', 'Kotikawatta Post Office'),
('Mathru', 'mathru@5678', 'Ragama Post Office');

SELECT * FROM Users;

INSERT INTO Users (username, password, post_office_name) VALUES
('rashmika', 'rashmika@1234', 'Avissawella Post Office'),
('shehan', 'shehan@secure', 'Matale Post Office'),
('sehan', 'sehan@password', 'Ambalangoda Post Office'),
('dula', 'dula@4567', 'Hatton Post Office'),
('dulmini', 'dulmini@pass', 'Piliyandala Post Office'),
('dulmi', 'dulmi@secure', 'Kalmunai Post Office'),
('tiara', 'tiara@pass123', 'Kadugannawa Post Office'),
('sanuka', 'sanuka@2024', 'Seeduwa Post Office'),
('oshani', 'oshani@5678', 'Anamaduwa Post Office'),
('rashmi', 'rashmi@pass', 'Haputale Post Office'),
('kusumawathi', 'kusumawathi@secure', 'Galgamuwa Post Office'),
('lakru', 'lakru@password', 'Deniyaya Post Office'),
('randunu', 'randunu@1234', 'Beruwala Post Office'),
('ravihara', 'ravihara@pass', 'Weeraketiya Post Office'),
('mani', 'mani@2024', 'Pelmadulla Post Office'),
('damsarani', 'damsarani@secure', 'Hakmana Post Office'),
('sithumya', 'sithumya@pass', 'Tissamaharama Post Office'),
('edirivira', 'edirivira@1234', 'Weligama Post Office'),
('malru', 'malru@password', 'Kalutara South Post Office'),
('amalsha', 'amalsha@5678', 'Balangoda Post Office'),
('sakuni', 'sakuni@pass', 'Aluthgama Post Office'),
('senuri', 'senuri@secure', 'Horowpothana Post Office'),
('senumi', 'senumi@1234', 'Madampe Post Office'),
('dulini', 'dulini@password', 'Kamburupitiya Post Office'),
('dinuli', 'dinuli@pass', 'Wellawa Post Office'),
('deshani', 'deshani@secure', 'Elpitiya Post Office'),
('randu', 'randu@4567', 'Negombo South Post Office'),
('thimanshi', 'thimanshi@1234', 'Mirigama Post Office'),
('thathsarani', 'thathsarani@pass', 'Polgahawela Post Office'),
('vindi', 'vindi@secure', 'Kekirawa Post Office'),
('dumidu', 'dumidu@password', 'Panagoda Post Office'),
('nidula', 'nidula@4567', 'Bandarawela Post Office'),
('chamudi', 'chamudi@secure', 'Dehiattakandiya Post Office'),
('dushmanth', 'dushmanth@pass', 'Kantalai Post Office'),
('viduranga', 'viduranga@1234', 'Talawakele Post Office'),
('dulanjana', 'dulanjana@password', 'Wattegama Post Office'),
('anjana', 'anjana@5678', 'Mannar City Post Office'),
('ashini', 'ashini@secure', 'Wariyapola Post Office'),
('divya', 'divya@password', 'Ambagamuwa Post Office'),
('pavithri', 'pavithri@pass', 'Embilipitiya Post Office'),
('savini', 'savini@1234', 'Angunakolapelessa Post Office'),
('chathu', 'chathu@secure', 'Puttalam South Post Office'),
('chathurya', 'chathurya@pass', 'Wadduwa Post Office'),
('samadi', 'samadi@1234', 'Hanwella Post Office'),
('adithya', 'adithya@pass', 'Kataragama Post Office'),
('rajahan', 'rajahan@password', 'Balapitiya Post Office'),
('parakum', 'parakum@secure', 'Hatton South Post Office'),
('uthumi', 'uthumi@pass', 'Yatiyanthota Post Office'),
('tinusha', 'tinusha@4567', 'Mihintale Post Office'),
('malmi', 'malmi@1234', 'Kottawa Post Office'),
('himahansi', 'himahansi@secure', 'Moragahahena Post Office');

INSERT INTO Users (username, password, post_office_name) VALUES
('Amal', 'amal@pass123', 'Kurunegala Main Post Office'),
('Nihal', 'nihal@password', 'Negombo Post Office'),
('Sareen', 'sareen@secure', 'Gampaha Post Office'),
('Sudana', 'sudana@4567', 'Kalutara Post Office'),
('Vimal', 'vimal@1234', 'Ratnapura Post Office'),
('Nihani', 'nihani@pass', 'Colombo Central Post Office'),
('Saraki', 'saraki@2024', 'Kandy City Post Office'),
('Rusee', 'ruseen@secure456', 'Chilaw Post Office'),
('Abhilashmi', 'abhilashmi@7890', 'Matara Post Office'),
('Prameela', 'prameela@password1', 'Anuradhapura Post Office'),
('Nilmil', 'nilmil@secure2', 'Trincomalee Post Office'),
('Dakshina', 'dakshina@pass', 'Hambantota Post Office'),
('Kerul', 'kerul@2024', 'Badulla Post Office'),
('Ashanthi', 'ashanthi@secure', 'Mannar Post Office'),
('Adesh', 'adesh@123', 'Kilinochchi Post Office'),
('Shamee', 'shamee@pass', 'Batticaloa Post Office'),
('Sihini', 'sihini@secure123', 'Nuwara Eliya Post Office'),
('Bhanusiri', 'bhanusiri@2024', 'Galle Post Office'),
('Ranine', 'ranine@pass', 'Puttalam Post Office'),
('Sathkeranee', 'sathkeranee@password', 'Mullaitivu Post Office'),
('Sameera', 'sameera@1234', 'Wattala Post Office'),
('Kumidu', 'kumidu@secure', 'Kegalle Post Office');

INSERT INTO Sellers (name, address, contact_number) VALUES
('Amara Traders', '123 Galle Road, Colombo', '0712345678'),
('Nimal Distributors', '45 Temple Street, Kandy', '0771234567'),
('Sunil Stores', '78 Lake Road, Gampaha', '0709876543'),
('Lanka Wholesale', '56 Market Street, Matara', '0786543210'),
('Pathma Enterprises', '23 Railway Avenue, Jaffna', '0723456789'),
('Herath Supplies', '14 Church Street, Negombo', '0765432109'),
('Thushara Exports', '88 Queen Street, Kurunegala', '0750987654'),
('Fernando & Sons', '67 King Street, Anuradhapura', '0774321098'),
('Priyanka Dealers', '49 Beach Road, Trincomalee', '0711234098'),
('Saman Electronics', '90 High Street, Ratnapura', '0728765432'),
('Jayawardena Traders', '12 Park Avenue, Badulla', '0745678901'),
('Wijesiri Grocers', '33 Flower Road, Hambantota', '0767890123'),
('Silva Retailers', '58 Main Street, Batticaloa', '0796543210'),
('Perera Furniture', '15 Hilltop Drive, Kilinochchi', '0784321098'),
('Ariyawansa Ltd', '21 City Center, Vavuniya', '0703210987'),
('Ruwan Builders', '32 New Town, Polonnaruwa', '0732109876'),
('Kumara Textiles', '74 Union Road, Kalutara', '0756789012'),
('Wimal Supermarket', '19 Coconut Lane, Puttalam', '0723450987'),
('Isuru Ventures', '47 Mountain Road, Nuwara Eliya', '0765432198'),
('Nalani Pharmacy', '60 River Drive, Mullaitivu', '0782109876'),
('Seneviratne Hardware', '25 Forest Avenue, Kegalle', '0798765432'),
('Jaya Industries', '39 East Market, Colombo', '0701234098'),
('Araliya Foods', '65 Maple Street, Kandy', '0716785432'),
('New World Co', '37 Harbor Lane, Galle', '0776547890'),
('Palitha Groceries', '54 Green Lane, Matale', '0758761234'),
('Nisansala Stationery', '13 Lion Square, Kurunegala', '0722345678'),
('Jayalath Beverages', '89 Garden Path, Matara', '0743216543'),
('Ranjith Plastics', '30 Victory Street, Kandy', '0709871234'),
('Wijeratne Paints', '17 Freedom Street, Anuradhapura', '0796547890'),
('Lakshmi Fashions', '40 Prince Avenue, Gampaha', '0787654321'),
('Damayanthi Gems', '77 Ruby Street, Ratnapura', '0764321987'),
('Madura Supermarket', '51 Sunrise Road, Jaffna', '0741230987'),
('Hemantha Woodworks', '26 Spice Road, Kilinochchi', '0753459876'),
('Ravi Construction', '88 Ocean Drive, Batticaloa', '0712108765'),
('Chamila Steel', '42 Star Street, Nuwara Eliya', '0786543212'),
('Ranasinghe Electronics', '15 Rainbow Avenue, Puttalam', '0775432109'),
('Roshan Agri Products', '68 Bloom Street, Mullaitivu', '0798764321'),
('Shantha Textiles', '36 Horizon Lane, Vavuniya', '0730987654'),
('Dinesh Pharma', '99 Maple Street, Colombo', '0723456780'),
('Sarath Imports', '57 Lily Avenue, Galle', '0706543212'),
('Nadeeka Cosmetics', '48 Palm Drive, Badulla', '0761234567'),
('Sumith Accessories', '44 Sunset Boulevard, Kegalle', '0783210987'),
('Upali Office Supplies', '11 Meadow Road, Kurunegala', '0790123456'),
('Amila Printers', '19 Top Hill, Jaffna', '0712348907'),
('Jayasuriya Motor Parts', '34 Windy Street, Kalutara', '0739876543'),
('Gunawardena Fabrics', '82 New Road, Polonnaruwa', '0751237890'),
('Tharaka Tools', '73 North Street, Negombo', '0745678902'),
('Karunaratne Dairy', '23 Rainbow Hill, Hambantota', '0786543211'),
('Shakthi Jewelers', '58 Victory Circle, Vavuniya', '0727890123');

INSERT INTO Sellers (name, address, contact_number) VALUES
('Chamika Traders', '12 Water Lane, Colombo', '0713456789'),
('Harsha Enterprises', '32 Silver Road, Galle', '0778765432'),
('Lakshan Stores', '76 Mango Street, Kandy', '0704321098'),
('Rukmal Distributors', '41 Hill View, Matale', '0785432109'),
('Indika Textiles', '55 Wind Street, Kurunegala', '0726789012'),
('Kalinga Imports', '98 Maple Grove, Ratnapura', '0761230987'),
('Tharanga Wholesalers', '21 Sunset Avenue, Jaffna', '0790987654'),
('Kusal Suppliers', '67 Ocean Path, Gampaha', '0752345678'),
('Dilhara Products', '88 Sandalwood Road, Anuradhapura', '0746543210'),
('Sandunika Ventures', '29 Coconut Grove, Vavuniya', '0734567890'),
('Lasith Supermarket', '33 River Road, Batticaloa', '0789876543'),
('Sajith Traders', '50 New Market Street, Polonnaruwa', '0708765432'),
('Nadeesha Beverages', '45 Horizon Lane, Nuwara Eliya', '0710987654'),
('Hansika Essentials', '20 Palmyrah Path, Kilinochchi', '0774321098'),
('Nishantha Electronics', '11 High Street, Badulla', '0725432109'),
('Shanaka Agro', '85 Lakefront Road, Puttalam', '0792345678'),
('Aruna Retailers', '62 Pepper Avenue, Kurunegala', '0758765432'),
('Jayani Distributors', '47 Queen’s Road, Jaffna', '0730987654'),
('Ranjan Hardware', '72 Orchid Path, Colombo', '0783210987'),
('Sumudu Textiles', '28 Victory Boulevard, Matara', '0776548901'),
('Dilini Enterprises', '33 Coral Street, Negombo', '0703456789'),
('Gamini Steelworks', '56 Palm Drive, Kandy', '0762109876'),
('Mahinda Grocers', '94 Union Square, Galle', '0716543210'),
('Asanka Supplies', '39 East Lake Drive, Hambantota', '0757894321'),
('Madhuka Retail', '60 Grand Avenue, Ratnapura', '0729087654'),
('Wasantha Traders', '84 Red Hill, Colombo', '0790123456'),
('Roshan Distributors', '25 Waterfall Street, Vavuniya', '0782345678'),
('Dilan Supermart', '70 Jasmine Avenue, Matale', '0775432109'),
('Shehan Industries', '14 Amber Drive, Kurunegala', '0736543210'),
('Menaka Exports', '29 Olive Path, Trincomalee', '0728765432'),
('Kasun Essentials', '63 Lion’s Lane, Anuradhapura', '0793456789'),
('Sahan Pharmacy', '78 Heritage Way, Kalutara', '0749876543'),
('Ajantha Supplies', '91 Victory Road, Kegalle', '0704321098'),
('Sumith Timber', '36 Pine Ridge, Polonnaruwa', '0765432109'),
('Ranjith Beverages', '45 Coconut Hill, Puttalam', '0712340987'),
('Lalitha Textiles', '50 Rose Lane, Mullaitivu', '0727890123'),
('Chandana Dealers', '12 Harbour Street, Jaffna', '0775678901'),
('Kamal Steel', '38 City Park, Matale', '0740987654'),
('Ruwan Ventures', '57 Royal Avenue, Kandy', '0732109876'),
('Sajini Distributors', '49 Blossom Path, Galle', '0787654321'),
('Sithara Fashion', '25 Greenway, Colombo', '0790987654'),
('Suranga Exporters', '61 King’s Road, Ratnapura', '0769876543'),
('Dinithi Grocers', '87 Elm Street, Gampaha', '0753210987'),
('Sampath Traders', '43 Highland Avenue, Jaffna', '0725432109'),
('Sunethra Essentials', '55 Fisher Lane, Hambantota', '0774321098'),
('Hemal Enterprises', '77 Riverwalk, Trincomalee', '0793456789'),
('Anura Products', '66 Mountain Drive, Vavuniya', '0730987654'),
('Priyantha Market', '17 Beach Road, Badulla', '0762109876'),
('Upul Stationery', '19 Greenfield, Kalutara', '0788765432'),
('Janaka Hardware', '33 Wood Road, Nuwara Eliya', '0746543210'),
('Padma Exports', '20 Violet Path, Polonnaruwa', '0705678901');

SELECT * FROM Sellers;

ALTER TABLE Sellers
ADD COLUMN to_address TEXT;



UPDATE Sellers
SET to_address = CASE seller_id
    WHEN 1 THEN '123 Blueberry Street, Colombo'
    WHEN 2 THEN '456 Green Road, Kandy'
    WHEN 3 THEN '789 Yellow Lane, Galle'
    WHEN 4 THEN '101 Red Boulevard, Matara'
    WHEN 5 THEN '202 Ocean Drive, Jaffna'
    WHEN 6 THEN '303 Sunset Blvd, Negombo'
    WHEN 7 THEN '404 Pine Street, Kegalle'
    WHEN 8 THEN '505 River Road, Anuradhapura'
    WHEN 9 THEN '606 Maple Avenue, Trincomalee'
    WHEN 10 THEN '707 Oak Lane, Vavuniya'
    WHEN 11 THEN '808 Spring Street, Badulla'
    WHEN 12 THEN '909 Elm Road, Polonnaruwa'
    WHEN 13 THEN '1010 Birch Street, Kalutara'
    WHEN 14 THEN '1111 Cedar Avenue, Matale'
    WHEN 15 THEN '1212 Willow Drive, Kurunegala'
    WHEN 16 THEN '1313 Pine Road, Ratnapura'
    WHEN 17 THEN '1414 Palm Street, Colombo Fort'
    WHEN 18 THEN '1515 Jasmine Lane, Galle South'
    WHEN 19 THEN '1616 Orchid Road, Kandy City'
    WHEN 20 THEN '1717 Tulip Blvd, Jaffna City'
    WHEN 21 THEN '1818 Lily Street, Kandy North'
    WHEN 22 THEN '1919 Rose Avenue, Gampaha'
    WHEN 23 THEN '2020 Violet Road, Matara'
    WHEN 24 THEN '2121 Daisy Street, Vavuniya City'
    WHEN 25 THEN '2222 Jasmine Drive, Colombo West'
    WHEN 26 THEN '2323 Lavender Lane, Trincomalee City'
    WHEN 27 THEN '2424 Sunflower Avenue, Badulla'
    WHEN 28 THEN '2525 Dahlia Road, Ratnapura City'
    WHEN 29 THEN '2626 Hydrangea Boulevard, Kegalle'
    WHEN 30 THEN '2727 Orchid Avenue, Polonnaruwa South'
    WHEN 31 THEN '2828 Marigold Street, Vavuniya North'
    WHEN 32 THEN '2929 Poppy Road, Galle District'
    WHEN 33 THEN '3030 Azalea Lane, Matale North'
    WHEN 34 THEN '3131 Cosmos Street, Anuradhapura South'
    WHEN 35 THEN '3232 Lily Blvd, Colombo South'
    WHEN 36 THEN '3333 Iris Road, Jaffna North'
    WHEN 37 THEN '3434 Carnation Avenue, Kurunegala South'
    WHEN 38 THEN '3535 Gardenia Street, Trincomalee South'
    WHEN 39 THEN '3636 Sunflower Lane, Matara South'
    WHEN 40 THEN '3737 Cactus Boulevard, Polonnaruwa North'
    WHEN 41 THEN '3838 Fern Road, Kandy District'
    WHEN 42 THEN '3939 Magnolia Street, Galle South'
    WHEN 43 THEN '4040 Lilac Avenue, Vavuniya South'
    WHEN 44 THEN '4141 Ivy Lane, Colombo East'
    WHEN 45 THEN '4242 Azalea Road, Gampaha'
    WHEN 46 THEN '4343 Marigold Street, Badulla'
    WHEN 47 THEN '4444 Hibiscus Blvd, Anuradhapura'
    WHEN 48 THEN '4545 Jasmine Road, Colombo North'
    WHEN 49 THEN '4646 Orchid Street, Kurunegala North'
    WHEN 50 THEN '4747 Rose Avenue, Trincomalee North'
    ELSE to_address
END;
SELECT seller_id, to_address FROM Sellers;

UPDATE Sellers s
SET to_address = CASE
    WHEN u.post_office_name = 'Colombo Fort Post Office' THEN '45 Sea Breeze Road, Colombo'
    WHEN u.post_office_name = 'Matale South Post Office' THEN '212 Coastal Road, Matale'
    WHEN u.post_office_name = 'Jaffna City Post Office' THEN '765 Riverside Drive, Jaffna'
    WHEN u.post_office_name = 'Galle South Post Office' THEN '99 Coral Lane, Galle'
    WHEN u.post_office_name = 'Kurunegala Post Office' THEN '23 Lakeview Terrace, Kurunegala'
    WHEN u.post_office_name = 'Badulla Post Office' THEN '88 Mountain Peak Road, Badulla'
    WHEN u.post_office_name = 'Anuradhapura Post Office' THEN '123 Ancient City Road, Anuradhapura'
    WHEN u.post_office_name = 'Polonnaruwa Post Office' THEN '150 Heritage Way, Polonnaruwa'
    WHEN u.post_office_name = 'Kandy City Post Office' THEN '34 Temple Road, Kandy'
    WHEN u.post_office_name = 'Trincomalee Post Office' THEN '45 Oceanic Avenue, Trincomalee'
    WHEN u.post_office_name = 'Vavuniya Post Office' THEN '67 Tranquil Valley Road, Vavuniya'
    WHEN u.post_office_name = 'Matara South Post Office' THEN '29 Southern Boulevard, Matara'
    WHEN u.post_office_name = 'Galle North Post Office' THEN '12 Blue Wave Lane, Galle'
    WHEN u.post_office_name = 'Jaffna South Post Office' THEN '501 North Street, Jaffna'
    WHEN u.post_office_name = 'Ratnapura Post Office' THEN '76 Gemstone Road, Ratnapura'
    WHEN u.post_office_name = 'Mannar Post Office' THEN '543 Seaside Drive, Mannar'
    WHEN u.post_office_name = 'Hambantota Post Office' THEN '98 Sand Dunes Road, Hambantota'
    WHEN u.post_office_name = 'Batticaloa Post Office' THEN '27 Lagoon Road, Batticaloa'
    WHEN u.post_office_name = 'Kegalle Post Office' THEN '22 Waterfall Avenue, Kegalle'
    WHEN u.post_office_name = 'Nuwara Eliya Post Office' THEN '64 Misty Hills, Nuwara Eliya'
    WHEN u.post_office_name = 'Mullaitivu Post Office' THEN '58 Serene Road, Mullaitivu'
    WHEN u.post_office_name = 'Ampara Post Office' THEN '111 Sunrise Lane, Ampara'
    WHEN u.post_office_name = 'Kalutara Post Office' THEN '89 Beachside Avenue, Kalutara'
    WHEN u.post_office_name = 'Negombo Post Office' THEN '200 Fishermen’s Path, Negombo'
    WHEN u.post_office_name = 'Ratnapura North Post Office' THEN '85 Royal Road, Ratnapura'
    WHEN u.post_office_name = 'Kandy North Post Office' THEN '10 Royal Avenue, Kandy'
    WHEN u.post_office_name = 'Galle District Post Office' THEN '103 Coastal Breeze Road, Galle'
    WHEN u.post_office_name = 'Colombo South Post Office' THEN '18 Sunset Boulevard, Colombo'
    WHEN u.post_office_name = 'Polonnaruwa North Post Office' THEN '67 Riverbank Road, Polonnaruwa'
    WHEN u.post_office_name = 'Badulla South Post Office' THEN '202 Eastern Road, Badulla'
    WHEN u.post_office_name = 'Jaffna District Post Office' THEN '300 Eastern Lane, Jaffna'
    WHEN u.post_office_name = 'Vavuniya District Post Office' THEN '45 District Avenue, Vavuniya'
    WHEN u.post_office_name = 'Gampaha Post Office' THEN '34 Green Park Road, Gampaha'
    WHEN u.post_office_name = 'Kilinochchi Post Office' THEN '67 Freedom Road, Kilinochchi'
    WHEN u.post_office_name = 'Kurunegala North Post Office' THEN '89 Mountain View Road, Kurunegala'
    WHEN u.post_office_name = 'Colombo Central Post Office' THEN '123 Main Street, Colombo'
    WHEN u.post_office_name = 'Matale City Post Office' THEN '432 Greenway, Matale'
    WHEN u.post_office_name = 'Anuradhapura North Post Office' THEN '654 Ancient Road, Anuradhapura'
    WHEN u.post_office_name = 'Trincomalee North Post Office' THEN '34 Pearl Bay Road, Trincomalee'
    WHEN u.post_office_name = 'Vavuniya South Post Office' THEN '55 Sunrise Road, Vavuniya'
    WHEN u.post_office_name = 'Kandy South Post Office' THEN '88 River Lane, Kandy'
    WHEN u.post_office_name = 'Matara North Post Office' THEN '222 Ocean Avenue, Matara'
    WHEN u.post_office_name = 'Jaffna North Post Office' THEN '99 Northern Way, Jaffna'
    WHEN u.post_office_name = 'Polonnaruwa South Post Office' THEN '321 Heritage Road, Polonnaruwa'
    WHEN u.post_office_name = 'Galle City Post Office' THEN '12 Coral View Road, Galle'
    WHEN u.post_office_name = 'Badulla City Post Office' THEN '233 Mountain Road, Badulla'
    WHEN u.post_office_name = 'Nuwara Eliya District Post Office' THEN '77 Evergreen Street, Nuwara Eliya'
    WHEN u.post_office_name = 'Ratnapura City Post Office' THEN '99 City Park Avenue, Ratnapura'
    WHEN u.post_office_name = 'Matale North Post Office' THEN '88 Forest Hill Road, Matale'
    WHEN u.post_office_name = 'Galle South Post Office' THEN '55 Ocean Breeze Road, Galle'
    WHEN u.post_office_name = 'Kandy City Post Office' THEN '444 Lakeside Road, Kandy'
    ELSE 'Unknown Address'
END
FROM Users u
WHERE s.seller_id = u.user_id;

UPDATE Sellers
SET to_address = NULL
WHERE seller_id = 1; 

UPDATE Sellers
SET to_address = NULL;

ALTER TABLE Sellers
ADD COLUMN destination_PO VARCHAR(40);

UPDATE Sellers
SET to_address = CASE seller_id
    WHEN 1 THEN '123 Blueberry Street, Colombo'
    WHEN 2 THEN '456 Green Road, Kandy'
    WHEN 3 THEN '789 Yellow Lane, Galle'
    WHEN 4 THEN '101 Red Boulevard, Matara'
    WHEN 5 THEN '202 Ocean Drive, Jaffna'
    WHEN 6 THEN '303 Sunset Blvd, Negombo'
    WHEN 7 THEN '404 Pine Street, Kegalle'
    WHEN 8 THEN '505 River Road, Anuradhapura'
    WHEN 9 THEN '606 Maple Avenue, Trincomalee'
    WHEN 10 THEN '707 Oak Lane, Vavuniya'
    WHEN 11 THEN '808 Spring Street, Badulla'
    WHEN 12 THEN '909 Elm Road, Polonnaruwa'
    WHEN 13 THEN '1010 Birch Street, Kalutara'
    WHEN 14 THEN '1111 Cedar Avenue, Matale'
    WHEN 15 THEN '1212 Willow Drive, Kurunegala'
    WHEN 16 THEN '1313 Pine Road, Ratnapura'
    WHEN 17 THEN '1414 Palm Street, Colombo Fort'
    WHEN 18 THEN '1515 Jasmine Lane, Galle South'
    WHEN 19 THEN '1616 Orchid Road, Kandy City'
    WHEN 20 THEN '1717 Tulip Blvd, Jaffna City'
    WHEN 21 THEN '1818 Lily Street, Kandy North'
    WHEN 22 THEN '1919 Rose Avenue, Gampaha'
    WHEN 23 THEN '2020 Violet Road, Matara'
    WHEN 24 THEN '2121 Daisy Street, Vavuniya City'
    WHEN 25 THEN '2222 Jasmine Drive, Colombo West'
    WHEN 26 THEN '2323 Lavender Lane, Trincomalee City'
    WHEN 27 THEN '2424 Sunflower Avenue, Badulla'
    WHEN 28 THEN '2525 Dahlia Road, Ratnapura City'
    WHEN 29 THEN '2626 Hydrangea Boulevard, Kegalle'
    WHEN 30 THEN '2727 Orchid Avenue, Polonnaruwa South'
    WHEN 31 THEN '2828 Marigold Street, Vavuniya North'
    WHEN 32 THEN '2929 Poppy Road, Galle District'
    WHEN 33 THEN '3030 Azalea Lane, Matale North'
    WHEN 34 THEN '3131 Cosmos Street, Anuradhapura South'
    WHEN 35 THEN '3232 Lily Blvd, Colombo South'
    WHEN 36 THEN '3333 Iris Road, Jaffna North'
    WHEN 37 THEN '3434 Carnation Avenue, Kurunegala South'
    WHEN 38 THEN '3535 Gardenia Street, Trincomalee South'
    WHEN 39 THEN '3636 Sunflower Lane, Matara South'
    WHEN 40 THEN '3737 Cactus Boulevard, Polonnaruwa North'
    WHEN 41 THEN '3838 Fern Road, Kandy District'
    WHEN 42 THEN '3939 Magnolia Street, Galle South'
    WHEN 43 THEN '4040 Lilac Avenue, Vavuniya South'
    WHEN 44 THEN '4141 Ivy Lane, Colombo East'
    WHEN 45 THEN '4242 Azalea Road, Gampaha'
    WHEN 46 THEN '4343 Marigold Street, Badulla'
    WHEN 47 THEN '4444 Hibiscus Blvd, Anuradhapura'
    WHEN 48 THEN '4545 Jasmine Road, Colombo North'
    WHEN 49 THEN '4646 Orchid Street, Kurunegala North'
    WHEN 50 THEN '4747 Rose Avenue, Trincomalee North'
    ELSE to_address
END;


UPDATE Sellers
SET destination_PO = CASE seller_id
    WHEN 1 THEN 'Colombo Central Post Office'
    WHEN 2 THEN 'Kandy City Post Office'
    WHEN 3 THEN 'Galle South Post Office'
    WHEN 4 THEN 'Matara City Post Office'
    WHEN 5 THEN 'Jaffna Central Post Office'
    WHEN 6 THEN 'Negombo Post Office'
    WHEN 7 THEN 'Kegalle City Post Office'
    WHEN 8 THEN 'Anuradhapura Post Office'
    WHEN 9 THEN 'Trincomalee Post Office'
    WHEN 10 THEN 'Vavuniya City Post Office'
    WHEN 11 THEN 'Badulla City Post Office'
    WHEN 12 THEN 'Polonnaruwa City Post Office'
    WHEN 13 THEN 'Kalutara City Post Office'
    WHEN 14 THEN 'Matale City Post Office'
    WHEN 15 THEN 'Kurunegala City Post Office'
    WHEN 16 THEN 'Ratnapura Post Office'
    WHEN 17 THEN 'Colombo Fort Post Office'
    WHEN 18 THEN 'Galle South Post Office'
    WHEN 19 THEN 'Kandy Central Post Office'
    WHEN 20 THEN 'Jaffna City Post Office'
    WHEN 21 THEN 'Kandy North Post Office'
    WHEN 22 THEN 'Gampaha Post Office'
    WHEN 23 THEN 'Matara North Post Office'
    WHEN 24 THEN 'Vavuniya City Post Office'
    WHEN 25 THEN 'Colombo West Post Office'
    WHEN 26 THEN 'Trincomalee City Post Office'
    WHEN 27 THEN 'Badulla Post Office'
    WHEN 28 THEN 'Ratnapura City Post Office'
    WHEN 29 THEN 'Kegalle Post Office'
    WHEN 30 THEN 'Polonnaruwa South Post Office'
    WHEN 31 THEN 'Vavuniya North Post Office'
    WHEN 32 THEN 'Galle District Post Office'
    WHEN 33 THEN 'Matale North Post Office'
    WHEN 34 THEN 'Anuradhapura South Post Office'
    WHEN 35 THEN 'Colombo South Post Office'
    WHEN 36 THEN 'Jaffna North Post Office'
    WHEN 37 THEN 'Kurunegala South Post Office'
    WHEN 38 THEN 'Trincomalee South Post Office'
    WHEN 39 THEN 'Matara South Post Office'
    WHEN 40 THEN 'Polonnaruwa North Post Office'
    WHEN 41 THEN 'Kandy District Post Office'
    WHEN 42 THEN 'Galle South Post Office'
    WHEN 43 THEN 'Vavuniya South Post Office'
    WHEN 44 THEN 'Colombo East Post Office'
    WHEN 45 THEN 'Gampaha Post Office'
    WHEN 46 THEN 'Badulla Post Office'
    WHEN 47 THEN 'Anuradhapura Post Office'
    WHEN 48 THEN 'Colombo North Post Office'
    WHEN 49 THEN 'Kurunegala North Post Office'
    WHEN 50 THEN 'Trincomalee North Post Office'
	WHEN 51 THEN 'Kandy City Post Office'
    WHEN 52 THEN 'Gampaha Central Post Office'
    WHEN 53 THEN 'Badulla City Post Office'
    WHEN 54 THEN 'Kurunegala Post Office'
    WHEN 55 THEN 'Matara South Post Office'
    WHEN 56 THEN 'Polonnaruwa Post Office'
    WHEN 57 THEN 'Kegalle City Post Office'
    WHEN 58 THEN 'Trincomalee Post Office'
    WHEN 59 THEN 'Vavuniya City Post Office'
    WHEN 60 THEN 'Anuradhapura Central Post Office'
    WHEN 61 THEN 'Colombo East Post Office'
    WHEN 62 THEN 'Jaffna City Post Office'
    WHEN 63 THEN 'Matale North Post Office'
    WHEN 64 THEN 'Ratnapura Post Office'
    WHEN 65 THEN 'Galle Central Post Office'
    WHEN 66 THEN 'Kandy District Post Office'
    WHEN 67 THEN 'Kurunegala South Post Office'
    WHEN 68 THEN 'Polonnaruwa City Post Office'
    WHEN 69 THEN 'Colombo West Post Office'
    WHEN 70 THEN 'Badulla Central Post Office'
    WHEN 71 THEN 'Gampaha District Post Office'
    WHEN 72 THEN 'Vavuniya South Post Office'
    WHEN 73 THEN 'Trincomalee North Post Office'
    WHEN 74 THEN 'Kegalle North Post Office'
    WHEN 75 THEN 'Kurunegala Central Post Office'
    WHEN 76 THEN 'Polonnaruwa North Post Office'
    WHEN 77 THEN 'Galle South Post Office'
    WHEN 78 THEN 'Kandy South Post Office'
    WHEN 79 THEN 'Matara South Post Office'
    WHEN 80 THEN 'Anuradhapura City Post Office'
    WHEN 81 THEN 'Vavuniya District Post Office'
    WHEN 82 THEN 'Colombo South Post Office'
    WHEN 83 THEN 'Galle North Post Office'
    WHEN 84 THEN 'Ratnapura City Post Office'
    WHEN 85 THEN 'Kandy North Post Office'
    WHEN 86 THEN 'Jaffna Central Post Office'
    WHEN 87 THEN 'Matale City Post Office'
    WHEN 88 THEN 'Polonnaruwa South Post Office'
    WHEN 89 THEN 'Kurunegala South Post Office'
    WHEN 90 THEN 'Kandy East Post Office'
    WHEN 91 THEN 'Vavuniya North Post Office'
    WHEN 92 THEN 'Galle South Post Office'
    WHEN 93 THEN 'Trincomalee Central Post Office'
    WHEN 94 THEN 'Polonnaruwa East Post Office'
    WHEN 95 THEN 'Matara North Post Office'
    WHEN 96 THEN 'Badulla South Post Office'
    WHEN 97 THEN 'Kandy East Post Office'
    WHEN 98 THEN 'Gampaha Central Post Office'
    WHEN 99 THEN 'Vavuniya South Post Office'
    WHEN 100 THEN 'Ratnapura North Post Office'
    ELSE destination_PO
END;

UPDATE Sellers
SET to_address = CASE seller_id
    WHEN 51 THEN '4855 Dahlia Street, Kandy'
    WHEN 52 THEN '4966 Violet Road, Gampaha'
    WHEN 53 THEN '5077 Lavender Blvd, Badulla'
    WHEN 54 THEN '5188 Jasmine Crescent, Kurunegala'
    WHEN 55 THEN '5299 Sunflower Lane, Matara'
    WHEN 56 THEN '5400 Marigold Ave, Polonnaruwa'
    WHEN 57 THEN '5511 Iris Road, Kegalle'
    WHEN 58 THEN '5622 Cosmos Drive, Trincomalee'
    WHEN 59 THEN '5733 Magnolia Lane, Vavuniya'
    WHEN 60 THEN '5844 Fern Boulevard, Anuradhapura'
    WHEN 61 THEN '5955 Camellia Street, Colombo East'
    WHEN 62 THEN '6066 Gardenia Road, Jaffna'
    WHEN 63 THEN '6177 Hydrangea Lane, Matale'
    WHEN 64 THEN '6288 Poppy Street, Ratnapura'
    WHEN 65 THEN '6399 Azalea Road, Galle'
    WHEN 66 THEN '6500 Cosmos Street, Kandy'
    WHEN 67 THEN '6611 Orchid Blvd, Kurunegala South'
    WHEN 68 THEN '6722 Carnation Avenue, Polonnaruwa'
    WHEN 69 THEN '6833 Dahlia Road, Colombo West'
    WHEN 70 THEN '6944 Poppy Avenue, Badulla'
    WHEN 71 THEN '7055 Ivy Boulevard, Gampaha'
    WHEN 72 THEN '7166 Hibiscus Lane, Vavuniya'
    WHEN 73 THEN '7277 Rose Crescent, Trincomalee'
    WHEN 74 THEN '7388 Cosmos Blvd, Kegalle'
    WHEN 75 THEN '7499 Jasmine Road, Kurunegala'
    WHEN 76 THEN '7600 Sunflower Lane, Polonnaruwa'
    WHEN 77 THEN '7711 Marigold Blvd, Galle'
    WHEN 78 THEN '7822 Cactus Avenue, Kandy'
    WHEN 79 THEN '7933 Cosmos Road, Matara'
    WHEN 80 THEN '8044 Orchid Boulevard, Anuradhapura'
    WHEN 81 THEN '8155 Iris Lane, Vavuniya'
    WHEN 82 THEN '8266 Hydrangea Avenue, Colombo South'
    WHEN 83 THEN '8377 Magnolia Road, Galle South'
    WHEN 84 THEN '8488 Azalea Crescent, Ratnapura'
    WHEN 85 THEN '8599 Fern Lane, Kandy North'
    WHEN 86 THEN '8700 Orchid Street, Jaffna'
    WHEN 87 THEN '8811 Camellia Road, Matale North'
    WHEN 88 THEN '8922 Gardenia Lane, Polonnaruwa South'
    WHEN 89 THEN '9033 Lavender Road, Kurunegala South'
    WHEN 90 THEN '9144 Sunflower Blvd, Kandy South'
    WHEN 91 THEN '9255 Poppy Boulevard, Vavuniya South'
    WHEN 92 THEN '9366 Hydrangea Boulevard, Colombo North'
    WHEN 93 THEN '9477 Camellia Crescent, Matara North'
    WHEN 94 THEN '9588 Azalea Blvd, Galle South'
    WHEN 95 THEN '9699 Orchid Crescent, Polonnaruwa South'
    WHEN 96 THEN '9800 Marigold Road, Badulla South'
    WHEN 97 THEN '9911 Lily Street, Kandy East'
    WHEN 98 THEN '10022 Fern Boulevard, Gampaha'
    WHEN 99 THEN '10133 Sunflower Lane, Vavuniya North'
    WHEN 100 THEN '10244 Jasmine Avenue, Ratnapura South'
    ELSE to_address
END;

INSERT INTO Sellers (name, address, contact_number, to_address, destination_PO)
VALUES
    ('Nandana Silva', 'No 17, Garden Road, Colombo 04', '0712345678', '123 Ocean Drive, Colombo', 'Colombo 04 Post Office'),
    ('Rashika Perera', '45A, Temple Road, Kandy', '0723456789', '456 Green Lane, Kandy', 'Kandy City Post Office'),
    ('Ruwanthi Jayasinghe', '12, Hilltop, Matara', '0734567890', '789 Sunrise Blvd, Matara', 'Matara South Post Office'),
    ('Kasuni Perera', '78, Lake Road, Galle', '0745678901', '101 Blueberry Crescent, Galle', 'Galle City Post Office'),
    ('Priyanthi Fernando', '20, Riverside Avenue, Jaffna', '0756789012', '202 Ocean Drive, Jaffna', 'Jaffna Central Post Office'),
    ('Chaminda Gunaratne', '7, Sunset Park, Anuradhapura', '0767890123', '303 Sunset Blvd, Anuradhapura', 'Anuradhapura City Post Office'),
    ('Deepika Wijesuriya', '9, Mango Grove, Polonnaruwa', '0778901234', '404 Palm Street, Polonnaruwa', 'Polonnaruwa Post Office'),
    ('Mihiri Perera', '6, Lotus Road, Kegalle', '0789012345', '505 Orchid Avenue, Kegalle', 'Kegalle City Post Office'),
    ('Saman Jayalath', '18, Royal Gardens, Matale', '0790123456', '606 Lily Lane, Matale', 'Matale District Post Office'),
    ('Nilani Samarasinghe', '10, Coral Street, Kurunegala', '0712345678', '707 Jasmine Blvd, Kurunegala', 'Kurunegala South Post Office'),
    ('Kanchana Dissanayake', '25, Coconut Grove, Ratnapura', '0723456789', '808 Ivy Street, Ratnapura', 'Ratnapura Post Office'),
    ('Nuwan Fernando', '32, Sapphire Road, Vavuniya', '0734567890', '909 Dahlia Blvd, Vavuniya', 'Vavuniya North Post Office'),
    ('Pavithra Kumari', '50, Moonlight Avenue, Galle', '0745678901', '1010 Cosmos Drive, Galle', 'Galle North Post Office'),
    ('Sandeepa Maduranga', '40, Mountain Road, Kandy', '0756789012', '1111 Jasmine Crescent, Kandy', 'Kandy North Post Office'),
    ('Nadeesha Kumari', '28, Palm Garden, Badulla', '0767890123', '1212 Lavender Road, Badulla', 'Badulla Post Office'),
    ('Sarath Abeywardena', '19, Greenfield Road, Colombo', '0778901234', '1313 Marigold Blvd, Colombo', 'Colombo 07 Post Office'),
    ('Anusha Wijesuriya', '11, Sunrise Road, Gampaha', '0789012345', '1414 Tulip Street, Gampaha', 'Gampaha District Post Office'),
    ('Kusal Senanayake', '14, Ocean View, Negombo', '0790123456', '1515 Orchid Avenue, Negombo', 'Negombo Post Office'),
    ('Mihira Dinesh', '23, Mountain Top, Anuradhapura', '0701234567', '1616 Rose Street, Anuradhapura', 'Anuradhapura North Post Office'),
    ('Sanduni Pathirana', '17, Lake View, Kegalle', '0712345678', '1717 Gardenia Road, Kegalle', 'Kegalle South Post Office'),
    ('Buddhika Rajapaksa', '5, Pine Tree Lane, Matara', '0723456789', '1818 Orchid Road, Matara', 'Matara North Post Office'),
    ('Lihini Perera', '30, Sunshine Hill, Polonnaruwa', '0734567890', '1919 Poppy Blvd, Polonnaruwa', 'Polonnaruwa City Post Office'),
    ('Sahan Weerasinghe', '13, Rose Avenue, Colombo', '0745678901', '2020 Jasmine Crescent, Colombo', 'Colombo East Post Office'),
    ('Chathuri Jayasekara', '8, Sunrise Road, Galle', '0756789012', '2121 Ivy Avenue, Galle', 'Galle South Post Office'),
    ('Niranjan Wijesekera', '35, Hill View, Kurunegala', '0767890123', '2222 Sunflower Road, Kurunegala', 'Kurunegala District Post Office'),
    ('Dinesh Fernando', '2, Jasmine Avenue, Vavuniya', '0778901234', '2323 Lily Blvd, Vavuniya', 'Vavuniya City Post Office'),
    ('Tharindu Kumarasinghe', '12, Blue Sky Lane, Matale', '0789012345', '2424 Cosmos Avenue, Matale', 'Matale City Post Office'),
    ('Ravindu Dissanayake', '21, Mango Lane, Ratnapura', '0790123456', '2525 Poppy Street, Ratnapura', 'Ratnapura City Post Office'),
    ('Dinushi Perera', '44, River Road, Kandy', '0701234567', '2626 Jasmine Blvd, Kandy', 'Kandy South Post Office'),
    ('Sanjeewa Wijeratne', '50, Greenfield Road, Colombo', '0712345678', '2727 Fern Street, Colombo', 'Colombo 03 Post Office'),
    ('Vihanga Fernando', '16, Sunset Blvd, Jaffna', '0723456789', '2828 Rose Avenue, Jaffna', 'Jaffna South Post Office'),
    ('Chamari Senaratne', '8, Orchid Garden, Polonnaruwa', '0734567890', '2929 Marigold Blvd, Polonnaruwa', 'Polonnaruwa South Post Office'),
    ('Sanath Jayasuriya', '32, River View, Vavuniya', '0745678901', '3030 Sunflower Road, Vavuniya', 'Vavuniya North Post Office'),
    ('Ruwani Weerasinghe', '14, Coral Reef, Galle', '0756789012', '3131 Lavender Street, Galle', 'Galle Central Post Office'),
    ('Vimukthi Rajapakse', '18, Sunset Park, Matara', '0767890123', '3232 Ivy Road, Matara', 'Matara City Post Office'),
    ('Nadeesha Gunawardena', '27, River Side, Anuradhapura', '0778901234', '3333 Gardenia Crescent, Anuradhapura', 'Anuradhapura South Post Office'),
    ('Chandima Perera', '6, Ocean View, Colombo', '0789012345', '3434 Tulip Road, Colombo', 'Colombo 05 Post Office'),
    ('Lahiru Jayasuriya', '22, Mango Tree, Kandy', '0790123456', '3535 Sunflower Blvd, Kandy', 'Kandy Central Post Office'),
    ('Hiruni Wijesuriya', '11, Sunrise Road, Badulla', '0701234567', '3636 Marigold Crescent, Badulla', 'Badulla North Post Office'),
    ('Teshan Kumara', '4, Rose Avenue, Polonnaruwa', '0712345678', '3737 Poppy Road, Polonnaruwa', 'Polonnaruwa East Post Office'),
    ('Kasun Rajapaksa', '12, Bluebell Lane, Kurunegala', '0723456789', '3838 Violet Street, Kurunegala', 'Kurunegala North Post Office'),
    ('Indika Perera', '35, Ocean Park, Matale', '0734567890', '3939 Jasmine Avenue, Matale', 'Matale District Post Office'),
    ('Kavisha Pathirana', '9, Sunset Hill, Jaffna', '0745678901', '4040 Gardenia Road, Jaffna', 'Jaffna North Post Office'),
    ('Dhanushka Weerasinghe', '21, Coral Street, Colombo', '0756789012', '4141 Dahlia Blvd, Colombo', 'Colombo West Post Office'),
    ('Kavinda Kumara', '18, Sapphire Road, Anuradhapura', '0767890123', '4242 Cosmos Blvd, Anuradhapura', 'Anuradhapura North Post Office'),
    ('Sashini Jayasinghe', '8, Palm Grove, Matara', '0778901234', '4343 Sunflower Crescent, Matara', 'Matara South Post Office'),
    ('Tharindu Dissanayake', '4, Royal Avenue, Galle', '0789012345', '4444 Azalea Street, Galle', 'Galle South Post Office'),
    ('Ashani Kumari', '15, Mango Park, Kurunegala', '0790123456', '4545 Violet Road, Kurunegala', 'Kurunegala East Post Office');

	INSERT INTO Sellers (name, address, contact_number, to_address, destination_PO)
VALUES
    ('Ajith Kumara', '10, Kings Road, Colombo 06', '0713456789', '123 Sunset Blvd, Colombo', 'Colombo 06 Post Office'),
    ('Sulochana Fernando', '21, Lotus Pond, Gampaha', '0724567890', '456 Orchid Avenue, Gampaha', 'Gampaha Central Post Office'),
    ('Vithya Selvarajah', '5, Waterfall Street, Jaffna', '0735678901', '789 Jasmine Drive, Jaffna', 'Jaffna District Post Office'),
    ('Chathura Perera', '14, Green Hill, Kurunegala', '0746789012', '1010 Fern Road, Kurunegala', 'Kurunegala Central Post Office'),
    ('Dulani Jayasinghe', '22, Riverbank, Badulla', '0757890123', '1111 Violet Blvd, Badulla', 'Badulla City Post Office'),
    ('Kasun Madhushanka', '13, Crystal Avenue, Matale', '0768901234', '1212 Poppy Crescent, Matale', 'Matale Post Office'),
    ('Anushka Gunaratne', '8, Emerald Road, Trincomalee', '0779012345', '1313 Sunflower Avenue, Trincomalee', 'Trincomalee Post Office'),
    ('Sumudu Wijesuriya', '33, Coral Reef, Vavuniya', '0780123456', '1414 Gardenia Street, Vavuniya', 'Vavuniya District Post Office'),
    ('Tharanga De Silva', '17, Mango Avenue, Kandy', '0791234567', '1515 Jasmine Road, Kandy', 'Kandy City Post Office'),
    ('Dilani Rathnayake', '40, Tulip Lane, Galle', '0702345678', '1616 Rose Crescent, Galle', 'Galle Central Post Office'),
    ('Nimasha Seneviratne', '27, Beachside, Jaffna', '0713456789', '1717 Lavender Blvd, Jaffna', 'Jaffna North Post Office'),
    ('Suren Perera', '14, Willow Park, Colombo 07', '0724567890', '1818 Azalea Lane, Colombo', 'Colombo 07 Post Office'),
    ('Priyanka Wijesinghe', '33, Sunset Road, Gampaha', '0735678901', '1919 Sunflower Blvd, Gampaha', 'Gampaha North Post Office'),
    ('Vijayakumar Thiruchenthil', '5, Palm Grove, Polonnaruwa', '0746789012', '2020 Lotus Avenue, Polonnaruwa', 'Polonnaruwa Post Office'),
    ('Ruwan Perera', '9, Rainbow Lane, Ratnapura', '0757890123', '2121 Jasmine Crescent, Ratnapura', 'Ratnapura North Post Office'),
    ('Kanchana Fernando', '11, Orchid Road, Matara', '0768901234', '2222 Poppy Blvd, Matara', 'Matara Central Post Office'),
    ('Mihiri Kaluarachchi', '13, Cherry Blossom Street, Kurunegala', '0779012345', '2323 Cosmos Road, Kurunegala', 'Kurunegala South Post Office'),
    ('Indira Sumanasiri', '21, White Sands, Anuradhapura', '0780123456', '2424 Magnolia Avenue, Anuradhapura', 'Anuradhapura South Post Office'),
    ('Sunethra Perera', '7, Oceanic Lane, Galle', '0791234567', '2525 Lily Road, Galle', 'Galle South Post Office'),
    ('Mahesh Perera', '16, Waterfall Street, Kandy', '0702345678', '2626 Rose Avenue, Kandy', 'Kandy Post Office'),
    ('Kavinda Kumara', '8, Coconut Grove, Matale', '0713456789', '2727 Jasmine Street, Matale', 'Matale North Post Office'),
    ('Pavithra Rajapaksa', '28, Sapphire Hill, Badulla', '0724567890', '2828 Lavender Crescent, Badulla', 'Badulla South Post Office'),
    ('Anusha Seneviratne', '12, Silver Road, Vavuniya', '0735678901', '2929 Lily Lane, Vavuniya', 'Vavuniya East Post Office'),
    ('Kasun Udugama', '21, Ocean Breeze, Jaffna', '0746789012', '3030 Gardenia Road, Jaffna', 'Jaffna Central Post Office'),
    ('Samantha Bandara', '8, Mango Tree Lane, Colombo 03', '0757890123', '3131 Dahlia Blvd, Colombo', 'Colombo 03 Post Office'),
    ('Madhusha Perera', '13, Diamond Hill, Matara', '0768901234', '3232 Poppy Road, Matara', 'Matara East Post Office'),
    ('Manjula Karunaratne', '27, Sunset Park, Galle', '0779012345', '3333 Jasmine Blvd, Galle', 'Galle North Post Office'),
    ('Thilini Wijesinghe', '6, River View, Kandy', '0780123456', '3434 Lavender Crescent, Kandy', 'Kandy District Post Office'),
    ('Nirmala Perera', '20, Ocean Breeze, Polonnaruwa', '0791234567', '3535 Cosmos Avenue, Polonnaruwa', 'Polonnaruwa West Post Office'),
    ('Chamilka Kumari', '3, Hilltop Road, Ratnapura', '0702345678', '3636 Sunflower Blvd, Ratnapura', 'Ratnapura South Post Office'),
    ('Chandima Jayalath', '12, Tulip Street, Kurunegala', '0713456789', '3737 Jasmine Avenue, Kurunegala', 'Kurunegala Post Office'),
    ('Ravindra Seneviratne', '5, Garden View, Gampaha', '0724567890', '3838 Violet Crescent, Gampaha', 'Gampaha South Post Office'),
    ('Chandani Kumari', '9, Waterfall Road, Vavuniya', '0735678901', '3939 Cosmos Blvd, Vavuniya', 'Vavuniya West Post Office'),
    ('Gayan Perera', '22, Moonlit Lane, Anuradhapura', '0746789012', '4040 Rose Road, Anuradhapura', 'Anuradhapura North Post Office'),
    ('Madhura Senanayake', '19, Coconut Park, Colombo 07', '0757890123', '4141 Jasmine Avenue, Colombo', 'Colombo West Post Office'),
    ('Kalani Jayasinghe', '13, Tropical Lane, Galle', '0768901234', '4242 Sunflower Crescent, Galle', 'Galle West Post Office'),
    ('Dilshan Wickramasinghe', '17, Lily Avenue, Ratnapura', '0779012345', '4343 Cosmos Lane, Ratnapura', 'Ratnapura Post Office'),
    ('Ranjani Samarasinghe', '21, Cherry Blossom Street, Kurunegala', '0780123456', '4444 Orchid Blvd, Kurunegala', 'Kurunegala City Post Office'),
    ('Lakmini Thennakoon', '25, Sunshine Road, Vavuniya', '0791234567', '4545 Magnolia Avenue, Vavuniya', 'Vavuniya South Post Office'),
    ('Nuwan Weerasinghe', '30, Bamboo Lane, Kandy', '0702345678', '4646 Jasmine Road, Kandy', 'Kandy East Post Office'),
    ('Chandima Kumari', '9, Maple Street, Anuradhapura', '0713456789', '4747 Rose Boulevard, Anuradhapura', 'Anuradhapura District Post Office'),
    ('Tharindu Rajapaksa', '12, Coral Lane, Matara', '0724567890', '4848 Violet Blvd, Matara', 'Matara South Post Office'),
    ('Sithara Kumari', '23, Mountain Road, Galle', '0735678901', '4949 Sunflower Avenue, Galle', 'Galle South Post Office'),
    ('Lahiru Jayalath', '14, Ocean Park, Kandy', '0746789012', '5050 Jasmine Road, Kandy', 'Kandy West Post Office'),
    ('Sahan Dissanayake', '10, Sunrise Street, Colombo', '0757890123', '5151 Lavender Lane, Colombo', 'Colombo Central Post Office'),
    ('Charith Perera', '17, Lotus Park, Polonnaruwa', '0768901234', '5252 Rose Crescent, Polonnaruwa', 'Polonnaruwa South Post Office'),
    ('Samanthi Kumari', '30, River Walk, Ratnapura', '0779012345', '5353 Violet Avenue, Ratnapura', 'Ratnapura North Post Office'),
    ('Anjalika Senanayake', '20, Green Acres, Matara', '0780123456', '5454 Sunflower Blvd, Matara', 'Matara Central Post Office');

	SELECT *FROM Sellers;

	INSERT INTO Sellers (name, address, contact_number, to_address, destination_PO)
VALUES
    ('Ravi Kularathna', '5, Green Park, Colombo 05', '0712345678', '123 Blueberry Lane, Colombo', 'Colombo 05 Post Office'),
    ('Nishantha Perera', '18, Orchid Gardens, Kandy', '0723456789', '456 Tulip Blvd, Kandy', 'Kandy Central Post Office'),
    ('Nuwani Jayasinghe', '22, Mango Tree Road, Matara', '0734567890', '789 Jasmine Avenue, Matara', 'Matara Post Office'),
    ('Ruthika Senanayake', '9, Sunset Road, Galle', '0745678901', '1010 Poppy Crescent, Galle', 'Galle Post Office');


INSERT INTO Sellers (name, address, contact_number, to_address, destination_PO)
VALUES
    ('Amal Wijesinghe', '1234 Willow Street, Colombo', '0756789012', '123 Green Road, Colombo 07', 'Colombo 07 Post Office'),
    ('Dinesh Perera', '56 Palm Grove, Kandy', '0723456789', '45 Tulip Blvd, Kandy', 'Kandy Post Office'),
    ('Shanika Fernando', '45 Lotus Lane, Matara', '0773456789', '789 Jasmine Street, Matara', 'Matara City Post Office'),
    ('Nihal Karunaratne', '2 Ocean Drive, Galle', '0765678901', '456 Maple Road, Galle', 'Galle Post Office'),
    ('Chandima Perera', '99 Sunset Road, Jaffna', '0754321098', '123 Poppy Avenue, Jaffna', 'Jaffna City Post Office'),
    ('Sanjeewa Wickramasinghe', '200 Blueberry Boulevard, Colombo', '0716789012', '789 Sunflower Road, Colombo', 'Colombo Post Office'),
    ('Niranjan Jayasuriya', '42 Coral Street, Trincomalee', '0787654321', '123 Orchid Lane, Trincomalee', 'Trincomalee City Post Office'),
    ('Anjali Perera', '100 Rosewood Lane, Matara', '0798765432', '456 Tulip Street, Matara', 'Matara District Post Office'),
    ('Saman Kularathna', '54 Pine Avenue, Kandy', '0778901234', '789 Lavender Road, Kandy', 'Kandy South Post Office'),
    ('Sasanka Weerasinghe', '89 Jasmine Road, Vavuniya', '0786789012', '1010 Gardenia Street, Vavuniya', 'Vavuniya South Post Office'),
    ('Ravindra Senanayake', '1 Cactus Avenue, Polonnaruwa', '0754325678', '123 Marigold Street, Polonnaruwa', 'Polonnaruwa Post Office'),
    ('Madusha Rathnayake', '22 Azalea Lane, Anuradhapura', '0765678901', '456 Rose Avenue, Anuradhapura', 'Anuradhapura Post Office'),
    ('Chamodi Perera', '33 Orchid Road, Colombo', '0734567890', '789 Iris Street, Colombo', 'Colombo West Post Office'),
    ('Ruhini Jayasuriya', '88 Violet Lane, Badulla', '0782345678', '123 Magnolia Road, Badulla', 'Badulla Post Office'),
    ('Kasun Alwis', '56 Orchid Avenue, Ratnapura', '0756789012', '456 Cactus Boulevard, Ratnapura', 'Ratnapura Post Office'),
    ('Sarath Gunarathna', '12 Rosewood Crescent, Galle', '0745678901', '789 Marigold Road, Galle', 'Galle South Post Office'),
    ('Tharini Kumari', '100 Oak Boulevard, Kegalle', '0738765432', '1010 Lily Avenue, Kegalle', 'Kegalle Post Office'),
    ('Kavinda Jayasinghe', '21 Sunflower Street, Colombo 06', '0789876543', '123 Magnolia Road, Colombo 06', 'Colombo 06 Post Office'),
    ('Madhuranga Wickramasinghe', '78 Jasmine Boulevard, Kurunegala', '0798765432', '456 Violet Lane, Kurunegala', 'Kurunegala South Post Office'),
    ('Suwani Perera', '101 Tulip Road, Vavuniya', '0755432109', '789 Fern Avenue, Vavuniya', 'Vavuniya North Post Office'),
    ('Dilini Kumari', '12 Marigold Street, Matale', '0747654321', '1010 Orchid Lane, Matale', 'Matale District Post Office'),
    ('Uditha Senanayake', '25 Pine Grove, Ratnapura', '0723456789', '456 Gardenia Street, Ratnapura', 'Ratnapura City Post Office'),
    ('Chamali Wickramasinghe', '99 Green Crescent, Polonnaruwa', '0719876543', '123 Dahlia Road, Polonnaruwa', 'Polonnaruwa South Post Office'),
    ('Danusha Karunarathna', '101 Rose Lane, Jaffna', '0782345678', '789 Sunflower Crescent, Jaffna', 'Jaffna Post Office'),
    ('Gayan Chandimal', '45 Jasmine Avenue, Colombo 04', '0793456789', '123 Tulip Road, Colombo 04', 'Colombo East Post Office'),
    ('Suresh Kularathna', '12 Orchid Boulevard, Kandy', '0765678901', '456 Gardenia Lane, Kandy', 'Kandy City Post Office'),
    ('Chandrika Perera', '100 Maple Street, Galle', '0752345678', '789 Iris Road, Galle', 'Galle North Post Office'),
    ('Janaka Alwis', '2 Blueberry Lane, Matara', '0712345678', '1010 Marigold Road, Matara', 'Matara South Post Office'),
    ('Viduranga Perera', '12 Sunflower Street, Kurunegala', '0787654321', '456 Fern Road, Kurunegala', 'Kurunegala North Post Office'),
    ('Sanali Wijesinghe', '45 Pine Lane, Vavuniya', '0798765432', '789 Jasmine Crescent, Vavuniya', 'Vavuniya West Post Office'),
    ('Sahan Kumara', '101 Orchid Road, Badulla', '0782345678', '123 Marigold Street, Badulla', 'Badulla North Post Office'),
    ('Mehreen Perera', '12 Maple Boulevard, Trincomalee', '0734567890', '456 Sunflower Crescent, Trincomalee', 'Trincomalee South Post Office'),
    ('Tharushi Jayasuriya', '200 Tulip Avenue, Anuradhapura', '0754321098', '789 Rose Avenue, Anuradhapura', 'Anuradhapura South Post Office'),
    ('Ruvindu Wickramasinghe', '34 Jasmine Road, Colombo 07', '0772345678', '123 Fern Boulevard, Colombo 07', 'Colombo South Post Office'),
    ('Kasun Alwis', '67 Oak Lane, Galle', '0787654321', '456 Sunflower Boulevard, Galle', 'Galle District Post Office'),
    ('Amaya Dissanayake', '12 Willow Street, Kurunegala', '0734567891', '789 Azalea Road, Kurunegala', 'Kurunegala District Post Office'),
    ('Manjula Perera', '89 Violet Avenue, Polonnaruwa', '0723456789', '123 Lily Road, Polonnaruwa', 'Polonnaruwa East Post Office'),
    ('Ruwan Kularathna', '45 Blueberry Street, Kandy', '0769876543', '456 Poppy Avenue, Kandy', 'Kandy South Post Office'),
    ('Ruchira Senanayake', '101 Marigold Lane, Colombo', '0772345678', '789 Jasmine Road, Colombo', 'Colombo West Post Office'),
    ('Anushka Wickramasinghe', '78 Tulip Avenue, Matara', '0787654321', '123 Orchid Road, Matara', 'Matara North Post Office'),
    ('Shanika Kumari', '56 Pine Road, Galle', '0754321098', '456 Gardenia Boulevard, Galle', 'Galle East Post Office'),
    ('Sashini Alwis', '34 Sunflower Crescent, Kandy', '0745678901', '123 Violet Boulevard, Kandy', 'Kandy North Post Office'),
    ('Rajitha Perera', '45 Lavender Road, Anuradhapura', '0798765432', '789 Rosewood Street, Anuradhapura', 'Anuradhapura District Post Office'),
    ('Sithumi Karunaratne', '12 Orchid Crescent, Vavuniya', '0782345678', '456 Fern Street, Vavuniya', 'Vavuniya City Post Office'),
    ('Madhura Jayasuriya', '67 Oak Road, Ratnapura', '0735678901', '123 Tulip Avenue, Ratnapura', 'Ratnapura South Post Office'),
    ('Malitha Perera', '34 Violet Lane, Kurunegala', '0723456789', '456 Gardenia Crescent, Kurunegala', 'Kurunegala West Post Office'),
    ('Sujatha Senanayake', '101 Rosewood Avenue, Badulla', '0787654321', '789 Azalea Road, Badulla', 'Badulla District Post Office'),
    ('Dilanka Wickramasinghe', '22 Lavender Boulevard, Kandy', '0752345678', '123 Magnolia Road, Kandy', 'Kandy District Post Office'),
    ('Indika Perera', '89 Marigold Road, Vavuniya', '0762345678', '456 Lily Avenue, Vavuniya', 'Vavuniya West Post Office'),
    ('Tharini Kumari', '101 Poppy Boulevard, Matara', '0779876543', '123 Jasmine Lane, Matara', 'Matara Post Office'),
    ('Kalpana Alwis', '56 Sunflower Boulevard, Trincomalee', '0787654321', '789 Orchid Crescent, Trincomalee', 'Trincomalee North Post Office'),
    ('Chinthaka Wickramasinghe', '101 Azalea Road, Galle', '0798765432', '456 Fern Boulevard, Galle', 'Galle Post Office'),
    ('Rathna Perera', '45 Tulip Avenue, Colombo 08', '0723456789', '123 Jasmine Crescent, Colombo', 'Colombo 08 Post Office'),
    ('Yasmin Karunaratne', '99 Lily Crescent, Anuradhapura', '0734567890', '456 Magnolia Lane, Anuradhapura', 'Anuradhapura North Post Office'),
    ('Kasuni Jayasinghe', '101 Marigold Boulevard, Ratnapura', '0782345678', '789 Sunflower Road, Ratnapura', 'Ratnapura North Post Office'),
    ('Kamani Senanayake', '22 Azalea Crescent, Galle', '0747654321', '123 Gardenia Boulevard, Galle', 'Galle South Post Office'),
    ('Dinushi Perera', '45 Jasmine Lane, Kandy', '0798765432', '456 Violet Boulevard, Kandy', 'Kandy City Post Office');

INSERT INTO Sellers (name, address, contact_number, to_address, destination_PO)
VALUES
    ('Roshan Silva', '12 Orchid Lane, Kegalle', '0722345678', '123 Tulip Boulevard, Kegalle', 'Kegalle Post Office'),
    ('Hiruni Fernando', '45 Green Road, Matara', '0797654321', '456 Jasmine Crescent, Matara', 'Matara South Post Office'),
    ('Indrani Perera', '88 Lavender Avenue, Anuradhapura', '0736789012', '789 Magnolia Road, Anuradhapura', 'Anuradhapura West Post Office'),
    ('Vishal Wickramasinghe', '34 Rosewood Crescent, Colombo', '0754321098', '123 Azalea Road, Colombo', 'Colombo West Post Office'),
    ('Jayanthi Kumari', '67 Tulip Avenue, Kandy', '0782345678', '456 Violet Boulevard, Kandy', 'Kandy North Post Office'),
    ('Tharushi Perera', '100 Jasmine Lane, Vavuniya', '0743456789', '789 Fern Avenue, Vavuniya', 'Vavuniya Post Office'),
    ('Ruchira Wickramasinghe', '45 Maple Street, Trincomalee', '0787654321', '123 Marigold Road, Trincomalee', 'Trincomalee South Post Office'),
    ('Kasun Jayasinghe', '23 Poppy Road, Galle', '0752345678', '456 Sunflower Boulevard, Galle', 'Galle South Post Office'),
    ('Siyara Karunaratne', '89 Blueberry Crescent, Matale', '0738765432', '123 Iris Street, Matale', 'Matale East Post Office'),
    ('Madhura Jayasuriya', '101 Violet Boulevard, Kegalle', '0745678901', '789 Poppy Lane, Kegalle', 'Kegalle District Post Office'),
    ('Chamilka Senanayake', '22 Sunflower Road, Vavuniya', '0723456789', '456 Jasmine Crescent, Vavuniya', 'Vavuniya West Post Office'),
    ('Akhila Karunaratne', '78 Azalea Street, Ratnapura', '0735678901', '789 Orchid Road, Ratnapura', 'Ratnapura North Post Office'),
    ('Shashini Wickramasinghe', '100 Maple Lane, Kandy', '0782345678', '123 Fern Road, Kandy', 'Kandy City Post Office'),
    ('Manoj Wijesinghe', '56 Tulip Crescent, Polonnaruwa', '0798765432', '456 Poppy Avenue, Polonnaruwa', 'Polonnaruwa South Post Office'),
    ('Amaya Dissanayake', '89 Jasmine Road, Colombo', '0787654321', '123 Rosewood Lane, Colombo', 'Colombo North Post Office'),
    ('Chandima Senanayake', '101 Violet Road, Galle', '0754321098', '456 Fern Boulevard, Galle', 'Galle East Post Office'),
    ('Sumedha Karunaratne', '56 Lavender Lane, Matara', '0732345678', '789 Magnolia Crescent, Matara', 'Matara West Post Office'),
    ('Dilini Jayasinghe', '34 Sunflower Boulevard, Kandy', '0745678901', '123 Violet Avenue, Kandy', 'Kandy District Post Office'),
    ('Ravindra Perera', '12 Maple Boulevard, Polonnaruwa', '0754325678', '456 Tulip Street, Polonnaruwa', 'Polonnaruwa North Post Office'),
    ('Shanika Karunaratne', '89 Gardenia Road, Galle', '0782345678', '123 Poppy Avenue, Galle', 'Galle City Post Office'),
    ('Nadeesha Wickramasinghe', '23 Jasmine Crescent, Colombo', '0787654321', '456 Azalea Boulevard, Colombo', 'Colombo 08 Post Office'),
    ('Samantha Wijesinghe', '12 Blueberry Street, Trincomalee', '0767654321', '789 Sunflower Boulevard, Trincomalee', 'Trincomalee Post Office'),
    ('Kavinda Alwis', '56 Orchid Crescent, Vavuniya', '0792345678', '123 Marigold Road, Vavuniya', 'Vavuniya East Post Office'),
    ('Manushka Perera', '34 Rose Boulevard, Matale', '0785678901', '456 Lily Lane, Matale', 'Matale City Post Office'),
    ('Sashini Kumari', '67 Maple Crescent, Kandy', '0756789012', '789 Azalea Boulevard, Kandy', 'Kandy West Post Office'),
    ('Chamila Wickramasinghe', '23 Tulip Crescent, Badulla', '0742345678', '123 Poppy Street, Badulla', 'Badulla District Post Office'),
    ('Sujan Jayasinghe', '12 Orchid Road, Polonnaruwa', '0798765432', '456 Jasmine Lane, Polonnaruwa', 'Polonnaruwa East Post Office'),
    ('Lihini Karunaratne', '100 Rosewood Crescent, Galle', '0733456789', '789 Fern Road, Galle', 'Galle North Post Office'),
    ('Dhanushka Perera', '45 Sunflower Boulevard, Kandy', '0722345678', '123 Tulip Lane, Kandy', 'Kandy South Post Office'),
    ('Priyantha Senanayake', '34 Azalea Road, Colombo', '0747654321', '456 Marigold Avenue, Colombo', 'Colombo South Post Office'),
    ('Sandali Wijesinghe', '56 Poppy Street, Vavuniya', '0732345678', '789 Jasmine Boulevard, Vavuniya', 'Vavuniya Post Office'),
    ('Shenuka Perera', '23 Blueberry Road, Ratnapura', '0787654321', '123 Orchid Avenue, Ratnapura', 'Ratnapura West Post Office'),
    ('Ravindra Wickramasinghe', '100 Fern Road, Galle', '0798765432', '456 Sunflower Crescent, Galle', 'Galle West Post Office'),
    ('Kasun Karunaratne', '12 Jasmine Avenue, Matale', '0756789012', '789 Lavender Boulevard, Matale', 'Matale Post Office'),
    ('Dilanka Alwis', '56 Maple Road, Vavuniya', '0747654321', '123 Marigold Crescent, Vavuniya', 'Vavuniya City Post Office'),
    ('Rathna Wickramasinghe', '34 Orchid Lane, Polonnaruwa', '0787654321', '456 Lily Boulevard, Polonnaruwa', 'Polonnaruwa West Post Office'),
    ('Yasmin Perera', '12 Blueberry Boulevard, Kandy', '0792345678', '789 Rose Avenue, Kandy', 'Kandy East Post Office'),
    ('Tashika Senanayake', '23 Rose Lane, Galle', '0782345678', '456 Azalea Avenue, Galle', 'Galle Post Office'),
    ('Hiran Alwis', '56 Fern Crescent, Colombo', '0745678901', '123 Sunflower Boulevard, Colombo', 'Colombo East Post Office'),
    ('Sasika Karunaratne', '12 Violet Road, Trincomalee', '0754321098', '456 Gardenia Lane, Trincomalee', 'Trincomalee West Post Office'),
    ('Madhavi Wijesinghe', '34 Lavender Crescent, Kandy', '0732345678', '789 Tulip Street, Kandy', 'Kandy North Post Office'),
    ('Vimukthi Perera', '45 Maple Boulevard, Galle', '0787654321', '123 Poppy Crescent, Galle', 'Galle District Post Office'),
    ('Tarantha Karunaratne', '56 Rosewood Street, Vavuniya', '0743456789', '456 Sunflower Crescent, Vavuniya', 'Vavuniya Post Office'),
    ('Chathura Senanayake', '23 Sunflower Avenue, Matara', '0798765432', '123 Gardenia Road, Matara', 'Matara West Post Office'),
    ('Ravindu Wickramasinghe', '12 Azalea Crescent, Polonnaruwa', '0787654321', '456 Fern Street, Polonnaruwa', 'Polonnaruwa North Post Office'),
    ('Vidura Jayasinghe', '56 Orchid Boulevard, Galle', '0747654321', '789 Violet Avenue, Galle', 'Galle North Post Office'),
    ('Lakshmi Perera', '23 Jasmine Street, Kandy', '0792345678', '123 Maple Road, Kandy', 'Kandy West Post Office'),
    ('Sayantha Alwis', '12 Violet Crescent, Colombo', '0734567890', '456 Rosewood Avenue, Colombo', 'Colombo 03 Post Office'),
    ('Nimali Senanayake', '34 Rose Boulevard, Matale', '0723456789', '789 Tulip Crescent, Matale', 'Matale North Post Office'),
    ('Sithum Wickramasinghe', '45 Jasmine Road, Badulla', '0787654321', '123 Sunflower Boulevard, Badulla', 'Badulla District Post Office'),
    ('Isuru Karunaratne', '56 Lavender Crescent, Galle', '0732345678', '456 Marigold Avenue, Galle', 'Galle South Post Office');

INSERT INTO Sellers (name, address, contact_number, to_address, destination_PO)
VALUES
    ('Lahiru Fernando', '23 Tulip Crescent, Kandy', '0782345678', '123 Rosewood Boulevard, Kandy', 'Kandy East Post Office'),
    ('Kumari Perera', '45 Jasmine Road, Ratnapura', '0745678901', '456 Gardenia Crescent, Ratnapura', 'Ratnapura City Post Office'),
    ('Tharindu Wijesinghe', '67 Lavender Lane, Polonnaruwa', '0723456789', '789 Sunflower Boulevard, Polonnaruwa', 'Polonnaruwa East Post Office'),
    ('Nilanthi Karunaratne', '23 Blueberry Boulevard, Galle', '0792345678', '123 Fern Avenue, Galle', 'Galle West Post Office'),
    ('Chandana Senanayake', '56 Poppy Crescent, Anuradhapura', '0732345678', '456 Jasmine Road, Anuradhapura', 'Anuradhapura West Post Office'),
    ('Tamalka Alwis', '89 Sunflower Boulevard, Matara', '0787654321', '123 Violet Crescent, Matara', 'Matara Post Office'),
    ('Chamodi Perera', '34 Orchid Lane, Polonnaruwa', '0745678901', '456 Magnolia Avenue, Polonnaruwa', 'Polonnaruwa North Post Office'),
    ('Saman Kumara', '101 Rosewood Road, Kandy', '0733456789', '123 Gardenia Boulevard, Kandy', 'Kandy City Post Office'),
    ('Madusha Jayasinghe', '23 Azalea Street, Trincomalee', '0783456789', '456 Poppy Boulevard, Trincomalee', 'Trincomalee Post Office'),
    ('Isuri Wickramasinghe', '45 Maple Crescent, Galle', '0726789012', '123 Jasmine Road, Galle', 'Galle South Post Office'),
    ('Buddhika Senanayake', '56 Fern Road, Kegalle', '0734567890', '789 Orchid Lane, Kegalle', 'Kegalle Post Office'),
    ('Kumudu Dissanayake', '89 Blueberry Street, Colombo', '0792345678', '123 Lavender Boulevard, Colombo', 'Colombo East Post Office'),
    ('Ranjani Karunaratne', '45 Jasmine Crescent, Badulla', '0743456789', '789 Azalea Avenue, Badulla', 'Badulla District Post Office'),
    ('Madhura Perera', '34 Poppy Road, Vavuniya', '0782345678', '123 Violet Street, Vavuniya', 'Vavuniya Post Office'),
    ('Sriya Wickramasinghe', '56 Azalea Crescent, Matara', '0735678901', '456 Marigold Boulevard, Matara', 'Matara West Post Office'),
    ('Sithma Karunaratne', '101 Tulip Avenue, Galle', '0747654321', '789 Sunflower Crescent, Galle', 'Galle East Post Office'),
    ('Jayanthi Wijesinghe', '34 Fern Boulevard, Ratnapura', '0787654321', '123 Poppy Crescent, Ratnapura', 'Ratnapura South Post Office'),
    ('Dinesh Karunaratne', '56 Jasmine Crescent, Vavuniya', '0792345678', '789 Azalea Avenue, Vavuniya', 'Vavuniya West Post Office'),
    ('Kanishka Fernando', '23 Maple Boulevard, Kandy', '0732345678', '123 Marigold Street, Kandy', 'Kandy North Post Office'),
    ('Rukshan Perera', '45 Rosewood Road, Galle', '0743456789', '456 Gardenia Boulevard, Galle', 'Galle North Post Office'),
    ('Suhana Alwis', '67 Blueberry Street, Polonnaruwa', '0787654321', '123 Jasmine Boulevard, Polonnaruwa', 'Polonnaruwa City Post Office'),
    ('Chandima Karunaratne', '12 Orchid Avenue, Matale', '0792345678', '456 Sunflower Crescent, Matale', 'Matale District Post Office'),
    ('Avinash Perera', '45 Fern Lane, Kandy', '0723456789', '789 Poppy Boulevard, Kandy', 'Kandy South Post Office'),
    ('Tashmi Karunaratne', '89 Sunflower Crescent, Colombo', '0782345678', '123 Azalea Boulevard, Colombo', 'Colombo West Post Office'),
    ('Dulani Wijesinghe', '101 Rose Boulevard, Vavuniya', '0732345678', '456 Jasmine Road, Vavuniya', 'Vavuniya District Post Office'),
    ('Dinesh Wickramasinghe', '56 Blueberry Boulevard, Anuradhapura', '0745678901', '123 Lavender Avenue, Anuradhapura', 'Anuradhapura Post Office'),
    ('Tariq Karunaratne', '67 Gardenia Road, Galle', '0792345678', '456 Marigold Boulevard, Galle', 'Galle City Post Office'),
    ('Suneth Perera', '23 Azalea Crescent, Matale', '0787654321', '789 Rosewood Boulevard, Matale', 'Matale Post Office'),
    ('Samanthi Senanayake', '45 Poppy Boulevard, Kandy', '0732345678', '123 Lavender Avenue, Kandy', 'Kandy Post Office'),
    ('Hiruni Karunaratne', '67 Jasmine Road, Ratnapura', '0792345678', '456 Sunflower Lane, Ratnapura', 'Ratnapura North Post Office'),
    ('Dilani Wijesinghe', '23 Fern Boulevard, Galle', '0743456789', '123 Violet Crescent, Galle', 'Galle District Post Office'),
    ('Chamika Perera', '45 Tulip Street, Matara', '0792345678', '789 Orchid Boulevard, Matara', 'Matara North Post Office'),
    ('Yasmin Karunaratne', '67 Rosewood Crescent, Kegalle', '0734567890', '123 Azalea Road, Kegalle', 'Kegalle City Post Office'),
    ('Ravindra Perera', '56 Lavender Road, Polonnaruwa', '0723456789', '456 Sunflower Crescent, Polonnaruwa', 'Polonnaruwa South Post Office'),
    ('Kavinda Wickramasinghe', '23 Blueberry Crescent, Vavuniya', '0742345678', '123 Poppy Road, Vavuniya', 'Vavuniya South Post Office'),
    ('Lahiru Jayasinghe', '45 Rose Boulevard, Kandy', '0787654321', '789 Lavender Street, Kandy', 'Kandy District Post Office'),
    ('Kumara Perera', '67 Jasmine Lane, Galle', '0732345678', '123 Sunflower Avenue, Galle', 'Galle South Post Office'),
    ('Uditha Alwis', '101 Azalea Boulevard, Colombo', '0792345678', '456 Tulip Road, Colombo', 'Colombo North Post Office'),
    ('Chamika Karunaratne', '23 Lavender Crescent, Anuradhapura', '0782345678', '123 Magnolia Road, Anuradhapura', 'Anuradhapura City Post Office'),
    ('Kavisha Senanayake', '56 Poppy Crescent, Matara', '0745678901', '789 Fern Boulevard, Matara', 'Matara District Post Office'),
    ('Buddhika Alwis', '45 Tulip Road, Vavuniya', '0792345678', '123 Jasmine Crescent, Vavuniya', 'Vavuniya North Post Office'),
    ('Madhusha Karunaratne', '23 Blueberry Boulevard, Polonnaruwa', '0734567890', '456 Orchid Lane, Polonnaruwa', 'Polonnaruwa East Post Office'),
    ('Sithara Perera', '45 Jasmine Road, Galle', '0792345678', '123 Lavender Boulevard, Galle', 'Galle North Post Office'),
    ('Nimesh Wijesinghe', '67 Fern Road, Kandy', '0745678901', '789 Marigold Crescent, Kandy', 'Kandy West Post Office'),
    ('Tashani Wickramasinghe', '23 Rosewood Lane, Colombo', '0734567890', '456 Poppy Road, Colombo', 'Colombo Post Office'),
    ('Sanduni Karunaratne', '101 Jasmine Crescent, Matara', '0747654321', '123 Violet Boulevard, Matara', 'Matara City Post Office'),
    ('Dilan Wijesinghe', '45 Blueberry Road, Anuradhapura', '0734567890', '789 Gardenia Lane, Anuradhapura', 'Anuradhapura North Post Office'),
    ('Lahiru Perera', '23 Tulip Crescent, Ratnapura', '0782345678', '123 Fern Boulevard, Ratnapura', 'Ratnapura East Post Office'),
    ('Kavishka Jayasinghe', '56 Lavender Road, Kandy', '0723456789', '789 Poppy Crescent, Kandy', 'Kandy City Post Office'),
    ('Yasmin Wickramasinghe', '45 Poppy Lane, Vavuniya', '0792345678', '123 Marigold Boulevard, Vavuniya', 'Vavuniya City Post Office'),
    ('Ravi Alwis', '67 Jasmine Crescent, Matale', '0745678901', '456 Sunflower Road, Matale', 'Matale North Post Office'),
    ('Chamodi Karunaratne', '23 Gardenia Road, Galle', '0782345678', '789 Lavender Crescent, Galle', 'Galle East Post Office'),
    ('Uditha Wijesinghe', '45 Rosewood Avenue, Anuradhapura', '0792345678', '123 Azalea Lane, Anuradhapura', 'Anuradhapura District Post Office'),
    ('Kanishka Karunaratne', '56 Violet Road, Matara', '0787654321', '789 Blueberry Boulevard, Matara', 'Matara North Post Office'),
    ('Chandana Perera', '23 Marigold Avenue, Ratnapura', '0745678901', '456 Sunflower Boulevard, Ratnapura', 'Ratnapura South Post Office'),
    ('Dilshan Wickramasinghe', '45 Blueberry Crescent, Polonnaruwa', '0792345678', '123 Jasmine Road, Polonnaruwa', 'Polonnaruwa City Post Office'),
    ('Pradeep Karunaratne', '56 Azalea Boulevard, Kandy', '0787654321', '789 Fern Crescent, Kandy', 'Kandy Post Office');

INSERT INTO Sellers (name, address, contact_number, to_address, destination_PO)
VALUES
    ('Niranjani Perera', '23 Gardenia Road, Kegalle', '0783456789', '123 Violet Boulevard, Kegalle', 'Kegalle South Post Office'),
    ('Dilini Alwis', '56 Sunflower Crescent, Anuradhapura', '0742345678', '456 Lavender Avenue, Anuradhapura', 'Anuradhapura South Post Office'),
    ('Ravindra Karunaratne', '67 Jasmine Road, Galle', '0734567890', '123 Poppy Lane, Galle', 'Galle West Post Office'),
    ('Shashini Wijesinghe', '45 Fern Boulevard, Polonnaruwa', '0787654321', '456 Marigold Street, Polonnaruwa', 'Polonnaruwa South Post Office'),
    ('Chandrika Perera', '101 Tulip Road, Matara', '0792345678', '789 Azalea Lane, Matara', 'Matara East Post Office'),
    ('Ravindra Wickramasinghe', '23 Orchid Avenue, Colombo', '0732345678', '123 Rosewood Boulevard, Colombo', 'Colombo North Post Office'),
    ('Nimasha Karunaratne', '45 Gardenia Lane, Ratnapura', '0745678901', '456 Violet Road, Ratnapura', 'Ratnapura City Post Office'),
    ('Ruwan Alwis', '67 Blueberry Crescent, Anuradhapura', '0792345678', '789 Sunflower Avenue, Anuradhapura', 'Anuradhapura North Post Office'),
    ('Sanath Perera', '56 Lavender Boulevard, Vavuniya', '0782345678', '123 Jasmine Crescent, Vavuniya', 'Vavuniya North Post Office'),
    ('Kasun Karunaratne', '45 Magnolia Crescent, Kandy', '0732345678', '789 Poppy Avenue, Kandy', 'Kandy South Post Office'),
    ('Pradeep Alwis', '23 Azalea Boulevard, Galle', '0787654321', '456 Orchid Crescent, Galle', 'Galle East Post Office'),
    ('Samantha Karunaratne', '56 Poppy Road, Matara', '0792345678', '123 Jasmine Lane, Matara', 'Matara West Post Office'),
    ('Krishna Perera', '67 Tulip Crescent, Kegalle', '0732345678', '789 Gardenia Road, Kegalle', 'Kegalle District Post Office'),
    ('Dinesh Wijesinghe', '45 Violet Street, Polonnaruwa', '0747654321', '123 Marigold Avenue, Polonnaruwa', 'Polonnaruwa North Post Office'),
    ('Sithara Alwis', '23 Fern Crescent, Colombo', '0782345678', '456 Jasmine Avenue, Colombo', 'Colombo West Post Office'),
    ('Kavindi Perera', '56 Blueberry Road, Vavuniya', '0792345678', '789 Orchid Boulevard, Vavuniya', 'Vavuniya District Post Office'),
    ('Nadeesha Karunaratne', '67 Sunflower Lane, Kandy', '0745678901', '123 Lavender Boulevard, Kandy', 'Kandy West Post Office'),
    ('Chandana Wickramasinghe', '23 Gardenia Crescent, Ratnapura', '0732345678', '456 Poppy Street, Ratnapura', 'Ratnapura East Post Office'),
    ('Sithmi Perera', '45 Jasmine Boulevard, Anuradhapura', '0787654321', '123 Marigold Crescent, Anuradhapura', 'Anuradhapura West Post Office'),
    ('Ravindra Karunaratne', '67 Blueberry Lane, Galle', '0734567890', '789 Lavender Crescent, Galle', 'Galle District Post Office'),
    ('Nuwan Wijesinghe', '23 Rosewood Avenue, Matale', '0782345678', '456 Sunflower Road, Matale', 'Matale Post Office'),
    ('Dilani Wickramasinghe', '45 Lavender Road, Kandy', '0745678901', '123 Azalea Boulevard, Kandy', 'Kandy East Post Office'),
    ('Chamika Perera', '56 Tulip Avenue, Vavuniya', '0792345678', '789 Gardenia Lane, Vavuniya', 'Vavuniya North Post Office'),
    ('Samanthi Wijesinghe', '23 Poppy Boulevard, Matara', '0742345678', '456 Lavender Street, Matara', 'Matara City Post Office'),
    ('Nimesh Karunaratne', '45 Azalea Crescent, Anuradhapura', '0787654321', '123 Marigold Road, Anuradhapura', 'Anuradhapura North Post Office'),
    ('Yasmin Perera', '67 Orchid Boulevard, Galle', '0734567890', '789 Rosewood Crescent, Galle', 'Galle North Post Office'),
    ('Chandrika Wijesinghe', '23 Fern Avenue, Matale', '0787654321', '456 Poppy Road, Matale', 'Matale West Post Office'),
    ('Nimal Karunaratne', '45 Jasmine Road, Colombo', '0792345678', '123 Lavender Boulevard, Colombo', 'Colombo East Post Office'),
    ('Krishan Wickramasinghe', '67 Sunflower Crescent, Kandy', '0745678901', '789 Azalea Lane, Kandy', 'Kandy City Post Office'),
    ('Tharindu Perera', '23 Blueberry Road, Galle', '0782345678', '456 Orchid Boulevard, Galle', 'Galle West Post Office'),
    ('Shashika Alwis', '56 Lavender Avenue, Ratnapura', '0732345678', '123 Violet Road, Ratnapura', 'Ratnapura North Post Office'),
    ('Saman Karunaratne', '45 Gardenia Crescent, Vavuniya', '0787654321', '789 Poppy Lane, Vavuniya', 'Vavuniya West Post Office'),
    ('Kavinda Wijesinghe', '23 Marigold Boulevard, Kandy', '0747654321', '456 Jasmine Lane, Kandy', 'Kandy North Post Office'),
    ('Dilsha Perera', '67 Poppy Crescent, Polonnaruwa', '0787654321', '123 Gardenia Boulevard, Polonnaruwa', 'Polonnaruwa District Post Office'),
    ('Chamodi Karunaratne', '45 Tulip Boulevard, Galle', '0792345678', '789 Rosewood Crescent, Galle', 'Galle South Post Office'),
    ('Manoj Wickramasinghe', '23 Jasmine Lane, Matara', '0742345678', '456 Sunflower Crescent, Matara', 'Matara South Post Office');

INSERT INTO Receivers (name, address, contact_number)
SELECT 
    CASE seller_id
        WHEN 1 THEN 'Janithi'
        WHEN 2 THEN 'Pamodya'
        WHEN 3 THEN 'Nethuli'
        WHEN 4 THEN 'Gihan'
        WHEN 5 THEN 'Tehan'
        WHEN 6 THEN 'Vihinadi'
        WHEN 7 THEN 'Senuri'
        WHEN 8 THEN 'Lukesh'
        WHEN 9 THEN 'Dimalshi'
        WHEN 10 THEN 'Manuri'
        WHEN 11 THEN 'Hasindi'
        WHEN 12 THEN 'Binuki'
        WHEN 13 THEN 'Yashoda'
        WHEN 14 THEN 'Nethali'
        WHEN 15 THEN 'Vihari'
        WHEN 16 THEN 'Vinura'
        WHEN 17 THEN 'Venura'
        WHEN 18 THEN 'Nethuja'
        WHEN 19 THEN 'Hansana'
        WHEN 20 THEN 'Akash'
        WHEN 21 THEN 'Nilasi'
        WHEN 22 THEN 'Tharidu'
        WHEN 23 THEN 'Takeshini'
        WHEN 24 THEN 'Linara'
        WHEN 25 THEN 'Akidu'
        WHEN 26 THEN 'Venul'
        WHEN 27 THEN 'Sithumya'
        WHEN 28 THEN 'Mehara'
        WHEN 29 THEN 'Vidumini'
        WHEN 30 THEN 'Lakshan'
        WHEN 31 THEN 'Vishmi'
        WHEN 32 THEN 'Hiruni'
        WHEN 33 THEN 'Derani'
        WHEN 34 THEN 'Shean'
        WHEN 35 THEN 'Shenul'
        WHEN 36 THEN 'Imeth'
        WHEN 37 THEN 'Deshan'
        WHEN 38 THEN 'Shehan'
        WHEN 39 THEN 'Thenura'
        WHEN 40 THEN 'Linal'
        WHEN 41 THEN 'Hasala'
        WHEN 42 THEN 'Thevidu'
        WHEN 43 THEN 'Lakmi'
        WHEN 44 THEN 'Lakmal'
        WHEN 45 THEN 'Nehara'
        WHEN 46 THEN 'Vihini'
        WHEN 47 THEN 'Nuwani'
        WHEN 48 THEN 'Yasiru'
        WHEN 49 THEN 'Nihinsa'
        WHEN 50 THEN 'Vidun'
    END AS name,
    to_address,
    CASE seller_id
        WHEN 1 THEN '0771234567'
        WHEN 2 THEN '0772345678'
        WHEN 3 THEN '0773456789'
        WHEN 4 THEN '0774567890'
        WHEN 5 THEN '0775678901'
        WHEN 6 THEN '0776789012'
        WHEN 7 THEN '0777890123'
        WHEN 8 THEN '0778901234'
        WHEN 9 THEN '0779012345'
        WHEN 10 THEN '0770123456'
        WHEN 11 THEN '0771234567'
        WHEN 12 THEN '0772345678'
        WHEN 13 THEN '0773456789'
        WHEN 14 THEN '0774567890'
        WHEN 15 THEN '0775678901'
        WHEN 16 THEN '0776789012'
        WHEN 17 THEN '0777890123'
        WHEN 18 THEN '0778901234'
        WHEN 19 THEN '0779012345'
        WHEN 20 THEN '0770123456'
        WHEN 21 THEN '0771234567'
        WHEN 22 THEN '0772345678'
        WHEN 23 THEN '0773456789'
        WHEN 24 THEN '0774567890'
        WHEN 25 THEN '0775678901'
        WHEN 26 THEN '0776789012'
        WHEN 27 THEN '0777890123'
        WHEN 28 THEN '0778901234'
        WHEN 29 THEN '0779012345'
        WHEN 30 THEN '0770123456'
        WHEN 31 THEN '0771234567'
        WHEN 32 THEN '0772345678'
        WHEN 33 THEN '0773456789'
        WHEN 34 THEN '0774567890'
        WHEN 35 THEN '0775678901'
        WHEN 36 THEN '0776789012'
        WHEN 37 THEN '0777890123'
        WHEN 38 THEN '0778901234'
        WHEN 39 THEN '0779012345'
        WHEN 40 THEN '0770123456'
        WHEN 41 THEN '0771234567'
        WHEN 42 THEN '0772345678'
        WHEN 43 THEN '0773456789'
        WHEN 44 THEN '0774567890'
        WHEN 45 THEN '0775678901'
        WHEN 46 THEN '0776789012'
        WHEN 47 THEN '0777890123'
        WHEN 48 THEN '0778901234'
        WHEN 49 THEN '0779012345'
        WHEN 50 THEN '0770123456'
    END AS contact_number
FROM Sellers
WHERE seller_id <= 50;

INSERT INTO Receivers (name, address, contact_number)
SELECT 
    CASE seller_id
        WHEN 101 THEN 'Manithi'
        WHEN 102 THEN 'Jayodya'
        WHEN 103 THEN 'Sethuli'
        WHEN 104 THEN 'Mihan'
        WHEN 105 THEN 'Mehan'
        WHEN 106 THEN 'Sihinadi'
        WHEN 107 THEN 'Tenuri'
        WHEN 108 THEN 'Kukesh'
        WHEN 109 THEN 'Timalshi'
        WHEN 110 THEN 'Banuri'
        WHEN 111 THEN 'Masindi'
        WHEN 112 THEN 'Chinuki'
        WHEN 113 THEN 'Rashoda'
        WHEN 114 THEN 'Methali'
        WHEN 115 THEN 'Nihari'
        WHEN 116 THEN 'Winura'
        WHEN 117 THEN 'Wenura'
        WHEN 118 THEN 'Rethuja'
        WHEN 119 THEN 'Yansana'
        WHEN 120 THEN 'Ukash'
        WHEN 121 THEN 'Oilasi'
        WHEN 122 THEN 'Oharidu'
        WHEN 123 THEN 'Rakeshini'
        WHEN 124 THEN 'Rinara'
        WHEN 125 THEN 'Ekidu'
        WHEN 126 THEN 'Wenul'
        WHEN 127 THEN 'Pithumya'
        WHEN 128 THEN 'Nehara'
        WHEN 129 THEN 'Sidumini'
        WHEN 130 THEN 'Rakshan'
        WHEN 131 THEN 'Tishmi'
        WHEN 132 THEN 'Tiruni'
        WHEN 133 THEN 'Terani'
        WHEN 134 THEN 'Yhean'
        WHEN 135 THEN 'Yhenul'
        WHEN 136 THEN 'Umeth'
        WHEN 137 THEN 'Teshan'
        WHEN 138 THEN 'Ehehan'
        WHEN 139 THEN 'Whenura'
        WHEN 140 THEN 'Rinal'
        WHEN 141 THEN 'Tasala'
        WHEN 142 THEN 'Yhevidu'
        WHEN 143 THEN 'Yakmi'
        WHEN 144 THEN 'Yakmal'
        WHEN 145 THEN 'Uehara'
        WHEN 146 THEN 'Pihini'
        WHEN 147 THEN 'Puwani'
        WHEN 148 THEN 'Pasiru'
        WHEN 149 THEN 'Rihinsa'
        WHEN 150 THEN 'Widun'
    END AS name,
    to_address,
    CASE seller_id
        WHEN 101 THEN '0771234567'
        WHEN 102 THEN '0772345678'
        WHEN 103 THEN '0773456789'
        WHEN 104 THEN '0774567890'
        WHEN 105 THEN '0775678901'
        WHEN 106 THEN '0776789012'
        WHEN 107 THEN '0777890123'
        WHEN 108 THEN '0778901234'
        WHEN 109 THEN '0779012345'
        WHEN 110 THEN '0770123456'
        WHEN 111 THEN '0771234567'
        WHEN 112 THEN '0772345678'
        WHEN 113 THEN '0773456789'
        WHEN 114 THEN '0774567890'
        WHEN 115 THEN '0775678901'
        WHEN 116 THEN '0776789012'
        WHEN 117 THEN '0777890123'
        WHEN 118 THEN '0778901234'
        WHEN 119 THEN '0779012345'
        WHEN 120 THEN '0770123456'
        WHEN 121 THEN '0771234567'
        WHEN 122 THEN '0772345678'
        WHEN 123 THEN '0773456789'
        WHEN 124 THEN '0774567890'
        WHEN 125 THEN '0775678901'
        WHEN 126 THEN '0776789012'
        WHEN 127 THEN '0777890123'
        WHEN 128 THEN '0778901234'
        WHEN 129 THEN '0779012345'
        WHEN 130 THEN '0770123456'
        WHEN 131 THEN '0771234567'
        WHEN 132 THEN '0772345678'
        WHEN 133 THEN '0773456789'
        WHEN 134 THEN '0774567890'
        WHEN 135 THEN '0775678901'
        WHEN 136 THEN '0776789012'
        WHEN 137 THEN '0777890123'
        WHEN 138 THEN '0778901234'
        WHEN 139 THEN '0779012345'
        WHEN 140 THEN '0770123456'
        WHEN 141 THEN '0771234567'
        WHEN 142 THEN '0772345678'
        WHEN 143 THEN '0773456789'
        WHEN 144 THEN '0774567890'
        WHEN 145 THEN '0775678901'
        WHEN 146 THEN '0776789012'
        WHEN 147 THEN '0777890123'
        WHEN 148 THEN '0778901234'
        WHEN 149 THEN '0779012345'
        WHEN 150 THEN '0770123456'
    END AS contact_number
FROM Sellers
WHERE seller_id BETWEEN 101 AND 150;

SELECT * FROM Receivers;


INSERT INTO Receivers (name, address, contact_number)
SELECT 
    CASE seller_id
        WHEN 151 THEN 'Nilanthi'
        WHEN 152 THEN 'Roshan'
        WHEN 153 THEN 'Haritha'
        WHEN 154 THEN 'Dulanjali'
        WHEN 155 THEN 'Sewwandi'
        WHEN 156 THEN 'Chameera'
        WHEN 157 THEN 'Rangana'
        WHEN 158 THEN 'Thilanka'
        WHEN 159 THEN 'Achini'
        WHEN 160 THEN 'Wimal'
        WHEN 161 THEN 'Shanthi'
        WHEN 162 THEN 'Malkanthi'
        WHEN 163 THEN 'Ruwanthi'
        WHEN 164 THEN 'Aruna'
        WHEN 165 THEN 'Sumudu'
        WHEN 166 THEN 'Sujeewa'
        WHEN 167 THEN 'Niroshan'
        WHEN 168 THEN 'Iresha'
        WHEN 169 THEN 'Waruna'
        WHEN 170 THEN 'Hemantha'
        WHEN 171 THEN 'Lasith'
        WHEN 172 THEN 'Ranil'
        WHEN 173 THEN 'Sanduni'
        WHEN 174 THEN 'Chaminda'
        WHEN 175 THEN 'Janith'
        WHEN 176 THEN 'Samadhi'
        WHEN 177 THEN 'Upeksha'
        WHEN 178 THEN 'Gayan'
        WHEN 179 THEN 'Chathuranga'
        WHEN 180 THEN 'Kavindi'
        WHEN 181 THEN 'Ruwangi'
        WHEN 182 THEN 'Mahinda'
        WHEN 183 THEN 'Chatura'
        WHEN 184 THEN 'Kasun'
        WHEN 185 THEN 'Piumi'
        WHEN 186 THEN 'Chiran'
        WHEN 187 THEN 'Ruvini'
        WHEN 188 THEN 'Dilanka'
        WHEN 189 THEN 'Ashan'
        WHEN 190 THEN 'Dinusha'
        WHEN 191 THEN 'Rajika'
        WHEN 192 THEN 'Samanthi'
        WHEN 193 THEN 'Heshan'
        WHEN 194 THEN 'Dinesh'
        WHEN 195 THEN 'Ruchira'
        WHEN 196 THEN 'Ishara'
        WHEN 197 THEN 'Wasantha'
        WHEN 198 THEN 'Nisal'
        WHEN 199 THEN 'Mahesh'
        WHEN 200 THEN 'Arosha'
        ELSE 'Unknown'  -- Set a default name to avoid NULL values
    END AS name,
    to_address,
    CASE seller_id
        WHEN 151 THEN '0773000001'
        WHEN 152 THEN '0773000002'
        WHEN 153 THEN '0773000003'
        WHEN 154 THEN '0773000004'
        WHEN 155 THEN '0773000005'
        WHEN 156 THEN '0773000006'
        WHEN 157 THEN '0773000007'
        WHEN 158 THEN '0773000008'
        WHEN 159 THEN '0773000009'
        WHEN 160 THEN '0773000010'
        WHEN 161 THEN '0773000011'
        WHEN 162 THEN '0773000012'
        WHEN 163 THEN '0773000013'
        WHEN 164 THEN '0773000014'
        WHEN 165 THEN '0773000015'
        WHEN 166 THEN '0773000016'
        WHEN 167 THEN '0773000017'
        WHEN 168 THEN '0773000018'
        WHEN 169 THEN '0773000019'
        WHEN 170 THEN '0773000020'
        WHEN 171 THEN '0773000021'
        WHEN 172 THEN '0773000022'
        WHEN 173 THEN '0773000023'
        WHEN 174 THEN '0773000024'
        WHEN 175 THEN '0773000025'
        WHEN 176 THEN '0773000026'
        WHEN 177 THEN '0773000027'
        WHEN 178 THEN '0773000028'
        WHEN 179 THEN '0773000029'
        WHEN 180 THEN '0773000030'
        WHEN 181 THEN '0773000031'
        WHEN 182 THEN '0773000032'
        WHEN 183 THEN '0773000033'
        WHEN 184 THEN '0773000034'
        WHEN 185 THEN '0773000035'
        WHEN 186 THEN '0773000036'
        WHEN 187 THEN '0773000037'
        WHEN 188 THEN '0773000038'
        WHEN 189 THEN '0773000039'
        WHEN 190 THEN '0773000040'
        WHEN 191 THEN '0773000041'
        WHEN 192 THEN '0773000042'
        WHEN 193 THEN '0773000043'
        WHEN 194 THEN '0773000044'
        WHEN 195 THEN '0773000045'
        WHEN 196 THEN '0773000046'
        WHEN 197 THEN '0773000047'
        WHEN 198 THEN '0773000048'
        WHEN 199 THEN '0773000049'
        WHEN 200 THEN '0773000050'
        ELSE 'Unknown'  -- Set a default contact number
    END AS contact_number
FROM Sellers
WHERE seller_id BETWEEN 151 AND 200;

INSERT INTO Receivers (name, address, contact_number)
SELECT 
    CASE seller_id
        WHEN 201 THEN 'Achintha'
        WHEN 202 THEN 'Ahinsa'
        WHEN 203 THEN 'Anura'
        WHEN 204 THEN 'Amal'
        WHEN 205 THEN 'Anil'
        WHEN 206 THEN 'Ayodya'
        WHEN 207 THEN 'Amara'
        WHEN 208 THEN 'Aruna'
        WHEN 209 THEN 'Abiman'
        WHEN 210 THEN 'Asiri'
        WHEN 211 THEN 'Bandara'
        WHEN 212 THEN 'Bigun'
        WHEN 213 THEN 'Bimantha'
        WHEN 214 THEN 'Binada'
        WHEN 215 THEN 'Binuka'
        WHEN 216 THEN 'Bimal'
        WHEN 217 THEN 'Bawantha'
        WHEN 218 THEN 'Banuka'
        WHEN 219 THEN 'Baji'
        WHEN 220 THEN 'Basnayaka'
        WHEN 221 THEN 'Chamith'
        WHEN 222 THEN 'Chanaka'
        WHEN 223 THEN 'Chathura'
        WHEN 224 THEN 'Chamal'
        WHEN 225 THEN 'Chandani'
        WHEN 226 THEN 'Chathura'
        WHEN 227 THEN 'Chanchala'
        WHEN 228 THEN 'Chamari'
        WHEN 229 THEN 'Chathuranga'
        WHEN 230 THEN 'Chulani'
        WHEN 231 THEN 'Charuka'
        WHEN 232 THEN 'Chamil'
        WHEN 233 THEN 'Chanuka'
        WHEN 234 THEN 'Chimantha'
        WHEN 235 THEN 'Charuki'
        WHEN 236 THEN 'Dimantha'
        WHEN 237 THEN 'Deesara'
        WHEN 238 THEN 'Dileepa'
        WHEN 239 THEN 'Dinuga'
        WHEN 240 THEN 'Dulnith'
        WHEN 241 THEN 'Dilan'
        WHEN 242 THEN 'Dayan'
        WHEN 243 THEN 'Duleeka'
        WHEN 244 THEN 'Dulneth'
        WHEN 245 THEN 'Deepika'
        WHEN 246 THEN 'Dumidu'
        WHEN 247 THEN 'Dasindu'
        WHEN 248 THEN 'Darindu'
        WHEN 249 THEN 'Dinithi'
        WHEN 250 THEN 'Dineth'
        ELSE 'Unknown'  -- Default to avoid NULL values
    END AS name,
    to_address,
    CASE seller_id
        WHEN 201 THEN '0774000001'
        WHEN 202 THEN '0774000002'
        WHEN 203 THEN '0774000003'
        WHEN 204 THEN '0774000004'
        WHEN 205 THEN '0774000005'
        WHEN 206 THEN '0774000006'
        WHEN 207 THEN '0774000007'
        WHEN 208 THEN '0774000008'
        WHEN 209 THEN '0774000009'
        WHEN 210 THEN '0774000010'
        WHEN 211 THEN '0774000011'
        WHEN 212 THEN '0774000012'
        WHEN 213 THEN '0774000013'
        WHEN 214 THEN '0774000014'
        WHEN 215 THEN '0774000015'
        WHEN 216 THEN '0774000016'
        WHEN 217 THEN '0774000017'
        WHEN 218 THEN '0774000018'
        WHEN 219 THEN '0774000019'
        WHEN 220 THEN '0774000020'
        WHEN 221 THEN '0774000021'
        WHEN 222 THEN '0774000022'
        WHEN 223 THEN '0774000023'
        WHEN 224 THEN '0774000024'
        WHEN 225 THEN '0774000025'
        WHEN 226 THEN '0774000026'
        WHEN 227 THEN '0774000027'
        WHEN 228 THEN '0774000028'
        WHEN 229 THEN '0774000029'
        WHEN 230 THEN '0774000030'
        WHEN 231 THEN '0774000031'
        WHEN 232 THEN '0774000032'
        WHEN 233 THEN '0774000033'
        WHEN 234 THEN '0774000034'
        WHEN 235 THEN '0774000035'
        WHEN 236 THEN '0774000036'
        WHEN 237 THEN '0774000037'
        WHEN 238 THEN '0774000038'
        WHEN 239 THEN '0774000039'
        WHEN 240 THEN '0774000040'
        WHEN 241 THEN '0774000041'
        WHEN 242 THEN '0774000042'
        WHEN 243 THEN '0774000043'
        WHEN 244 THEN '0774000044'
        WHEN 245 THEN '0774000045'
        WHEN 246 THEN '0774000046'
        WHEN 247 THEN '0774000047'
        WHEN 248 THEN '0774000048'
        WHEN 249 THEN '0774000049'
        WHEN 250 THEN '0774000050'
        ELSE 'Unknown'  -- Default to avoid NULL values
    END AS contact_number
FROM Sellers
WHERE seller_id BETWEEN 201 AND 250;

INSERT INTO Receivers (name, address, contact_number)
SELECT 
    CASE seller_id
        WHEN 251 THEN 'Bandara'
        WHEN 252 THEN 'Bigun'
        WHEN 253 THEN 'Bimantha'
        WHEN 254 THEN 'Binada'
        WHEN 255 THEN 'Binuka'
        WHEN 256 THEN 'Bimal'
        WHEN 257 THEN 'Bawantha'
        WHEN 258 THEN 'Banuka'
        WHEN 259 THEN 'Baji'
        WHEN 260 THEN 'Basnayaka'
        WHEN 261 THEN 'Chamith'
        WHEN 262 THEN 'Chanaka'
        WHEN 263 THEN 'Chathura'
        WHEN 264 THEN 'Chamal'
        WHEN 265 THEN 'Chandani'
        WHEN 266 THEN 'Chanchala'
        WHEN 267 THEN 'Chamari'
        WHEN 268 THEN 'Chathuranga'
        WHEN 269 THEN 'Chulani'
        WHEN 270 THEN 'Charuka'
        WHEN 271 THEN 'Chamil'
        WHEN 272 THEN 'Chanuka'
        WHEN 273 THEN 'Chimantha'
        WHEN 274 THEN 'Charuki'
        WHEN 275 THEN 'Dimantha'
        WHEN 276 THEN 'Deesara'
        WHEN 277 THEN 'Dileepa'
        WHEN 278 THEN 'Dinuga'
        WHEN 279 THEN 'Dulnith'
        WHEN 280 THEN 'Dilan'
        WHEN 281 THEN 'Dayan'
        WHEN 282 THEN 'Duleeka'
        WHEN 283 THEN 'Dulneth'
        WHEN 284 THEN 'Deepika'
        WHEN 285 THEN 'Dumidu'
        WHEN 286 THEN 'Dasindu'
        WHEN 287 THEN 'Darindu'
        WHEN 288 THEN 'Dinithi'
        WHEN 289 THEN 'Dineth'
        WHEN 290 THEN 'Eshan'
        WHEN 291 THEN 'Eshani'
        WHEN 292 THEN 'Edirisinghe'
        WHEN 293 THEN 'Eranga'
        WHEN 294 THEN 'Fathima'
        WHEN 295 THEN 'Fazran'
        WHEN 296 THEN 'Ganga'
        WHEN 297 THEN 'Gunawardana'
        WHEN 298 THEN 'Gagamini'
        WHEN 299 THEN 'Galaya'
        WHEN 300 THEN 'Galiwar'
        ELSE 'Unknown'
    END AS name,
    to_address,
    CASE seller_id
        WHEN 251 THEN '0774000051'
        WHEN 252 THEN '0774000052'
        WHEN 253 THEN '0774000053'
        WHEN 254 THEN '0774000054'
        WHEN 255 THEN '0774000055'
        WHEN 256 THEN '0774000056'
        WHEN 257 THEN '0774000057'
        WHEN 258 THEN '0774000058'
        WHEN 259 THEN '0774000059'
        WHEN 260 THEN '0774000060'
        WHEN 261 THEN '0774000061'
        WHEN 262 THEN '0774000062'
        WHEN 263 THEN '0774000063'
        WHEN 264 THEN '0774000064'
        WHEN 265 THEN '0774000065'
        WHEN 266 THEN '0774000066'
        WHEN 267 THEN '0774000067'
        WHEN 268 THEN '0774000068'
        WHEN 269 THEN '0774000069'
        WHEN 270 THEN '0774000070'
        WHEN 271 THEN '0774000071'
        WHEN 272 THEN '0774000072'
        WHEN 273 THEN '0774000073'
        WHEN 274 THEN '0774000074'
        WHEN 275 THEN '0774000075'
        WHEN 276 THEN '0774000076'
        WHEN 277 THEN '0774000077'
        WHEN 278 THEN '0774000078'
        WHEN 279 THEN '0774000079'
        WHEN 280 THEN '0774000080'
        WHEN 281 THEN '0774000081'
        WHEN 282 THEN '0774000082'
        WHEN 283 THEN '0774000083'
        WHEN 284 THEN '0774000084'
        WHEN 285 THEN '0774000085'
        WHEN 286 THEN '0774000086'
        WHEN 287 THEN '0774000087'
        WHEN 288 THEN '0774000088'
        WHEN 289 THEN '0774000089'
        WHEN 290 THEN '0774000090'
        WHEN 291 THEN '0774000091'
        WHEN 292 THEN '0774000092'
        WHEN 293 THEN '0774000093'
        WHEN 294 THEN '0774000094'
        WHEN 295 THEN '0774000095'
        WHEN 296 THEN '0774000096'
        WHEN 297 THEN '0774000097'
        WHEN 298 THEN '0774000098'
        WHEN 299 THEN '0774000099'
        WHEN 300 THEN '0774000100'
        ELSE 'Unknown'
    END AS contact_number
FROM Sellers
WHERE seller_id BETWEEN 251 AND 300;



INSERT INTO Parcels (seller_id, receiver_id, destination_post_office, amount, weight, commission, barcode) VALUES
(1, 1, (SELECT destination_PO FROM Sellers WHERE seller_id = 1), 45.50, 2.15, 5.20, 'BARCODE100001'),
(2, 2, (SELECT destination_PO FROM Sellers WHERE seller_id = 2), 67.30, 3.55, 6.75, 'BARCODE100002'),
(3, 3, (SELECT destination_PO FROM Sellers WHERE seller_id = 3), 88.40, 4.25, 8.10, 'BARCODE100003'),
(4, 4, (SELECT destination_PO FROM Sellers WHERE seller_id = 4), 59.20, 2.85, 7.00, 'BARCODE100004'),
(5, 5, (SELECT destination_PO FROM Sellers WHERE seller_id = 5), 34.10, 1.50, 3.20, 'BARCODE100005'),
(6, 6, (SELECT destination_PO FROM Sellers WHERE seller_id = 6), 79.60, 3.75, 9.50, 'BARCODE100006'),
(7, 7, (SELECT destination_PO FROM Sellers WHERE seller_id = 7), 52.75, 2.90, 5.40, 'BARCODE100007'),
(8, 8, (SELECT destination_PO FROM Sellers WHERE seller_id = 8), 63.50, 2.45, 7.30, 'BARCODE100008'),
(9, 9, (SELECT destination_PO FROM Sellers WHERE seller_id = 9), 72.30, 3.20, 6.10, 'BARCODE100009'),
(10, 10, (SELECT destination_PO FROM Sellers WHERE seller_id = 10), 48.70, 2.55, 5.60, 'BARCODE100010'),
(11, 11, (SELECT destination_PO FROM Sellers WHERE seller_id = 11), 53.20, 3.10, 5.90, 'BARCODE100011'),
(12, 12, (SELECT destination_PO FROM Sellers WHERE seller_id = 12), 42.80, 2.35, 4.10, 'BARCODE100012'),
(13, 13, (SELECT destination_PO FROM Sellers WHERE seller_id = 13), 65.40, 3.45, 6.80, 'BARCODE100013'),
(14, 14, (SELECT destination_PO FROM Sellers WHERE seller_id = 14), 74.10, 2.95, 7.20, 'BARCODE100014'),
(15, 15, (SELECT destination_PO FROM Sellers WHERE seller_id = 15), 50.00, 1.80, 4.50, 'BARCODE100015'),
(16, 16, (SELECT destination_PO FROM Sellers WHERE seller_id = 16), 61.30, 3.00, 5.30, 'BARCODE100016'),
(17, 17, (SELECT destination_PO FROM Sellers WHERE seller_id = 17), 69.80, 2.70, 6.40, 'BARCODE100017'),
(18, 18, (SELECT destination_PO FROM Sellers WHERE seller_id = 18), 56.90, 2.50, 5.60, 'BARCODE100018'),
(19, 19, (SELECT destination_PO FROM Sellers WHERE seller_id = 19), 60.10, 2.20, 5.00, 'BARCODE100019'),
(20, 20, (SELECT destination_PO FROM Sellers WHERE seller_id = 20), 77.50, 3.35, 8.10, 'BARCODE100020'),
(21, 21, (SELECT destination_PO FROM Sellers WHERE seller_id = 21), 49.30, 1.95, 4.80, 'BARCODE100021'),
(22, 22, (SELECT destination_PO FROM Sellers WHERE seller_id = 22), 68.20, 2.60, 6.20, 'BARCODE100022'),
(23, 23, (SELECT destination_PO FROM Sellers WHERE seller_id = 23), 54.10, 2.40, 5.10, 'BARCODE100023'),
(24, 24, (SELECT destination_PO FROM Sellers WHERE seller_id = 24), 45.90, 1.75, 3.90, 'BARCODE100024'),
(25, 25, (SELECT destination_PO FROM Sellers WHERE seller_id = 25), 71.20, 3.00, 6.90, 'BARCODE100025'),
(26, 26, (SELECT destination_PO FROM Sellers WHERE seller_id = 26), 59.50, 2.80, 6.00, 'BARCODE100026'),
(27, 27, (SELECT destination_PO FROM Sellers WHERE seller_id = 27), 67.70, 3.25, 7.10, 'BARCODE100027'),
(28, 28, (SELECT destination_PO FROM Sellers WHERE seller_id = 28), 62.30, 3.10, 6.80, 'BARCODE100028'),
(29, 29, (SELECT destination_PO FROM Sellers WHERE seller_id = 29), 48.20, 2.20, 4.50, 'BARCODE100029'),
(30, 30, (SELECT destination_PO FROM Sellers WHERE seller_id = 30), 64.90, 2.60, 5.70, 'BARCODE100030'),
(31, 31, (SELECT destination_PO FROM Sellers WHERE seller_id = 31), 52.80, 2.40, 5.30, 'BARCODE100031'),
(32, 32, (SELECT destination_PO FROM Sellers WHERE seller_id = 32), 58.10, 2.95, 5.80, 'BARCODE100032'),
(33, 33, (SELECT destination_PO FROM Sellers WHERE seller_id = 33), 49.60, 2.00, 4.90, 'BARCODE100033'),
(34, 34, (SELECT destination_PO FROM Sellers WHERE seller_id = 34), 73.30, 3.20, 7.20, 'BARCODE100034'),
(35, 35, (SELECT destination_PO FROM Sellers WHERE seller_id = 35), 62.40, 2.85, 6.50, 'BARCODE100035'),
(36, 36, (SELECT destination_PO FROM Sellers WHERE seller_id = 36), 53.90, 2.35, 4.90, 'BARCODE100036'),
(37, 37, (SELECT destination_PO FROM Sellers WHERE seller_id = 37), 71.00, 3.00, 6.70, 'BARCODE100037'),
(38, 38, (SELECT destination_PO FROM Sellers WHERE seller_id = 38), 63.10, 3.15, 6.90, 'BARCODE100038'),
(39, 39, (SELECT destination_PO FROM Sellers WHERE seller_id = 39), 55.70, 2.75, 5.80, 'BARCODE100039'),
(40, 40, (SELECT destination_PO FROM Sellers WHERE seller_id = 40), 58.50, 2.60, 5.20, 'BARCODE100040'),
(41, 41, (SELECT destination_PO FROM Sellers WHERE seller_id = 41), 74.80, 3.40, 7.50, 'BARCODE100041'),
(42, 42, (SELECT destination_PO FROM Sellers WHERE seller_id = 42), 49.30, 2.05, 4.50, 'BARCODE100042'),
(43, 43, (SELECT destination_PO FROM Sellers WHERE seller_id = 43), 66.20, 2.90, 6.30, 'BARCODE100043'),
(44, 44, (SELECT destination_PO FROM Sellers WHERE seller_id = 44), 57.10, 2.70, 5.80, 'BARCODE100044'),
(45, 45, (SELECT destination_PO FROM Sellers WHERE seller_id = 45), 60.50, 3.10, 5.90, 'BARCODE100045'),
(46, 46, (SELECT destination_PO FROM Sellers WHERE seller_id = 46), 53.20, 2.85, 5.50, 'BARCODE100046'),
(47, 47, (SELECT destination_PO FROM Sellers WHERE seller_id = 47), 75.40, 3.20, 7.30, 'BARCODE100047'),
(48, 48, (SELECT destination_PO FROM Sellers WHERE seller_id = 48), 68.30, 3.05, 6.80, 'BARCODE100048'),
(49, 49, (SELECT destination_PO FROM Sellers WHERE seller_id = 49), 59.20, 2.55, 5.60, 'BARCODE100049'),
(50, 50, (SELECT destination_PO FROM Sellers WHERE seller_id = 50), 54.90, 2.45, 5.10, 'BARCODE100050');



INSERT INTO Parcels (seller_id, receiver_id, destination_post_office, amount, weight, commission, barcode) VALUES
(51, 51, (SELECT destination_PO FROM Sellers WHERE seller_id = 51), 65.60, 3.40, 6.90, 'BARCODE100051'),
(52, 52, (SELECT destination_PO FROM Sellers WHERE seller_id = 52), 72.40, 3.10, 7.30, 'BARCODE100052'),
(53, 53, (SELECT destination_PO FROM Sellers WHERE seller_id = 53), 61.80, 2.95, 6.50, 'BARCODE100053'),
(54, 54, (SELECT destination_PO FROM Sellers WHERE seller_id = 54), 70.90, 3.15, 7.00, 'BARCODE100054'),
(55, 55, (SELECT destination_PO FROM Sellers WHERE seller_id = 55), 58.30, 2.70, 5.80, 'BARCODE100055'),
(56, 56, (SELECT destination_PO FROM Sellers WHERE seller_id = 56), 75.00, 3.50, 7.40, 'BARCODE100056'),
(57, 57, (SELECT destination_PO FROM Sellers WHERE seller_id = 57), 64.50, 2.85, 6.60, 'BARCODE100057'),
(58, 58, (SELECT destination_PO FROM Sellers WHERE seller_id = 58), 80.10, 3.30, 8.10, 'BARCODE100058'),
(59, 59, (SELECT destination_PO FROM Sellers WHERE seller_id = 59), 57.20, 2.55, 5.40, 'BARCODE100059'),
(60, 60, (SELECT destination_PO FROM Sellers WHERE seller_id = 60), 68.70, 3.00, 6.80, 'BARCODE100060'),
(61, 61, (SELECT destination_PO FROM Sellers WHERE seller_id = 61), 73.90, 3.40, 7.30, 'BARCODE100061'),
(62, 62, (SELECT destination_PO FROM Sellers WHERE seller_id = 62), 66.40, 2.95, 6.90, 'BARCODE100062'),
(63, 63, (SELECT destination_PO FROM Sellers WHERE seller_id = 63), 60.10, 2.80, 5.90, 'BARCODE100063'),
(64, 64, (SELECT destination_PO FROM Sellers WHERE seller_id = 64), 72.10, 3.25, 7.00, 'BARCODE100064'),
(65, 65, (SELECT destination_PO FROM Sellers WHERE seller_id = 65), 65.40, 3.15, 6.80, 'BARCODE100065'),
(66, 66, (SELECT destination_PO FROM Sellers WHERE seller_id = 66), 59.90, 2.60, 5.60, 'BARCODE100066'),
(67, 67, (SELECT destination_PO FROM Sellers WHERE seller_id = 67), 75.50, 3.40, 7.20, 'BARCODE100067'),
(68, 68, (SELECT destination_PO FROM Sellers WHERE seller_id = 68), 62.60, 2.95, 6.40, 'BARCODE100068'),
(69, 69, (SELECT destination_PO FROM Sellers WHERE seller_id = 69), 69.70, 3.00, 6.90, 'BARCODE100069'),
(70, 70, (SELECT destination_PO FROM Sellers WHERE seller_id = 70), 64.80, 3.05, 6.20, 'BARCODE100070'),
(71, 71, (SELECT destination_PO FROM Sellers WHERE seller_id = 71), 61.20, 2.85, 6.10, 'BARCODE100071'),
(72, 72, (SELECT destination_PO FROM Sellers WHERE seller_id = 72), 66.70, 3.25, 7.10, 'BARCODE100072'),
(73, 73, (SELECT destination_PO FROM Sellers WHERE seller_id = 73), 70.80, 3.35, 7.50, 'BARCODE100073'),
(74, 74, (SELECT destination_PO FROM Sellers WHERE seller_id = 74), 55.10, 2.75, 5.00, 'BARCODE100074'),
(75, 75, (SELECT destination_PO FROM Sellers WHERE seller_id = 75), 63.30, 3.00, 6.00, 'BARCODE100075'),
(76, 76, (SELECT destination_PO FROM Sellers WHERE seller_id = 76), 70.20, 3.40, 7.20, 'BARCODE100076'),
(77, 77, (SELECT destination_PO FROM Sellers WHERE seller_id = 77), 64.10, 2.85, 6.10, 'BARCODE100077'),
(78, 78, (SELECT destination_PO FROM Sellers WHERE seller_id = 78), 69.00, 3.10, 6.70, 'BARCODE100078'),
(79, 79, (SELECT destination_PO FROM Sellers WHERE seller_id = 79), 72.60, 3.20, 7.40, 'BARCODE100079'),
(80, 80, (SELECT destination_PO FROM Sellers WHERE seller_id = 80), 66.00, 3.30, 6.80, 'BARCODE100080'),
(81, 81, (SELECT destination_PO FROM Sellers WHERE seller_id = 81), 77.20, 3.45, 7.80, 'BARCODE100081'),
(82, 82, (SELECT destination_PO FROM Sellers WHERE seller_id = 82), 61.00, 2.95, 5.80, 'BARCODE100082'),
(83, 83, (SELECT destination_PO FROM Sellers WHERE seller_id = 83), 65.00, 3.15, 6.50, 'BARCODE100083'),
(84, 84, (SELECT destination_PO FROM Sellers WHERE seller_id = 84), 58.90, 2.60, 5.40, 'BARCODE100084'),
(85, 85, (SELECT destination_PO FROM Sellers WHERE seller_id = 85), 72.40, 3.05, 7.00, 'BARCODE100085'),
(86, 86, (SELECT destination_PO FROM Sellers WHERE seller_id = 86), 64.70, 2.75, 6.10, 'BARCODE100086'),
(87, 87, (SELECT destination_PO FROM Sellers WHERE seller_id = 87), 78.80, 3.40, 7.50, 'BARCODE100087'),
(88, 88, (SELECT destination_PO FROM Sellers WHERE seller_id = 88), 69.50, 3.10, 6.80, 'BARCODE100088'),
(89, 89, (SELECT destination_PO FROM Sellers WHERE seller_id = 89), 75.90, 3.20, 7.30, 'BARCODE100089'),
(90, 90, (SELECT destination_PO FROM Sellers WHERE seller_id = 90), 60.80, 2.85, 5.90, 'BARCODE100090'),
(91, 91, (SELECT destination_PO FROM Sellers WHERE seller_id = 91), 63.60, 3.00, 6.20, 'BARCODE100091'),
(92, 92, (SELECT destination_PO FROM Sellers WHERE seller_id = 92), 72.50, 3.30, 7.00, 'BARCODE100092'),
(93, 93, (SELECT destination_PO FROM Sellers WHERE seller_id = 93), 69.10, 3.05, 6.50, 'BARCODE100093'),
(94, 94, (SELECT destination_PO FROM Sellers WHERE seller_id = 94), 67.80, 2.95, 6.20, 'BARCODE100094'),
(95, 95, (SELECT destination_PO FROM Sellers WHERE seller_id = 95), 74.60, 3.15, 7.10, 'BARCODE100095'),
(96, 96, (SELECT destination_PO FROM Sellers WHERE seller_id = 96), 66.90, 2.85, 6.30, 'BARCODE100096'),
(97, 97, (SELECT destination_PO FROM Sellers WHERE seller_id = 97), 77.00, 3.25, 7.40, 'BARCODE100097'),
(98, 98, (SELECT destination_PO FROM Sellers WHERE seller_id = 98), 65.80, 3.10, 6.60, 'BARCODE100098'),
(99, 99, (SELECT destination_PO FROM Sellers WHERE seller_id = 99), 60.20, 2.70, 5.30, 'BARCODE100099'),
(100, 100, (SELECT destination_PO FROM Sellers WHERE seller_id = 100), 68.80, 3.20, 6.90, 'BARCODE100100');

INSERT INTO Parcels (seller_id, receiver_id, destination_post_office, amount, weight, commission, barcode) VALUES
(101, 101, (SELECT destination_PO FROM Sellers WHERE seller_id = 101), 66.50, 3.30, 6.70, 'BARCODE100101'),
(102, 102, (SELECT destination_PO FROM Sellers WHERE seller_id = 102), 73.20, 3.15, 7.10, 'BARCODE100102'),
(103, 103, (SELECT destination_PO FROM Sellers WHERE seller_id = 103), 59.40, 2.85, 5.90, 'BARCODE100103'),
(104, 104, (SELECT destination_PO FROM Sellers WHERE seller_id = 104), 74.80, 3.45, 7.30, 'BARCODE100104'),
(105, 105, (SELECT destination_PO FROM Sellers WHERE seller_id = 105), 67.10, 3.05, 6.50, 'BARCODE100105'),
(106, 106, (SELECT destination_PO FROM Sellers WHERE seller_id = 106), 69.90, 3.00, 6.80, 'BARCODE100106'),
(107, 107, (SELECT destination_PO FROM Sellers WHERE seller_id = 107), 62.80, 3.10, 6.20, 'BARCODE100107'),
(108, 108, (SELECT destination_PO FROM Sellers WHERE seller_id = 108), 66.10, 2.95, 6.40, 'BARCODE100108'),
(109, 109, (SELECT destination_PO FROM Sellers WHERE seller_id = 109), 72.00, 3.20, 7.10, 'BARCODE100109'),
(110, 110, (SELECT destination_PO FROM Sellers WHERE seller_id = 110), 65.60, 2.85, 6.30, 'BARCODE100110'),
(111, 111, (SELECT destination_PO FROM Sellers WHERE seller_id = 111), 78.20, 3.50, 7.70, 'BARCODE100111'),
(112, 112, (SELECT destination_PO FROM Sellers WHERE seller_id = 112), 70.80, 3.15, 7.10, 'BARCODE100112'),
(113, 113, (SELECT destination_PO FROM Sellers WHERE seller_id = 113), 75.50, 3.25, 7.50, 'BARCODE100113'),
(114, 114, (SELECT destination_PO FROM Sellers WHERE seller_id = 114), 66.80, 3.30, 6.70, 'BARCODE100114'),
(115, 115, (SELECT destination_PO FROM Sellers WHERE seller_id = 115), 60.90, 2.95, 6.00, 'BARCODE100115'),
(116, 116, (SELECT destination_PO FROM Sellers WHERE seller_id = 116), 63.70, 3.05, 6.20, 'BARCODE100116'),
(117, 117, (SELECT destination_PO FROM Sellers WHERE seller_id = 117), 74.00, 3.40, 7.30, 'BARCODE100117'),
(118, 118, (SELECT destination_PO FROM Sellers WHERE seller_id = 118), 67.60, 3.00, 6.50, 'BARCODE100118'),
(119, 119, (SELECT destination_PO FROM Sellers WHERE seller_id = 119), 80.40, 3.45, 7.80, 'BARCODE100119'),
(120, 120, (SELECT destination_PO FROM Sellers WHERE seller_id = 120), 63.50, 2.90, 6.10, 'BARCODE100120'),
(121, 121, (SELECT destination_PO FROM Sellers WHERE seller_id = 121), 77.00, 3.20, 7.50, 'BARCODE100121'),
(122, 122, (SELECT destination_PO FROM Sellers WHERE seller_id = 122), 69.30, 3.10, 6.70, 'BARCODE100122'),
(123, 123, (SELECT destination_PO FROM Sellers WHERE seller_id = 123), 72.80, 3.25, 7.10, 'BARCODE100123'),
(124, 124, (SELECT destination_PO FROM Sellers WHERE seller_id = 124), 66.00, 3.00, 6.50, 'BARCODE100124'),
(125, 125, (SELECT destination_PO FROM Sellers WHERE seller_id = 125), 74.60, 3.40, 7.20, 'BARCODE100125'),
(126, 126, (SELECT destination_PO FROM Sellers WHERE seller_id = 126), 61.20, 2.85, 6.10, 'BARCODE100126'),
(127, 127, (SELECT destination_PO FROM Sellers WHERE seller_id = 127), 68.90, 3.10, 6.80, 'BARCODE100127'),
(128, 128, (SELECT destination_PO FROM Sellers WHERE seller_id = 128), 70.50, 3.20, 7.00, 'BARCODE100128'),
(129, 129, (SELECT destination_PO FROM Sellers WHERE seller_id = 129), 69.40, 3.05, 6.70, 'BARCODE100129'),
(130, 130, (SELECT destination_PO FROM Sellers WHERE seller_id = 130), 76.20, 3.30, 7.60, 'BARCODE100130'),
(131, 131, (SELECT destination_PO FROM Sellers WHERE seller_id = 131), 75.30, 3.15, 7.50, 'BARCODE100131'),
(132, 132, (SELECT destination_PO FROM Sellers WHERE seller_id = 132), 63.90, 3.00, 6.20, 'BARCODE100132'),
(133, 133, (SELECT destination_PO FROM Sellers WHERE seller_id = 133), 69.10, 2.95, 6.60, 'BARCODE100133'),
(134, 134, (SELECT destination_PO FROM Sellers WHERE seller_id = 134), 72.00, 3.25, 7.10, 'BARCODE100134'),
(135, 135, (SELECT destination_PO FROM Sellers WHERE seller_id = 135), 71.80, 3.35, 7.20, 'BARCODE100135'),
(136, 136, (SELECT destination_PO FROM Sellers WHERE seller_id = 136), 67.90, 3.05, 6.70, 'BARCODE100136'),
(137, 137, (SELECT destination_PO FROM Sellers WHERE seller_id = 137), 76.70, 3.40, 7.50, 'BARCODE100137'),
(138, 138, (SELECT destination_PO FROM Sellers WHERE seller_id = 138), 75.00, 3.25, 7.40, 'BARCODE100138'),
(139, 139, (SELECT destination_PO FROM Sellers WHERE seller_id = 139), 63.30, 2.85, 6.10, 'BARCODE100139'),
(140, 140, (SELECT destination_PO FROM Sellers WHERE seller_id = 140), 71.50, 3.00, 6.90, 'BARCODE100140'),
(141, 141, (SELECT destination_PO FROM Sellers WHERE seller_id = 141), 68.40, 3.20, 6.60, 'BARCODE100141'),
(142, 142, (SELECT destination_PO FROM Sellers WHERE seller_id = 142), 74.10, 3.30, 7.10, 'BARCODE100142'),
(143, 143, (SELECT destination_PO FROM Sellers WHERE seller_id = 143), 76.00, 3.10, 7.30, 'BARCODE100143'),
(144, 144, (SELECT destination_PO FROM Sellers WHERE seller_id = 144), 70.60, 3.00, 6.90, 'BARCODE100144'),
(145, 145, (SELECT destination_PO FROM Sellers WHERE seller_id = 145), 69.80, 3.05, 6.70, 'BARCODE100145'),
(146, 146, (SELECT destination_PO FROM Sellers WHERE seller_id = 146), 72.40, 3.20, 7.00, 'BARCODE100146'),
(147, 147, (SELECT destination_PO FROM Sellers WHERE seller_id = 147), 75.10, 3.25, 7.20, 'BARCODE100147'),
(148, 148, (SELECT destination_PO FROM Sellers WHERE seller_id = 148), 62.00, 3.00, 6.10, 'BARCODE100148'),
(149, 149, (SELECT destination_PO FROM Sellers WHERE seller_id = 149), 77.30, 3.40, 7.60, 'BARCODE100149'),
(150, 150, (SELECT destination_PO FROM Sellers WHERE seller_id = 150), 70.20, 3.30, 7.00, 'BARCODE100150');

SELECT * FROM Parcels;

INSERT INTO Parcels (seller_id, receiver_id, destination_post_office, amount, weight, commission, barcode) VALUES
(151, 151, (SELECT destination_PO FROM Sellers WHERE seller_id = 151), 85.50, 4.00, 8.50, 'BARCODE101151'),
(152, 152, (SELECT destination_PO FROM Sellers WHERE seller_id = 152), 92.30, 3.80, 9.20, 'BARCODE101152'),
(153, 153, (SELECT destination_PO FROM Sellers WHERE seller_id = 153), 78.60, 3.45, 7.80, 'BARCODE101153'),
(154, 154, (SELECT destination_PO FROM Sellers WHERE seller_id = 154), 95.20, 4.10, 9.50, 'BARCODE101154'),
(155, 155, (SELECT destination_PO FROM Sellers WHERE seller_id = 155), 83.70, 3.60, 8.40, 'BARCODE101155'),
(156, 156, (SELECT destination_PO FROM Sellers WHERE seller_id = 156), 87.80, 3.50, 8.80, 'BARCODE101156'),
(157, 157, (SELECT destination_PO FROM Sellers WHERE seller_id = 157), 91.50, 4.00, 9.10, 'BARCODE101157'),
(158, 158, (SELECT destination_PO FROM Sellers WHERE seller_id = 158), 80.20, 3.30, 8.00, 'BARCODE101158'),
(159, 159, (SELECT destination_PO FROM Sellers WHERE seller_id = 159), 76.10, 3.00, 7.60, 'BARCODE101159'),
(160, 160, (SELECT destination_PO FROM Sellers WHERE seller_id = 160), 93.70, 3.90, 9.30, 'BARCODE101160'),
(161, 161, (SELECT destination_PO FROM Sellers WHERE seller_id = 161), 88.50, 3.80, 8.90, 'BARCODE101161'),
(162, 162, (SELECT destination_PO FROM Sellers WHERE seller_id = 162), 84.10, 3.40, 8.40, 'BARCODE101162'),
(163, 163, (SELECT destination_PO FROM Sellers WHERE seller_id = 163), 78.00, 3.20, 7.80, 'BARCODE101163'),
(164, 164, (SELECT destination_PO FROM Sellers WHERE seller_id = 164), 86.30, 3.60, 8.60, 'BARCODE101164'),
(165, 165, (SELECT destination_PO FROM Sellers WHERE seller_id = 165), 90.40, 3.80, 9.00, 'BARCODE101165'),
(166, 166, (SELECT destination_PO FROM Sellers WHERE seller_id = 166), 82.20, 3.50, 8.20, 'BARCODE101166'),
(167, 167, (SELECT destination_PO FROM Sellers WHERE seller_id = 167), 79.10, 3.20, 7.90, 'BARCODE101167'),
(168, 168, (SELECT destination_PO FROM Sellers WHERE seller_id = 168), 91.80, 3.90, 9.10, 'BARCODE101168'),
(169, 169, (SELECT destination_PO FROM Sellers WHERE seller_id = 169), 94.60, 4.00, 9.50, 'BARCODE101169'),
(170, 170, (SELECT destination_PO FROM Sellers WHERE seller_id = 170), 85.40, 3.70, 8.50, 'BARCODE101170'),
(171, 171, (SELECT destination_PO FROM Sellers WHERE seller_id = 171), 90.20, 3.80, 9.10, 'BARCODE101171'),
(172, 172, (SELECT destination_PO FROM Sellers WHERE seller_id = 172), 87.90, 3.60, 8.80, 'BARCODE101172'),
(173, 173, (SELECT destination_PO FROM Sellers WHERE seller_id = 173), 92.10, 3.90, 9.20, 'BARCODE101173'),
(174, 174, (SELECT destination_PO FROM Sellers WHERE seller_id = 174), 80.90, 3.30, 8.00, 'BARCODE101174'),
(175, 175, (SELECT destination_PO FROM Sellers WHERE seller_id = 175), 77.80, 3.10, 7.80, 'BARCODE101175'),
(176, 176, (SELECT destination_PO FROM Sellers WHERE seller_id = 176), 95.10, 4.10, 9.50, 'BARCODE101176'),
(177, 177, (SELECT destination_PO FROM Sellers WHERE seller_id = 177), 84.90, 3.50, 8.40, 'BARCODE101177'),
(178, 178, (SELECT destination_PO FROM Sellers WHERE seller_id = 178), 81.50, 3.20, 8.10, 'BARCODE101178'),
(179, 179, (SELECT destination_PO FROM Sellers WHERE seller_id = 179), 83.60, 3.30, 8.30, 'BARCODE101179'),
(180, 180, (SELECT destination_PO FROM Sellers WHERE seller_id = 180), 79.60, 3.20, 7.90, 'BARCODE101180'),
(181, 181, (SELECT destination_PO FROM Sellers WHERE seller_id = 181), 78.70, 3.10, 7.80, 'BARCODE101181'),
(182, 182, (SELECT destination_PO FROM Sellers WHERE seller_id = 182), 90.60, 3.80, 9.10, 'BARCODE101182'),
(183, 183, (SELECT destination_PO FROM Sellers WHERE seller_id = 183), 85.20, 3.70, 8.50, 'BARCODE101183'),
(184, 184, (SELECT destination_PO FROM Sellers WHERE seller_id = 184), 87.00, 3.50, 8.70, 'BARCODE101184'),
(185, 185, (SELECT destination_PO FROM Sellers WHERE seller_id = 185), 92.50, 3.90, 9.30, 'BARCODE101185'),
(186, 186, (SELECT destination_PO FROM Sellers WHERE seller_id = 186), 80.10, 3.20, 8.00, 'BARCODE101186'),
(187, 187, (SELECT destination_PO FROM Sellers WHERE seller_id = 187), 81.60, 3.30, 8.10, 'BARCODE101187'),
(188, 188, (SELECT destination_PO FROM Sellers WHERE seller_id = 188), 93.30, 3.90, 9.20, 'BARCODE101188'),
(189, 189, (SELECT destination_PO FROM Sellers WHERE seller_id = 189), 78.50, 3.00, 7.70, 'BARCODE101189'),
(190, 190, (SELECT destination_PO FROM Sellers WHERE seller_id = 190), 88.80, 3.60, 8.90, 'BARCODE101190'),
(191, 191, (SELECT destination_PO FROM Sellers WHERE seller_id = 191), 76.40, 3.10, 7.80, 'BARCODE101191'),
(192, 192, (SELECT destination_PO FROM Sellers WHERE seller_id = 192), 94.90, 4.00, 9.50, 'BARCODE101192'),
(193, 193, (SELECT destination_PO FROM Sellers WHERE seller_id = 193), 85.60, 3.50, 8.60, 'BARCODE101193'),
(194, 194, (SELECT destination_PO FROM Sellers WHERE seller_id = 194), 79.90, 3.20, 8.00, 'BARCODE101194'),
(195, 195, (SELECT destination_PO FROM Sellers WHERE seller_id = 195), 93.60, 3.90, 9.30, 'BARCODE101195'),
(196, 196, (SELECT destination_PO FROM Sellers WHERE seller_id = 196), 82.80, 3.40, 8.30, 'BARCODE101196'),
(197, 197, (SELECT destination_PO FROM Sellers WHERE seller_id = 197), 79.20, 3.00, 7.80, 'BARCODE101197'),
(198, 198, (SELECT destination_PO FROM Sellers WHERE seller_id = 198), 91.30, 3.90, 9.10, 'BARCODE101198'),
(199, 199, (SELECT destination_PO FROM Sellers WHERE seller_id = 199), 76.80, 3.10, 7.70, 'BARCODE101199'),
(200, 200, (SELECT destination_PO FROM Sellers WHERE seller_id = 200), 88.10, 3.60, 8.90, 'BARCODE101200');

SELECT * FROM Receivers;


SELECT receiver_id FROM Receivers;

INSERT INTO Receivers (receiver_id, name, address, contact_number)
SELECT 
    151 AS receiver_id,  -- Explicitly set receiver_id to 151
    CASE seller_id
        WHEN 151 THEN 'Nilanthi'
        ELSE 'Unknown'  -- Default name for other sellers (if necessary)
    END AS name,
    to_address AS address,  -- Use the to_address from Sellers table
    CASE seller_id
        WHEN 151 THEN '0773000001'
        ELSE 'Unknown'  -- Default contact number for other sellers (if necessary)
    END AS contact_number
FROM Sellers
WHERE seller_id = 151;

INSERT INTO Parcels (seller_id, receiver_id, destination_post_office, amount, weight, commission, barcode) 
VALUES 
(201, 201, (SELECT destination_PO FROM Sellers WHERE seller_id = 201), 88.50, 3.80, 8.60, 'BARCODE101201'),
(202, 202, (SELECT destination_PO FROM Sellers WHERE seller_id = 202), 91.30, 3.90, 9.10, 'BARCODE101202'),
(203, 203, (SELECT destination_PO FROM Sellers WHERE seller_id = 203), 80.40, 3.30, 8.20, 'BARCODE101203'),
(204, 204, (SELECT destination_PO FROM Sellers WHERE seller_id = 204), 92.80, 4.00, 9.40, 'BARCODE101204'),
(205, 205, (SELECT destination_PO FROM Sellers WHERE seller_id = 205), 85.00, 3.50, 8.50, 'BARCODE101205'),
(206, 206, (SELECT destination_PO FROM Sellers WHERE seller_id = 206), 93.50, 3.90, 9.20, 'BARCODE101206'),
(207, 207, (SELECT destination_PO FROM Sellers WHERE seller_id = 207), 84.90, 3.60, 8.40, 'BARCODE101207'),
(208, 208, (SELECT destination_PO FROM Sellers WHERE seller_id = 208), 91.70, 3.80, 9.00, 'BARCODE101208'),
(209, 209, (SELECT destination_PO FROM Sellers WHERE seller_id = 209), 86.60, 3.50, 8.70, 'BARCODE101209'),
(210, 210, (SELECT destination_PO FROM Sellers WHERE seller_id = 210), 94.20, 3.80, 9.30, 'BARCODE101210'),
(211, 211, (SELECT destination_PO FROM Sellers WHERE seller_id = 211), 87.30, 3.40, 8.50, 'BARCODE101211'),
(212, 212, (SELECT destination_PO FROM Sellers WHERE seller_id = 212), 78.70, 3.10, 7.90, 'BARCODE101212'),
(213, 213, (SELECT destination_PO FROM Sellers WHERE seller_id = 213), 92.40, 3.90, 9.10, 'BARCODE101213'),
(214, 214, (SELECT destination_PO FROM Sellers WHERE seller_id = 214), 80.60, 3.30, 8.30, 'BARCODE101214'),
(215, 215, (SELECT destination_PO FROM Sellers WHERE seller_id = 215), 95.00, 4.10, 9.50, 'BARCODE101215'),
(216, 216, (SELECT destination_PO FROM Sellers WHERE seller_id = 216), 89.20, 3.80, 8.80, 'BARCODE101216'),
(217, 217, (SELECT destination_PO FROM Sellers WHERE seller_id = 217), 79.50, 3.00, 7.80, 'BARCODE101217'),
(218, 218, (SELECT destination_PO FROM Sellers WHERE seller_id = 218), 82.30, 3.40, 8.20, 'BARCODE101218'),
(219, 219, (SELECT destination_PO FROM Sellers WHERE seller_id = 219), 94.80, 4.00, 9.40, 'BARCODE101219'),
(220, 220, (SELECT destination_PO FROM Sellers WHERE seller_id = 220), 90.10, 3.90, 9.00, 'BARCODE101220'),
(221, 221, (SELECT destination_PO FROM Sellers WHERE seller_id = 221), 91.50, 3.80, 9.10, 'BARCODE101221'),
(222, 222, (SELECT destination_PO FROM Sellers WHERE seller_id = 222), 88.30, 3.70, 8.80, 'BARCODE101222'),
(223, 223, (SELECT destination_PO FROM Sellers WHERE seller_id = 223), 80.80, 3.20, 8.10, 'BARCODE101223'),
(224, 224, (SELECT destination_PO FROM Sellers WHERE seller_id = 224), 92.10, 3.90, 9.20, 'BARCODE101224'),
(225, 225, (SELECT destination_PO FROM Sellers WHERE seller_id = 225), 76.80, 3.10, 7.60, 'BARCODE101225'),
(226, 226, (SELECT destination_PO FROM Sellers WHERE seller_id = 226), 85.60, 3.40, 8.50, 'BARCODE101226'),
(227, 227, (SELECT destination_PO FROM Sellers WHERE seller_id = 227), 89.10, 3.80, 8.90, 'BARCODE101227'),
(228, 228, (SELECT destination_PO FROM Sellers WHERE seller_id = 228), 84.50, 3.30, 8.20, 'BARCODE101228'),
(229, 229, (SELECT destination_PO FROM Sellers WHERE seller_id = 229), 93.40, 4.00, 9.30, 'BARCODE101229'),
(230, 230, (SELECT destination_PO FROM Sellers WHERE seller_id = 230), 81.00, 3.20, 8.00, 'BARCODE101230'),
(231, 231, (SELECT destination_PO FROM Sellers WHERE seller_id = 231), 90.70, 3.80, 9.10, 'BARCODE101231'),
(232, 232, (SELECT destination_PO FROM Sellers WHERE seller_id = 232), 79.80, 3.10, 7.90, 'BARCODE101232'),
(233, 233, (SELECT destination_PO FROM Sellers WHERE seller_id = 233), 92.20, 3.90, 9.20, 'BARCODE101233'),
(234, 234, (SELECT destination_PO FROM Sellers WHERE seller_id = 234), 86.90, 3.60, 8.60, 'BARCODE101234'),
(235, 235, (SELECT destination_PO FROM Sellers WHERE seller_id = 235), 94.40, 4.10, 9.40, 'BARCODE101235'),
(236, 236, (SELECT destination_PO FROM Sellers WHERE seller_id = 236), 80.30, 3.30, 8.10, 'BARCODE101236'),
(237, 237, (SELECT destination_PO FROM Sellers WHERE seller_id = 237), 95.20, 4.00, 9.50, 'BARCODE101237'),
(238, 238, (SELECT destination_PO FROM Sellers WHERE seller_id = 238), 84.60, 3.40, 8.40, 'BARCODE101238'),
(239, 239, (SELECT destination_PO FROM Sellers WHERE seller_id = 239), 77.90, 3.10, 7.70, 'BARCODE101239'),
(240, 240, (SELECT destination_PO FROM Sellers WHERE seller_id = 240), 91.60, 3.80, 9.00, 'BARCODE101240'),
(241, 241, (SELECT destination_PO FROM Sellers WHERE seller_id = 241), 83.40, 3.20, 8.30, 'BARCODE101241'),
(242, 242, (SELECT destination_PO FROM Sellers WHERE seller_id = 242), 95.30, 4.00, 9.40, 'BARCODE101242'),
(243, 243, (SELECT destination_PO FROM Sellers WHERE seller_id = 243), 76.70, 3.00, 7.60, 'BARCODE101243'),
(244, 244, (SELECT destination_PO FROM Sellers WHERE seller_id = 244), 89.30, 3.80, 8.90, 'BARCODE101244'),
(245, 245, (SELECT destination_PO FROM Sellers WHERE seller_id = 245), 82.80, 3.50, 8.20, 'BARCODE101245'),
(246, 246, (SELECT destination_PO FROM Sellers WHERE seller_id = 246), 87.50, 3.60, 8.70, 'BARCODE101246'),
(247, 247, (SELECT destination_PO FROM Sellers WHERE seller_id = 247), 91.80, 3.90, 9.10, 'BARCODE101247'),
(248, 248, (SELECT destination_PO FROM Sellers WHERE seller_id = 248), 90.50, 3.70, 8.90, 'BARCODE101248'),
(249, 249, (SELECT destination_PO FROM Sellers WHERE seller_id = 249), 85.40, 3.40, 8.60, 'BARCODE101249'),
(250, 250, (SELECT destination_PO FROM Sellers WHERE seller_id = 250), 84.80, 3.50, 8.50, 'BARCODE101250');

INSERT INTO Parcels (seller_id, receiver_id, destination_post_office, amount, weight, commission, barcode) 
VALUES 
(251, 251, (SELECT destination_PO FROM Sellers WHERE seller_id = 251), 92.90, 3.80, 9.10, 'BARCODE101251'),
(252, 252, (SELECT destination_PO FROM Sellers WHERE seller_id = 252), 90.20, 3.60, 8.90, 'BARCODE101252'),
(253, 253, (SELECT destination_PO FROM Sellers WHERE seller_id = 253), 81.70, 3.40, 8.30, 'BARCODE101253'),
(254, 254, (SELECT destination_PO FROM Sellers WHERE seller_id = 254), 94.10, 3.90, 9.20, 'BARCODE101254'),
(255, 255, (SELECT destination_PO FROM Sellers WHERE seller_id = 255), 83.40, 3.50, 8.40, 'BARCODE101255'),
(256, 256, (SELECT destination_PO FROM Sellers WHERE seller_id = 256), 92.00, 3.80, 9.00, 'BARCODE101256'),
(257, 257, (SELECT destination_PO FROM Sellers WHERE seller_id = 257), 77.80, 3.10, 7.80, 'BARCODE101257'),
(258, 258, (SELECT destination_PO FROM Sellers WHERE seller_id = 258), 91.80, 3.90, 9.10, 'BARCODE101258'),
(259, 259, (SELECT destination_PO FROM Sellers WHERE seller_id = 259), 85.60, 3.40, 8.50, 'BARCODE101259'),
(260, 260, (SELECT destination_PO FROM Sellers WHERE seller_id = 260), 95.30, 4.00, 9.50, 'BARCODE101260'),
(261, 261, (SELECT destination_PO FROM Sellers WHERE seller_id = 261), 88.40, 3.70, 8.80, 'BARCODE101261'),
(262, 262, (SELECT destination_PO FROM Sellers WHERE seller_id = 262), 84.80, 3.30, 8.20, 'BARCODE101262'),
(263, 263, (SELECT destination_PO FROM Sellers WHERE seller_id = 263), 91.00, 3.80, 9.00, 'BARCODE101263'),
(264, 264, (SELECT destination_PO FROM Sellers WHERE seller_id = 264), 79.10, 3.00, 7.90, 'BARCODE101264'),
(265, 265, (SELECT destination_PO FROM Sellers WHERE seller_id = 265), 87.90, 3.60, 8.80, 'BARCODE101265'),
(266, 266, (SELECT destination_PO FROM Sellers WHERE seller_id = 266), 94.50, 3.90, 9.40, 'BARCODE101266'),
(267, 267, (SELECT destination_PO FROM Sellers WHERE seller_id = 267), 80.50, 3.20, 8.10, 'BARCODE101267'),
(268, 268, (SELECT destination_PO FROM Sellers WHERE seller_id = 268), 92.10, 3.80, 9.10, 'BARCODE101268'),
(269, 269, (SELECT destination_PO FROM Sellers WHERE seller_id = 269), 90.30, 3.70, 9.00, 'BARCODE101269'),
(270, 270, (SELECT destination_PO FROM Sellers WHERE seller_id = 270), 85.80, 3.50, 8.60, 'BARCODE101270'),
(271, 271, (SELECT destination_PO FROM Sellers WHERE seller_id = 271), 76.90, 3.00, 7.70, 'BARCODE101271'),
(272, 272, (SELECT destination_PO FROM Sellers WHERE seller_id = 272), 93.60, 4.00, 9.30, 'BARCODE101272'),
(273, 273, (SELECT destination_PO FROM Sellers WHERE seller_id = 273), 78.20, 3.10, 7.90, 'BARCODE101273'),
(274, 274, (SELECT destination_PO FROM Sellers WHERE seller_id = 274), 86.40, 3.40, 8.50, 'BARCODE101274'),
(275, 275, (SELECT destination_PO FROM Sellers WHERE seller_id = 275), 90.60, 3.80, 9.10, 'BARCODE101275'),
(276, 276, (SELECT destination_PO FROM Sellers WHERE seller_id = 276), 82.50, 3.20, 8.00, 'BARCODE101276'),
(277, 277, (SELECT destination_PO FROM Sellers WHERE seller_id = 277), 95.40, 4.10, 9.40, 'BARCODE101277'),
(278, 278, (SELECT destination_PO FROM Sellers WHERE seller_id = 278), 81.80, 3.30, 8.20, 'BARCODE101278'),
(279, 279, (SELECT destination_PO FROM Sellers WHERE seller_id = 279), 87.70, 3.50, 8.70, 'BARCODE101279'),
(280, 280, (SELECT destination_PO FROM Sellers WHERE seller_id = 280), 92.30, 3.90, 9.10, 'BARCODE101280'),
(281, 281, (SELECT destination_PO FROM Sellers WHERE seller_id = 281), 85.30, 3.40, 8.40, 'BARCODE101281'),
(282, 282, (SELECT destination_PO FROM Sellers WHERE seller_id = 282), 93.00, 3.80, 9.00, 'BARCODE101282'),
(283, 283, (SELECT destination_PO FROM Sellers WHERE seller_id = 283), 78.40, 3.10, 7.80, 'BARCODE101283'),
(284, 284, (SELECT destination_PO FROM Sellers WHERE seller_id = 284), 81.10, 3.30, 8.10, 'BARCODE101284'),
(285, 285, (SELECT destination_PO FROM Sellers WHERE seller_id = 285), 94.60, 4.00, 9.30, 'BARCODE101285'),
(286, 286, (SELECT destination_PO FROM Sellers WHERE seller_id = 286), 88.20, 3.60, 8.80, 'BARCODE101286'),
(287, 287, (SELECT destination_PO FROM Sellers WHERE seller_id = 287), 93.70, 3.90, 9.30, 'BARCODE101287'),
(288, 288, (SELECT destination_PO FROM Sellers WHERE seller_id = 288), 79.50, 3.20, 7.90, 'BARCODE101288'),
(289, 289, (SELECT destination_PO FROM Sellers WHERE seller_id = 289), 92.00, 3.80, 9.00, 'BARCODE101289'),
(290, 290, (SELECT destination_PO FROM Sellers WHERE seller_id = 290), 84.20, 3.30, 8.20, 'BARCODE101290'),
(291, 291, (SELECT destination_PO FROM Sellers WHERE seller_id = 291), 91.40, 3.70, 8.90, 'BARCODE101291'),
(292, 292, (SELECT destination_PO FROM Sellers WHERE seller_id = 292), 87.50, 3.60, 8.70, 'BARCODE101292'),
(293, 293, (SELECT destination_PO FROM Sellers WHERE seller_id = 293), 94.80, 4.00, 9.40, 'BARCODE101293'),
(294, 294, (SELECT destination_PO FROM Sellers WHERE seller_id = 294), 79.80, 3.10, 7.90, 'BARCODE101294'),
(295, 295, (SELECT destination_PO FROM Sellers WHERE seller_id = 295), 86.50, 3.40, 8.50, 'BARCODE101295'),
(296, 296, (SELECT destination_PO FROM Sellers WHERE seller_id = 296), 90.80, 3.70, 9.00, 'BARCODE101296'),
(297, 297, (SELECT destination_PO FROM Sellers WHERE seller_id = 297), 84.10, 3.30, 8.20, 'BARCODE101297'),
(298, 298, (SELECT destination_PO FROM Sellers WHERE seller_id = 298), 92.70, 3.90, 9.20, 'BARCODE101298'),
(299, 299, (SELECT destination_PO FROM Sellers WHERE seller_id = 299), 83.20, 3.30, 8.20, 'BARCODE101299'),
(300, 300, (SELECT destination_PO FROM Sellers WHERE seller_id = 300), 90.00, 3.80, 9.00, 'BARCODE101300');

INSERT INTO Parcels (seller_id, receiver_id, destination_post_office, amount, weight, commission, barcode) 
VALUES 
(301, 301, (SELECT destination_PO FROM Sellers WHERE seller_id = 301), 93.10, 3.90, 9.10, 'BARCODE101301'),
(302, 302, (SELECT destination_PO FROM Sellers WHERE seller_id = 302), 84.40, 3.40, 8.40, 'BARCODE101302'),
(303, 303, (SELECT destination_PO FROM Sellers WHERE seller_id = 303), 91.50, 3.70, 8.90, 'BARCODE101303'),
(304, 304, (SELECT destination_PO FROM Sellers WHERE seller_id = 304), 79.90, 3.10, 7.80, 'BARCODE101304'),
(305, 305, (SELECT destination_PO FROM Sellers WHERE seller_id = 305), 90.60, 3.80, 9.00, 'BARCODE101305'),
(306, 306, (SELECT destination_PO FROM Sellers WHERE seller_id = 306), 85.00, 3.50, 8.50, 'BARCODE101306'),
(307, 307, (SELECT destination_PO FROM Sellers WHERE seller_id = 307), 94.20, 3.90, 9.30, 'BARCODE101307'),
(308, 308, (SELECT destination_PO FROM Sellers WHERE seller_id = 308), 79.70, 3.00, 7.80, 'BARCODE101308'),
(309, 309, (SELECT destination_PO FROM Sellers WHERE seller_id = 309), 87.10, 3.60, 8.60, 'BARCODE101309'),
(310, 310, (SELECT destination_PO FROM Sellers WHERE seller_id = 310), 91.80, 3.90, 9.10, 'BARCODE101310'),
(311, 311, (SELECT destination_PO FROM Sellers WHERE seller_id = 311), 83.60, 3.40, 8.30, 'BARCODE101311'),
(312, 312, (SELECT destination_PO FROM Sellers WHERE seller_id = 312), 92.30, 3.80, 9.20, 'BARCODE101312'),
(313, 313, (SELECT destination_PO FROM Sellers WHERE seller_id = 313), 80.80, 3.10, 7.90, 'BARCODE101313'),
(314, 314, (SELECT destination_PO FROM Sellers WHERE seller_id = 314), 94.50, 3.90, 9.30, 'BARCODE101314'),
(315, 315, (SELECT destination_PO FROM Sellers WHERE seller_id = 315), 85.90, 3.50, 8.60, 'BARCODE101315'),
(316, 316, (SELECT destination_PO FROM Sellers WHERE seller_id = 316), 78.20, 3.00, 7.70, 'BARCODE101316'),
(317, 317, (SELECT destination_PO FROM Sellers WHERE seller_id = 317), 93.50, 3.90, 9.40, 'BARCODE101317'),
(318, 318, (SELECT destination_PO FROM Sellers WHERE seller_id = 318), 82.40, 3.30, 8.20, 'BARCODE101318'),
(319, 319, (SELECT destination_PO FROM Sellers WHERE seller_id = 319), 92.80, 3.80, 9.10, 'BARCODE101319'),
(320, 320, (SELECT destination_PO FROM Sellers WHERE seller_id = 320), 84.70, 3.40, 8.40, 'BARCODE101320'),
(321, 321, (SELECT destination_PO FROM Sellers WHERE seller_id = 321), 91.40, 3.70, 9.00, 'BARCODE101321'),
(322, 322, (SELECT destination_PO FROM Sellers WHERE seller_id = 322), 80.30, 3.20, 7.90, 'BARCODE101322'),
(323, 323, (SELECT destination_PO FROM Sellers WHERE seller_id = 323), 94.70, 4.00, 9.40, 'BARCODE101323'),
(324, 324, (SELECT destination_PO FROM Sellers WHERE seller_id = 324), 86.20, 3.50, 8.50, 'BARCODE101324'),
(325, 325, (SELECT destination_PO FROM Sellers WHERE seller_id = 325), 88.10, 3.60, 8.80, 'BARCODE101325'),
(326, 326, (SELECT destination_PO FROM Sellers WHERE seller_id = 326), 93.80, 3.90, 9.30, 'BARCODE101326'),
(327, 327, (SELECT destination_PO FROM Sellers WHERE seller_id = 327), 79.60, 3.10, 7.90, 'BARCODE101327'),
(328, 328, (SELECT destination_PO FROM Sellers WHERE seller_id = 328), 85.20, 3.40, 8.40, 'BARCODE101328'),
(329, 329, (SELECT destination_PO FROM Sellers WHERE seller_id = 329), 91.10, 3.80, 9.00, 'BARCODE101329'),
(330, 330, (SELECT destination_PO FROM Sellers WHERE seller_id = 330), 92.10, 3.90, 9.10, 'BARCODE101330'),
(331, 331, (SELECT destination_PO FROM Sellers WHERE seller_id = 331), 87.80, 3.60, 8.70, 'BARCODE101331'),
(332, 332, (SELECT destination_PO FROM Sellers WHERE seller_id = 332), 94.30, 4.00, 9.30, 'BARCODE101332'),
(333, 333, (SELECT destination_PO FROM Sellers WHERE seller_id = 333), 79.50, 3.10, 7.90, 'BARCODE101333'),
(334, 334, (SELECT destination_PO FROM Sellers WHERE seller_id = 334), 92.50, 3.80, 9.10, 'BARCODE101334'),
(335, 335, (SELECT destination_PO FROM Sellers WHERE seller_id = 335), 85.80, 3.40, 8.60, 'BARCODE101335'),
(336, 336, (SELECT destination_PO FROM Sellers WHERE seller_id = 336), 94.00, 3.90, 9.20, 'BARCODE101336'),
(337, 337, (SELECT destination_PO FROM Sellers WHERE seller_id = 337), 80.10, 3.20, 7.90, 'BARCODE101337'),
(338, 338, (SELECT destination_PO FROM Sellers WHERE seller_id = 338), 93.00, 3.80, 9.10, 'BARCODE101338'),
(339, 339, (SELECT destination_PO FROM Sellers WHERE seller_id = 339), 88.50, 3.60, 8.90, 'BARCODE101339'),
(340, 340, (SELECT destination_PO FROM Sellers WHERE seller_id = 340), 79.80, 3.10, 7.90, 'BARCODE101340'),
(341, 341, (SELECT destination_PO FROM Sellers WHERE seller_id = 341), 85.40, 3.30, 8.40, 'BARCODE101341'),
(342, 342, (SELECT destination_PO FROM Sellers WHERE seller_id = 342), 91.20, 3.70, 8.90, 'BARCODE101342'),
(343, 343, (SELECT destination_PO FROM Sellers WHERE seller_id = 343), 92.80, 3.90, 9.20, 'BARCODE101343'),
(344, 344, (SELECT destination_PO FROM Sellers WHERE seller_id = 344), 86.00, 3.50, 8.50, 'BARCODE101344'),
(345, 345, (SELECT destination_PO FROM Sellers WHERE seller_id = 345), 93.30, 3.90, 9.20, 'BARCODE101345'),
(346, 346, (SELECT destination_PO FROM Sellers WHERE seller_id = 346), 79.10, 3.00, 7.80, 'BARCODE101346'),
(347, 347, (SELECT destination_PO FROM Sellers WHERE seller_id = 347), 81.20, 3.20, 8.00, 'BARCODE101347'),
(348, 348, (SELECT destination_PO FROM Sellers WHERE seller_id = 348), 88.90, 3.60, 8.90, 'BARCODE101348'),
(349, 349, (SELECT destination_PO FROM Sellers WHERE seller_id = 349), 84.60, 3.40, 8.50, 'BARCODE101349'),
(350, 350, (SELECT destination_PO FROM Sellers WHERE seller_id = 350), 91.00, 3.70, 8.90, 'BARCODE101350');

INSERT INTO Receivers (name, address, contact_number)
SELECT 
    CASE seller_id
        WHEN 302 THEN 'John Doe'
        WHEN 303 THEN 'Jane Smith'
        WHEN 304 THEN 'Robert Brown'
        WHEN 305 THEN 'Emily White'
        WHEN 306 THEN 'Michael Johnson'
        WHEN 307 THEN 'Sarah Lee'
        WHEN 308 THEN 'David Harris'
        WHEN 309 THEN 'Laura Miller'
        WHEN 310 THEN 'James Clark'
        WHEN 311 THEN 'Linda Lewis'
        WHEN 312 THEN 'William Walker'
        WHEN 313 THEN 'Elizabeth Hall'
        WHEN 314 THEN 'Joseph Allen'
        WHEN 315 THEN 'Nancy Young'
        WHEN 316 THEN 'Charles King'
        WHEN 317 THEN 'Patricia Scott'
        WHEN 318 THEN 'Daniel Adams'
        WHEN 319 THEN 'Catherine Carter'
        WHEN 320 THEN 'Paul Mitchell'
        WHEN 321 THEN 'Angela Perez'
        WHEN 322 THEN 'Mark Lewis'
        WHEN 323 THEN 'Susan Walker'
        WHEN 324 THEN 'George Hall'
        WHEN 325 THEN 'Karen Allen'
        WHEN 326 THEN 'Richard Young'
        WHEN 327 THEN 'Lisa Clark'
        WHEN 328 THEN 'Thomas Adams'
        WHEN 329 THEN 'Jessica Carter'
        WHEN 330 THEN 'Brian Mitchell'
        WHEN 331 THEN 'Megan Perez'
        WHEN 332 THEN 'John Harris'
        WHEN 333 THEN 'Deborah Lewis'
        WHEN 334 THEN 'Stephen Walker'
        WHEN 335 THEN 'Dorothy Hall'
        WHEN 336 THEN 'Gary Young'
        WHEN 337 THEN 'Tina Clark'
        WHEN 338 THEN 'Paul Adams'
        WHEN 339 THEN 'Helen Carter'
        WHEN 340 THEN 'Samuel Mitchell'
        WHEN 341 THEN 'Marie Perez'
        WHEN 342 THEN 'Albert Harris'
        WHEN 343 THEN 'Grace Lewis'
        WHEN 344 THEN 'Nathan Walker'
        WHEN 345 THEN 'Evelyn Hall'
        WHEN 346 THEN 'Jacob Allen'
        WHEN 347 THEN 'Samantha Young'
        WHEN 348 THEN 'Brian Clark'
        WHEN 349 THEN 'Olivia Adams'
        WHEN 350 THEN 'Charlotte Carter'
        WHEN 351 THEN 'Benjamin Mitchell'
        WHEN 352 THEN 'Sophia Perez'
        ELSE 'Unknown'
    END AS name,
    CASE seller_id
        WHEN 302 THEN 'No. 123, Galle Road, Colombo 03'
        WHEN 303 THEN 'No. 456, Kandy Road, Nuwara Eliya'
        WHEN 304 THEN 'No. 789, Peradeniya Road, Kandy'
        WHEN 305 THEN 'No. 321, Gampaha Road, Colombo 06'
        WHEN 306 THEN 'No. 654, Main Street, Jaffna'
        WHEN 307 THEN 'No. 987, Nuwara Eliya Road, Kandy'
        WHEN 308 THEN 'No. 123, Nawala Road, Nugegoda'
        WHEN 309 THEN 'No. 432, Highlevel Road, Colombo 08'
        WHEN 310 THEN 'No. 876, Ratnapura Road, Kegalle'
        WHEN 311 THEN 'No. 321, Kurunegala Road, Colombo 05'
        WHEN 312 THEN 'No. 654, Anuradhapura Road, Polonnaruwa'
        WHEN 313 THEN 'No. 123, Colombo Road, Galle'
        WHEN 314 THEN 'No. 987, Negombo Road, Katunayake'
        WHEN 315 THEN 'No. 321, Avissawella Road, Colombo 10'
        WHEN 316 THEN 'No. 654, Moratuwa Road, Panadura'
        WHEN 317 THEN 'No. 876, Matara Road, Weligama'
        WHEN 318 THEN 'No. 432, Kalutara Road, Colombo 12'
        WHEN 319 THEN 'No. 123, Galle Road, Mount Lavinia'
        WHEN 320 THEN 'No. 987, Kandy Road, Gampaha'
        WHEN 321 THEN 'No. 654, Piliyandala Road, Colombo 14'
        WHEN 322 THEN 'No. 432, Nuwara Eliya Road, Kandy'
        WHEN 323 THEN 'No. 876, Colombo Road, Rathnapura'
        WHEN 324 THEN 'No. 321, Kelaniya Road, Kelaniya'
        WHEN 325 THEN 'No. 654, Beruwala Road, Kalutara'
        WHEN 326 THEN 'No. 123, Puttalam Road, Negombo'
        WHEN 327 THEN 'No. 987, Galle Road, Panadura'
        WHEN 328 THEN 'No. 432, Ambalangoda Road, Galle'
        WHEN 329 THEN 'No. 321, Miriswatte Road, Colombo 07'
        WHEN 330 THEN 'No. 654, Matale Road, Kandy'
        WHEN 331 THEN 'No. 876, Walasmulla Road, Matara'
        WHEN 332 THEN 'No. 123, Kelaniya Road, Colombo 09'
        WHEN 333 THEN 'No. 432, Biyagama Road, Kaduwela'
        WHEN 334 THEN 'No. 987, Colombo Road, Kandy'
        WHEN 335 THEN 'No. 876, Puttalam Road, Gampaha'
        WHEN 336 THEN 'No. 654, Nittambuwa Road, Colombo 11'
        WHEN 337 THEN 'No. 321, Thalangama Road, Battaramulla'
        WHEN 338 THEN 'No. 876, Weligama Road, Galle'
        WHEN 339 THEN 'No. 123, Kalutara Road, Colombo 04'
        WHEN 340 THEN 'No. 432, Matara Road, Colombo 13'
        WHEN 341 THEN 'No. 987, Gampaha Road, Nugegoda'
        WHEN 342 THEN 'No. 654, Kegalle Road, Rambukkana'
        WHEN 343 THEN 'No. 123, Ragama Road, Gampaha'
        WHEN 344 THEN 'No. 432, Katunayake Road, Negombo'
        WHEN 345 THEN 'No. 321, Kurunegala Road, Kegalle'
        WHEN 346 THEN 'No. 876, Hikkaduwa Road, Galle'
        WHEN 347 THEN 'No. 654, Colombo Road, Kaduwela'
        WHEN 348 THEN 'No. 987, Moratuwa Road, Dehiwala'
        WHEN 349 THEN 'No. 432, Mount Lavinia Road, Colombo 15'
        WHEN 350 THEN 'No. 123, Colombo Road, Homagama'
        WHEN 351 THEN 'No. 987, Kandy Road, Kurunegala'
        WHEN 352 THEN 'No. 654, Galle Road, Beruwala'
        ELSE 'Unknown Address'
    END AS address,
    CASE seller_id
        WHEN 302 THEN '0771234567'
        WHEN 303 THEN '0772345678'
        WHEN 304 THEN '0773456789'
        WHEN 305 THEN '0774567890'
        WHEN 306 THEN '0775678901'
        WHEN 307 THEN '0776789012'
        WHEN 308 THEN '0777890123'
        WHEN 309 THEN '0778901234'
        WHEN 310 THEN '0779012345'
        WHEN 311 THEN '0770123456'
        WHEN 312 THEN '0771234568'
        WHEN 313 THEN '0772345679'
        WHEN 314 THEN '0773456780'
        WHEN 315 THEN '0774567891'
        WHEN 316 THEN '0775678902'
        WHEN 317 THEN '0776789013'
        WHEN 318 THEN '0777890124'
        WHEN 319 THEN '0778901235'
        WHEN 320 THEN '0779012346'
        WHEN 321 THEN '0770123457'
        WHEN 322 THEN '0771234569'
        WHEN 323 THEN '0772345680'
        WHEN 324 THEN '0773456781'
        WHEN 325 THEN '0774567892'
        WHEN 326 THEN '0775678903'
        WHEN 327 THEN '0776789014'
        WHEN 328 THEN '0777890125'
        WHEN 329 THEN '0778901236'
        WHEN 330 THEN '0779012347'
        WHEN 331 THEN '0770123458'
        WHEN 332 THEN '0771234570'
        WHEN 333 THEN '0772345681'
        WHEN 334 THEN '0773456782'
        WHEN 335 THEN '0774567893'
        WHEN 336 THEN '0775678904'
        WHEN 337 THEN '0776789015'
        WHEN 338 THEN '0777890126'
        WHEN 339 THEN '0778901237'
        WHEN 340 THEN '0779012348'
        WHEN 341 THEN '0770123459'
        WHEN 342 THEN '0771234571'
        WHEN 343 THEN '0772345682'
        WHEN 344 THEN '0773456783'
        WHEN 345 THEN '0774567894'
        WHEN 346 THEN '0775678905'
        WHEN 347 THEN '0776789016'
        WHEN 348 THEN '0777890127'
        WHEN 349 THEN '0778901238'
        WHEN 350 THEN '0779012349'
        WHEN 351 THEN '0770123460'
        WHEN 352 THEN '0771234572'
        ELSE 'Unknown Number'
    END AS contact_number
FROM Sellers
WHERE seller_id BETWEEN 302 AND 352;

INSERT INTO Receivers (name, address, contact_number)
SELECT 
    CASE seller_id
        WHEN 352 THEN 'Sophia Perez'
        WHEN 353 THEN 'Liam Harris'
        WHEN 354 THEN 'Isabella Lewis'
        WHEN 355 THEN 'Ethan Walker'
        WHEN 356 THEN 'Mia Hall'
        WHEN 357 THEN 'Jackson Young'
        WHEN 358 THEN 'Olivia Clark'
        WHEN 359 THEN 'James Adams'
        WHEN 360 THEN 'Avery Carter'
        WHEN 361 THEN 'Chloe Mitchell'
        WHEN 362 THEN 'Matthew Perez'
        WHEN 363 THEN 'Amelia Harris'
        WHEN 364 THEN 'Oliver Lewis'
        WHEN 365 THEN 'Lucas Walker'
        WHEN 366 THEN 'Sophia Hall'
        WHEN 367 THEN 'Alexander Young'
        WHEN 368 THEN 'Evelyn Clark'
        WHEN 369 THEN 'Benjamin Adams'
        WHEN 370 THEN 'Charlotte Carter'
        WHEN 371 THEN 'Henry Mitchell'
        WHEN 372 THEN 'Emily Perez'
        WHEN 373 THEN 'Jack Harris'
        WHEN 374 THEN 'Aiden Lewis'
        WHEN 375 THEN 'Ella Walker'
        WHEN 376 THEN 'Ryan Hall'
        WHEN 377 THEN 'Zoe Young'
        WHEN 378 THEN 'Mason Clark'
        WHEN 379 THEN 'Harper Adams'
        WHEN 380 THEN 'Jackson Carter'
        WHEN 381 THEN 'Amelia Mitchell'
        WHEN 382 THEN 'Lucas Perez'
        WHEN 383 THEN 'Lily Harris'
        WHEN 384 THEN 'Henry Lewis'
        WHEN 385 THEN 'Isabella Walker'
        WHEN 386 THEN 'Carter Hall'
        WHEN 387 THEN 'Archer Young'
        WHEN 388 THEN 'Aiden Clark'
        WHEN 389 THEN 'Scarlett Adams'
        WHEN 390 THEN 'Mila Carter'
        WHEN 391 THEN 'Eli Mitchell'
        WHEN 392 THEN 'Grace Perez'
        WHEN 393 THEN 'Matthew Harris'
        WHEN 394 THEN 'Leah Lewis'
        WHEN 395 THEN 'Hudson Walker'
        WHEN 396 THEN 'James Hall'
        WHEN 397 THEN 'Levi Young'
        WHEN 398 THEN 'Sophie Clark'
        WHEN 399 THEN 'Madison Adams'
        WHEN 400 THEN 'Elijah Carter'
        ELSE 'Unknown'
    END AS name,
    CASE seller_id
        WHEN 352 THEN 'No. 654, Galle Road, Beruwala'
        WHEN 353 THEN 'No. 876, Highlevel Road, Kandy'
        WHEN 354 THEN 'No. 432, Matara Road, Colombo 10'
        WHEN 355 THEN 'No. 321, Nuwara Eliya Road, Kandy'
        WHEN 356 THEN 'No. 987, Gampaha Road, Colombo 11'
        WHEN 357 THEN 'No. 654, Kurunegala Road, Galle'
        WHEN 358 THEN 'No. 123, Anuradhapura Road, Polonnaruwa'
        WHEN 359 THEN 'No. 432, Kandy Road, Mount Lavinia'
        WHEN 360 THEN 'No. 876, Nittambuwa Road, Colombo 03'
        WHEN 361 THEN 'No. 321, Negombo Road, Kegalle'
        WHEN 362 THEN 'No. 654, Piliyandala Road, Colombo 04'
        WHEN 363 THEN 'No. 123, Weligama Road, Galle'
        WHEN 364 THEN 'No. 987, Puttalam Road, Kegalle'
        WHEN 365 THEN 'No. 432, Walasmulla Road, Matara'
        WHEN 366 THEN 'No. 876, Ragama Road, Gampaha'
        WHEN 367 THEN 'No. 321, Beruwala Road, Kalutara'
        WHEN 368 THEN 'No. 654, Colombo Road, Kaduwela'
        WHEN 369 THEN 'No. 987, Moratuwa Road, Mount Lavinia'
        WHEN 370 THEN 'No. 432, Galle Road, Colombo 05'
        WHEN 371 THEN 'No. 876, Kelaniya Road, Battaramulla'
        WHEN 372 THEN 'No. 123, Kurunegala Road, Galle'
        WHEN 373 THEN 'No. 654, Kandy Road, Panadura'
        WHEN 374 THEN 'No. 432, Ambalangoda Road, Nugegoda'
        WHEN 375 THEN 'No. 987, Nuwara Eliya Road, Kandy'
        WHEN 376 THEN 'No. 321, Colombo Road, Gampaha'
        WHEN 377 THEN 'No. 876, Matara Road, Colombo 08'
        WHEN 378 THEN 'No. 654, Thalangama Road, Dehiwala'
        WHEN 379 THEN 'No. 432, Kegalle Road, Polonnaruwa'
        WHEN 380 THEN 'No. 987, Ragama Road, Kegalle'
        WHEN 381 THEN 'No. 321, Galle Road, Kurunegala'
        WHEN 382 THEN 'No. 876, Nittambuwa Road, Kandy'
        WHEN 383 THEN 'No. 654, Puttalam Road, Nuwara Eliya'
        WHEN 384 THEN 'No. 432, Colombo Road, Kaduwela'
        WHEN 385 THEN 'No. 987, Matale Road, Gampaha'
        WHEN 386 THEN 'No. 321, Kelaniya Road, Colombo 02'
        WHEN 387 THEN 'No. 876, Nuwara Eliya Road, Kandy'
        WHEN 388 THEN 'No. 654, Colombo Road, Polonnaruwa'
        WHEN 389 THEN 'No. 432, Gampaha Road, Panadura'
        WHEN 390 THEN 'No. 987, Ambalangoda Road, Kalutara'
        WHEN 391 THEN 'No. 321, Kandy Road, Colombo 06'
        WHEN 392 THEN 'No. 654, Colombo Road, Kandy'
        WHEN 393 THEN 'No. 432, Thalangama Road, Weligama'
        WHEN 394 THEN 'No. 987, Galle Road, Kegalle'
        WHEN 395 THEN 'No. 321, Nuwara Eliya Road, Mount Lavinia'
        WHEN 396 THEN 'No. 876, Kalutara Road, Polonnaruwa'
        WHEN 397 THEN 'No. 654, Matara Road, Kandy'
        WHEN 398 THEN 'No. 432, Colombo Road, Galle'
        WHEN 399 THEN 'No. 987, Kurunegala Road, Kegalle'
        WHEN 400 THEN 'No. 321, Ragama Road, Polonnaruwa'
        ELSE 'Unknown Address'
    END AS address,
    CASE seller_id
        WHEN 352 THEN '0771234572'
        WHEN 353 THEN '0772345683'
        WHEN 354 THEN '0773456794'
        WHEN 355 THEN '0774567905'
        WHEN 356 THEN '0775678916'
        WHEN 357 THEN '0776789027'
        WHEN 358 THEN '0777890138'
        WHEN 359 THEN '0778901249'
        WHEN 360 THEN '0779012350'
        WHEN 361 THEN '0770123461'
        WHEN 362 THEN '0771234573'
        WHEN 363 THEN '0772345684'
        WHEN 364 THEN '0773456795'
        WHEN 365 THEN '0774567906'
        WHEN 366 THEN '0775678917'
        WHEN 367 THEN '0776789028'
        WHEN 368 THEN '0777890139'
        WHEN 369 THEN '0778901250'
        WHEN 370 THEN '0779012351'
        WHEN 371 THEN '0770123462'
        WHEN 372 THEN '0771234574'
        WHEN 373 THEN '0772345685'
        WHEN 374 THEN '0773456796'
        WHEN 375 THEN '0774567907'
        WHEN 376 THEN '0775678918'
        WHEN 377 THEN '0776789029'
        WHEN 378 THEN '0777890140'
        WHEN 379 THEN '0778901251'
        WHEN 380 THEN '0779012352'
        WHEN 381 THEN '0770123463'
        WHEN 382 THEN '0771234575'
        WHEN 383 THEN '0772345686'
        WHEN 384 THEN '0773456797'
        WHEN 385 THEN '0774567908'
        WHEN 386 THEN '0775678919'
        WHEN 387 THEN '0776789030'
        WHEN 388 THEN '0777890141'
        WHEN 389 THEN '0778901252'
        WHEN 390 THEN '0779012353'
        WHEN 391 THEN '0770123464'
        WHEN 392 THEN '0771234576'
        WHEN 393 THEN '0772345687'
        WHEN 394 THEN '0773456798'
        WHEN 395 THEN '0774567909'
        WHEN 396 THEN '0775678920'
        WHEN 397 THEN '0776789031'
        WHEN 398 THEN '0777890142'
        WHEN 399 THEN '0778901253'
        WHEN 400 THEN '0779012354'
        ELSE 'Unknown Number'
    END AS contact_number
FROM Sellers
WHERE seller_id BETWEEN 352 AND 400;

INSERT INTO Parcels (seller_id, receiver_id, destination_post_office, amount, weight, commission, barcode) 
VALUES 
(351, 351, (SELECT destination_PO FROM Sellers WHERE seller_id = 351), 92.40, 3.90, 9.20, 'BARCODE101351'),
(352, 352, (SELECT destination_PO FROM Sellers WHERE seller_id = 352), 84.90, 3.30, 8.40, 'BARCODE101352'),
(353, 353, (SELECT destination_PO FROM Sellers WHERE seller_id = 353), 91.10, 3.80, 8.90, 'BARCODE101353'),
(354, 354, (SELECT destination_PO FROM Sellers WHERE seller_id = 354), 80.50, 3.20, 7.90, 'BARCODE101354'),
(355, 355, (SELECT destination_PO FROM Sellers WHERE seller_id = 355), 93.20, 3.90, 9.30, 'BARCODE101355'),
(356, 356, (SELECT destination_PO FROM Sellers WHERE seller_id = 356), 85.50, 3.40, 8.50, 'BARCODE101356'),
(357, 357, (SELECT destination_PO FROM Sellers WHERE seller_id = 357), 94.40, 4.00, 9.40, 'BARCODE101357'),
(358, 358, (SELECT destination_PO FROM Sellers WHERE seller_id = 358), 79.80, 3.00, 7.80, 'BARCODE101358'),
(359, 359, (SELECT destination_PO FROM Sellers WHERE seller_id = 359), 88.30, 3.60, 8.80, 'BARCODE101359'),
(360, 360, (SELECT destination_PO FROM Sellers WHERE seller_id = 360), 91.70, 3.90, 9.00, 'BARCODE101360'),
(361, 361, (SELECT destination_PO FROM Sellers WHERE seller_id = 361), 84.10, 3.30, 8.30, 'BARCODE101361'),
(362, 362, (SELECT destination_PO FROM Sellers WHERE seller_id = 362), 92.00, 3.80, 9.10, 'BARCODE101362'),
(363, 363, (SELECT destination_PO FROM Sellers WHERE seller_id = 363), 79.20, 3.10, 7.80, 'BARCODE101363'),
(364, 364, (SELECT destination_PO FROM Sellers WHERE seller_id = 364), 94.10, 3.90, 9.20, 'BARCODE101364'),
(365, 365, (SELECT destination_PO FROM Sellers WHERE seller_id = 365), 86.30, 3.50, 8.60, 'BARCODE101365'),
(366, 366, (SELECT destination_PO FROM Sellers WHERE seller_id = 366), 93.60, 3.90, 9.30, 'BARCODE101366'),
(367, 367, (SELECT destination_PO FROM Sellers WHERE seller_id = 367), 78.10, 3.00, 7.70, 'BARCODE101367'),
(368, 368, (SELECT destination_PO FROM Sellers WHERE seller_id = 368), 81.90, 3.20, 8.10, 'BARCODE101368'),
(369, 369, (SELECT destination_PO FROM Sellers WHERE seller_id = 369), 88.00, 3.50, 8.80, 'BARCODE101369'),
(370, 370, (SELECT destination_PO FROM Sellers WHERE seller_id = 370), 84.80, 3.40, 8.40, 'BARCODE101370'),
(371, 371, (SELECT destination_PO FROM Sellers WHERE seller_id = 371), 91.30, 3.80, 9.00, 'BARCODE101371'),
(372, 372, (SELECT destination_PO FROM Sellers WHERE seller_id = 372), 92.20, 3.90, 9.10, 'BARCODE101372'),
(373, 373, (SELECT destination_PO FROM Sellers WHERE seller_id = 373), 85.70, 3.50, 8.60, 'BARCODE101373'),
(374, 374, (SELECT destination_PO FROM Sellers WHERE seller_id = 374), 79.90, 3.10, 7.80, 'BARCODE101374'),
(375, 375, (SELECT destination_PO FROM Sellers WHERE seller_id = 375), 91.80, 3.90, 9.10, 'BARCODE101375'),
(376, 376, (SELECT destination_PO FROM Sellers WHERE seller_id = 376), 93.40, 3.90, 9.30, 'BARCODE101376'),
(377, 377, (SELECT destination_PO FROM Sellers WHERE seller_id = 377), 79.60, 3.10, 7.90, 'BARCODE101377'),
(378, 378, (SELECT destination_PO FROM Sellers WHERE seller_id = 378), 85.40, 3.30, 8.50, 'BARCODE101378'),
(379, 379, (SELECT destination_PO FROM Sellers WHERE seller_id = 379), 91.60, 3.80, 9.00, 'BARCODE101379'),
(380, 380, (SELECT destination_PO FROM Sellers WHERE seller_id = 380), 92.80, 3.90, 9.10, 'BARCODE101380'),
(381, 381, (SELECT destination_PO FROM Sellers WHERE seller_id = 381), 84.60, 3.40, 8.50, 'BARCODE101381'),
(382, 382, (SELECT destination_PO FROM Sellers WHERE seller_id = 382), 92.50, 3.90, 9.10, 'BARCODE101382'),
(383, 383, (SELECT destination_PO FROM Sellers WHERE seller_id = 383), 81.50, 3.20, 8.10, 'BARCODE101383'),
(384, 384, (SELECT destination_PO FROM Sellers WHERE seller_id = 384), 94.60, 4.00, 9.40, 'BARCODE101384'),
(385, 385, (SELECT destination_PO FROM Sellers WHERE seller_id = 385), 85.20, 3.30, 8.40, 'BARCODE101385'),
(386, 386, (SELECT destination_PO FROM Sellers WHERE seller_id = 386), 88.20, 3.50, 8.90, 'BARCODE101386'),
(387, 387, (SELECT destination_PO FROM Sellers WHERE seller_id = 387), 91.90, 3.90, 9.10, 'BARCODE101387'),
(388, 388, (SELECT destination_PO FROM Sellers WHERE seller_id = 388), 93.30, 3.90, 9.20, 'BARCODE101388'),
(389, 389, (SELECT destination_PO FROM Sellers WHERE seller_id = 389), 79.50, 3.10, 7.90, 'BARCODE101389'),
(390, 390, (SELECT destination_PO FROM Sellers WHERE seller_id = 390), 85.60, 3.40, 8.50, 'BARCODE101390'),
(391, 391, (SELECT destination_PO FROM Sellers WHERE seller_id = 391), 91.40, 3.80, 8.90, 'BARCODE101391'),
(392, 392, (SELECT destination_PO FROM Sellers WHERE seller_id = 392), 92.10, 3.90, 9.00, 'BARCODE101392'),
(393, 393, (SELECT destination_PO FROM Sellers WHERE seller_id = 393), 84.70, 3.40, 8.40, 'BARCODE101393'),
(394, 394, (SELECT destination_PO FROM Sellers WHERE seller_id = 394), 90.80, 3.70, 8.90, 'BARCODE101394'),
(395, 395, (SELECT destination_PO FROM Sellers WHERE seller_id = 395), 91.50, 3.80, 9.00, 'BARCODE101395'),
(396, 396, (SELECT destination_PO FROM Sellers WHERE seller_id = 396), 85.90, 3.50, 8.60, 'BARCODE101396'),
(397, 397, (SELECT destination_PO FROM Sellers WHERE seller_id = 397), 93.80, 4.00, 9.30, 'BARCODE101397'),
(398, 398, (SELECT destination_PO FROM Sellers WHERE seller_id = 398), 79.20, 3.00, 7.80, 'BARCODE101398'),
(399, 399, (SELECT destination_PO FROM Sellers WHERE seller_id = 399), 86.00, 3.40, 8.50, 'BARCODE101399'),
(400, 400, (SELECT destination_PO FROM Sellers WHERE seller_id = 400), 92.60, 3.90, 9.20, 'BARCODE101400');



ALTER TABLE Sellers
ADD COLUMN parcel_barcode VARCHAR(255);


UPDATE Sellers s
JOIN parcel p ON s.seller_id = p.seller_id
SET s.parcel_barcode = p.barcode;

SELECT * FROM Sellers;


UPDATE Sellers s
SET parcel_barcode = p.barcode
FROM Parcels p
WHERE s.seller_id = p.seller_id;

INSERT INTO Transactions (parcel_id, amount, status)
VALUES 
    (1, 100.00, 'Pending'),
    (2, 200.50, 'Completed'),
    (3, 150.75, 'Failed'),
    (4, 300.00, 'Pending'),
    (5, 500.00, 'Completed'),
    (6, 450.25, 'Pending'),
    (7, 125.00, 'Completed'),
    (8, 275.00, 'Pending'),
    (9, 350.00, 'Completed'),
    (10, 400.00, 'Failed'),
    (11, 220.50, 'Completed'),
    (12, 300.00, 'Pending'),
    (13, 380.75, 'Failed'),
    (14, 450.00, 'Completed'),
    (15, 500.00, 'Pending'),
    (16, 550.25, 'Completed'),
    (17, 600.00, 'Pending'),
    (18, 650.00, 'Completed'),
    (19, 700.00, 'Pending'),
    (20, 750.50, 'Completed'),
    (21, 800.00, 'Failed'),
    (22, 850.00, 'Pending'),
    (23, 900.00, 'Completed'),
    (24, 950.50, 'Failed'),
    (25, 1000.00, 'Pending'),
    (26, 1100.00, 'Completed'),
    (27, 1150.50, 'Pending'),
    (28, 1200.00, 'Completed'),
    (29, 1250.00, 'Failed'),
    (30, 1300.50, 'Pending'),
    (31, 1350.00, 'Completed'),
    (32, 1400.00, 'Pending'),
    (33, 1450.00, 'Failed'),
    (34, 1500.00, 'Completed'),
    (35, 1550.50, 'Pending'),
    (36, 1600.00, 'Completed'),
    (37, 1650.00, 'Failed'),
    (38, 1700.50, 'Pending'),
    (39, 1750.00, 'Completed'),
    (40, 1800.00, 'Failed'),
    (41, 1850.50, 'Pending'),
    (42, 1900.00, 'Completed'),
    (43, 1950.00, 'Failed'),
    (44, 2000.00, 'Pending'),
    (45, 2100.00, 'Completed'),
    (46, 2150.00, 'Pending'),
    (47, 2200.00, 'Completed'),
    (48, 2250.00, 'Failed'),
    (49, 2300.50, 'Pending'),
    (50, 2400.00, 'Completed');
SELECT * FROM Transactions;
SELECT * FROM Receipts;
INSERT INTO Transactions (parcel_id, amount, status)
SELECT 
    parcel_id,
    (amount + weight + commission) AS calculated_amount,
    'Pending' AS status
FROM Parcels;


DELETE FROM Transactions;
 DROP TABLE Transactions;

INSERT INTO Receipts (parcel_id, amount)
SELECT 
    parcel_id,
    (amount + weight + commission) AS calculated_amount
FROM Parcels;
